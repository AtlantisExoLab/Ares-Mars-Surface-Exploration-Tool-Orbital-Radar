/**
 * AppShell.tsx
 * Primary application layout container integrating the Cesium Mars globe with the
 * top-left SearchBar, LeftRail, RightControls, StatusBar, slide-in panels, measure tool, and keyboard shortcuts.
 */

import React, { useEffect, useRef, useState } from 'react';
import * as Cesium from 'cesium';
import { AnimatePresence } from 'framer-motion';

import { useGlobeStore } from '../../store/globeStore';
import { usePlannerStore } from '../../store/plannerStore';
import { LANDING_SITES } from '../../data/landingSites';
import { LandingSitePins } from '../../globe/LandingSitePins';
import { RouteLayer } from '../../globe/RouteLayer';
import { cesiumLonToMars } from '../../globe/CoordinateUtils';
import { resetNorth, resetToGlobeView } from '../../globe/CameraController';

import { LeftRail } from './LeftRail';
import { RightControls } from './RightControls';
import { StatusBar } from './StatusBar';
import { SearchBar } from '../search/SearchBar';
import { LayerPanel } from '../layers/LayerPanel';
import { SitesSidebar } from '../sites/SitesSidebar';
import { MissionCard } from '../sites/MissionCard';
import { MissionPlanner } from '../planner/MissionPlanner';
import { SettingsPanel } from '../settings/SettingsPanel';
import { EnhanceButton } from '../ai/EnhanceButton';
import { OrbitalLayer } from '../../globe/OrbitalLayer';
import { DataLayersSync } from '../../globe/DataLayersSync';
import { LiveTelemetryHeader } from './LiveTelemetryHeader';
import { OrbitalRadarPanel } from '../orbiters/OrbitalRadarPanel';
import { MeasureTool } from '../tools/MeasureTool';
import { NASAResourcesPanel } from '../panels/NASAResourcesPanel';
import { RoverTraverseLayer } from '../../globe/RoverTraverseLayer';
import { LiveRoverImageryPanel } from '../panels/LiveRoverImageryPanel';

interface AppShellProps {
  viewer: Cesium.Viewer;
}

export const AppShell: React.FC<AppShellProps> = ({ viewer }) => {
  const activePanel = useGlobeStore((s) => s.activePanel);
  const selectedSiteId = useGlobeStore((s) => s.selectedSiteId);
  const setSelectedSite = useGlobeStore((s) => s.setSelectedSite);
  const setCursorInfo = useGlobeStore((s) => s.setCursorInfo);
  const setCameraAlt = useGlobeStore((s) => s.setCameraAlt);
  const isMeasuring = useGlobeStore((s) => s.isMeasuring);

  const waypoints = usePlannerStore((s) => s.waypoints);
  const isAddingWaypoints = usePlannerStore((s) => s.isAddingWaypoints);
  const addWaypoint = usePlannerStore((s) => s.addWaypoint);

  // High-performance throttled mouse move tracking for Mars coordinates
  useEffect(() => {
    if (!viewer?.scene) return;

    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);

    let lastSampleTime = 0;
    let pendingRaf: number | null = null;
    let lastPosition: Cesium.Cartesian2 | null = null;

    const sampleCoordinate = () => {
      pendingRaf = null;
      if (!lastPosition || viewer.isDestroyed()) return;

      const ray = viewer.camera.getPickRay(lastPosition);
      if (!ray) return;

      const cartesian = viewer.scene.globe.pick(ray, viewer.scene);
      if (cartesian) {
        const cartographic = Cesium.Cartographic.fromCartesian(
          cartesian,
          viewer.scene.globe.ellipsoid
        );
        const lat = Cesium.Math.toDegrees(cartographic.latitude);
        const lon = cesiumLonToMars(Cesium.Math.toDegrees(cartographic.longitude));
        const elev = Math.round(cartographic.height);

        setCursorInfo(lat, lon, elev);
      } else {
        setCursorInfo(null, null, null);
      }
    };

    handler.setInputAction((movement: any) => {
      lastPosition = movement.endPosition;
      const now = performance.now();
      // Throttle coordinate picking to at most 20Hz (every 50ms) to ensure smooth 60fps globe rotation
      if (now - lastSampleTime > 50) {
        lastSampleTime = now;
        if (!pendingRaf) {
          pendingRaf = requestAnimationFrame(sampleCoordinate);
        }
      }
    }, Cesium.ScreenSpaceEventType.MOUSE_MOVE);

    // Track camera altitude changes (throttled)
    let lastCameraAlt = 0;
    const removeCameraListener = viewer.camera.changed.addEventListener(() => {
      const altM = viewer.camera.positionCartographic.height;
      const altKm = Math.round(altM / 1000);
      if (Math.abs(altKm - lastCameraAlt) >= 2) {
        lastCameraAlt = altKm;
        setCameraAlt(altKm);
      }
    });

    return () => {
      if (pendingRaf) cancelAnimationFrame(pendingRaf);
      handler.destroy();
      removeCameraListener();
    };
  }, [viewer, setCursorInfo, setCameraAlt]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is currently typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.key === 'r' || e.key === 'R') {
        resetNorth(viewer);
      } else if (e.key === 'h' || e.key === 'H') {
        resetToGlobeView(viewer);
      } else if (e.key === '+' || e.key === '=') {
        viewer.camera.zoomIn(viewer.camera.positionCartographic.height * 0.3);
      } else if (e.key === '-' || e.key === '_') {
        viewer.camera.zoomOut(viewer.camera.positionCartographic.height * 0.4);
      } else if (e.key === 'f' || e.key === 'F') {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen();
        } else {
          document.exitFullscreen();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [viewer]);

  return (
    <div className="relative w-full h-full pointer-events-none select-none overflow-hidden">
      {/* 3D Map Entities on Globe */}
      <LandingSitePins
        viewer={viewer}
        sites={LANDING_SITES}
        selectedSiteId={selectedSiteId}
        onSiteClick={(site) => setSelectedSite(site.id)}
        disabled={isMeasuring}
      />

      {/* 3D Real-Time Orbital Tracking Layer (Phobos, Deimos, Orbiters) */}
      <OrbitalLayer viewer={viewer} />

      {/* Rover Traverse Paths (Curiosity & Perseverance) */}
      <RoverTraverseLayer viewer={viewer} />

      {/* Multi-Spectral Planetary Data Layers Sync (NASA Trek WMTS) */}
      <DataLayersSync viewer={viewer} />

      <RouteLayer
        viewer={viewer}
        waypoints={waypoints}
        onWaypointClick={(i) => console.log('Waypoint clicked:', i)}
        onGlobeClick={(lat, lon) => addWaypoint(lat, lon)}
        isAddingWaypoints={isAddingWaypoints}
      />

      {/* Navigation Left Rail */}
      <LeftRail />

      {/* Unified Top Navigation & Live Telemetry Header (Guarantees zero overlap on any screen width) */}
      <div className="fixed top-3 left-20 right-20 z-20 pointer-events-none flex items-center justify-between gap-4">
        <div className="pointer-events-auto flex-shrink-0">
          <SearchBar />
        </div>
        <div className="pointer-events-auto flex-shrink min-w-0">
          <LiveTelemetryHeader />
        </div>
      </div>

      {/* Right Controls HUD */}
      <RightControls />

      {/* Interactive Surface Measurement Tool */}
      <MeasureTool viewer={viewer} />

      {/* AI Super-Resolution Button */}
      <EnhanceButton />

      {/* Bottom Status Bar */}
      <StatusBar />

      {/* Modals & Slide-in Panels */}
      <AnimatePresence>
        {activePanel === 'layers' && <LayerPanel key="layers" />}
        {activePanel === 'sites' && <SitesSidebar key="sites" />}
        {activePanel === 'live-images' && <LiveRoverImageryPanel key="live-images" />}
        {activePanel === 'radar' && <OrbitalRadarPanel key="radar" />}
        {activePanel === 'nasa-resources' && <NASAResourcesPanel key="nasa-resources" />}
        {activePanel === 'planner' && <MissionPlanner key="planner" />}
        {activePanel === 'settings' && <SettingsPanel key="settings" />}
        {selectedSiteId && activePanel !== 'planner' && <MissionCard key="mission-card" />}
      </AnimatePresence>
    </div>
  );
};
