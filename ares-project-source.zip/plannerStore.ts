import { create } from 'zustand';

export interface Waypoint {
  id: string;
  lat: number;
  lon: number;
  label: string;
  note: string;
}

interface PlannerStore {
  isOpen: boolean;
  openPlanner: () => void;
  closePlanner: () => void;

  currentStep: 1 | 2 | 3 | 4 | 5;
  setStep: (s: 1 | 2 | 3 | 4 | 5) => void;

  // Step 1: Location
  baseLocation: { lat: number; lon: number; name: string } | null;
  setBaseLocation: (loc: PlannerStore['baseLocation']) => void;

  // Step 2: Objective
  objective: string;
  setObjective: (o: string) => void;

  // Step 3: Layers (uses globeStore)

  // Step 4: Route
  waypoints: Waypoint[];
  addWaypoint: (lat: number, lon: number) => void;
  removeWaypoint: (id: string) => void;
  moveWaypoint: (id: string, lat: number, lon: number) => void;
  isAddingWaypoints: boolean;
  setAddingWaypoints: (v: boolean) => void;

  // Step 5: Safety
  evaSpeedKmh: number;
  setEvaSpeedKmh: (v: number) => void;
  evaTimeLimitHours: number;
  setEvaTimeLimitHours: (v: number) => void;
  evaMode: 'astronaut-pair' | 'rover-assisted';
  setEvaMode: (m: PlannerStore['evaMode']) => void;
  displayMode: 'tablet' | 'helmet-hud' | 'habitat';
  setDisplayMode: (m: PlannerStore['displayMode']) => void;

  // Computed
  getTotalDistanceKm: () => number;
  getEstimatedDurationHours: () => number;
}

/** Haversine distance in km between two lat/lon pairs (approximate for Mars). */
function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3389.5; // Mars mean radius in km
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

let _waypointCounter = 0;

export const usePlannerStore = create<PlannerStore>((set, get) => ({
  isOpen: false,
  openPlanner: () => set({ isOpen: true }),
  closePlanner: () => set({ isOpen: false }),

  currentStep: 1,
  setStep: (s) => set({ currentStep: s }),

  baseLocation: null,
  setBaseLocation: (loc) => set({ baseLocation: loc }),

  objective: '',
  setObjective: (o) => set({ objective: o }),

  waypoints: [],
  addWaypoint: (lat, lon) => {
    _waypointCounter += 1;
    const id = `wp-${Date.now()}-${_waypointCounter}`;
    set((state) => ({
      waypoints: [
        ...state.waypoints,
        { id, lat, lon, label: `WP ${state.waypoints.length + 1}`, note: '' },
      ],
    }));
  },
  removeWaypoint: (id) =>
    set((state) => ({ waypoints: state.waypoints.filter((w) => w.id !== id) })),
  moveWaypoint: (id, lat, lon) =>
    set((state) => ({
      waypoints: state.waypoints.map((w) => (w.id === id ? { ...w, lat, lon } : w)),
    })),
  isAddingWaypoints: false,
  setAddingWaypoints: (v) => set({ isAddingWaypoints: v }),

  evaSpeedKmh: 1.5,
  setEvaSpeedKmh: (v) => set({ evaSpeedKmh: v }),
  evaTimeLimitHours: 8,
  setEvaTimeLimitHours: (v) => set({ evaTimeLimitHours: v }),
  evaMode: 'astronaut-pair',
  setEvaMode: (m) => set({ evaMode: m }),
  displayMode: 'tablet',
  setDisplayMode: (m) => set({ displayMode: m }),

  getTotalDistanceKm: () => {
    const { waypoints } = get();
    if (waypoints.length < 2) return 0;
    let total = 0;
    for (let i = 1; i < waypoints.length; i++) {
      total += haversineKm(
        waypoints[i - 1].lat,
        waypoints[i - 1].lon,
        waypoints[i].lat,
        waypoints[i].lon
      );
    }
    return total;
  },

  getEstimatedDurationHours: () => {
    const { getTotalDistanceKm, evaSpeedKmh } = get();
    const dist = getTotalDistanceKm();
    if (evaSpeedKmh <= 0) return 0;
    return dist / evaSpeedKmh;
  },
}));
