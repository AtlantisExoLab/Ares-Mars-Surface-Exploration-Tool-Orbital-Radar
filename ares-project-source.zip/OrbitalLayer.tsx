/**
 * OrbitalLayer.tsx
 *
 * High-performance 3D orbital tracking layer for Mars in CesiumJS.
 * Inspired by Orbital Radar (orbitalradar.com/mars):
 *  - Renders 3D closed Keplerian orbit paths for Phobos, Deimos, and 7 active orbiters
 *  - Real-time animated satellite positions via native Cesium.CallbackProperty (zero GC churn)
 *  - Agency colour-coded trajectory lines (NASA, ESA, UAE, CNSA, Moons)
 *  - ScreenSpaceEventHandler click detection with smooth orbital fly-to
 */

import React, { useEffect, useRef } from 'react';
import * as Cesium from 'cesium';
import { ORBITAL_BODIES, getOrbitPolyline, getBodyState, type OrbitalBody } from '../data/orbitalBodies';
import { useGlobeStore } from '../store/globeStore';

interface OrbitalLayerProps {
  viewer: Cesium.Viewer;
}

export const OrbitalLayer: React.FC<OrbitalLayerProps> = ({ viewer }) => {
  const showOrbits = useGlobeStore((s) => s.showOrbits);
  const selectedOrbitalBodyId = useGlobeStore((s) => s.selectedOrbitalBodyId);
  const setSelectedOrbitalBody = useGlobeStore((s) => s.setSelectedOrbitalBody);
  const setActivePanel = useGlobeStore((s) => s.setActivePanel);

  const polylineEntityIdsRef = useRef<string[]>([]);
  const bodyEntityIdsRef = useRef<Map<string, Cesium.Entity>>(new Map());

  // 1. Build Orbit Trajectory Polylines (static geometric loops)
  useEffect(() => {
    // Remove old polylines
    polylineEntityIdsRef.current.forEach((id) => {
      const e = viewer.entities.getById(id);
      if (e) viewer.entities.remove(e);
    });
    polylineEntityIdsRef.current = [];

    if (!showOrbits) return;

    ORBITAL_BODIES.forEach((body) => {
      const positions = getOrbitPolyline(body, 96);
      const isSelected = body.id === selectedOrbitalBodyId;
      const polylineId = `orbit-line-${body.id}`;

      const color = Cesium.Color.fromCssColorString(body.color);

      viewer.entities.add({
        id: polylineId,
        name: `${body.name} Orbit`,
        polyline: {
          positions,
          width: isSelected ? 2.5 : 1.2,
          material: new Cesium.PolylineGlowMaterialProperty({
            glowPower: isSelected ? 0.35 : 0.15,
            color: isSelected ? color.withAlpha(0.95) : color.withAlpha(0.45),
          }),
          arcType: Cesium.ArcType.NONE,
        },
      });

      polylineEntityIdsRef.current.push(polylineId);
    });

    viewer.scene.requestRender();
  }, [viewer, showOrbits, selectedOrbitalBodyId]);

  // 2. Build Moving Satellite Entities with zero-allocation CallbackProperty
  useEffect(() => {
    // Clean up old body entities
    bodyEntityIdsRef.current.forEach((e) => viewer.entities.remove(e));
    bodyEntityIdsRef.current.clear();

    if (!showOrbits) return;

    ORBITAL_BODIES.forEach((body) => {
      const entityId = `orbit-body-${body.id}`;
      const isMoon = body.type === 'moon';
      const isSelected = body.id === selectedOrbitalBodyId;
      const color = Cesium.Color.fromCssColorString(body.color);

      // Native Cesium CallbackPositionProperty calculates instantaneous position on-demand
      // without mutating entity properties or triggering React re-renders
      const positionProperty = new Cesium.CallbackPositionProperty(() => {
        const state = getBodyState(body, new Date());
        return state.position;
      }, false);

      const entity = viewer.entities.add({
        id: entityId,
        name: body.name,
        position: positionProperty,
        point: {
          pixelSize: isMoon ? (isSelected ? 14 : 10) : (isSelected ? 10 : 7),
          color: isMoon ? Cesium.Color.WHITE : color,
          outlineColor: isSelected ? Cesium.Color.fromCssColorString('#38bdf8') : Cesium.Color.BLACK,
          outlineWidth: isSelected ? 3 : 1.5,
          disableDepthTestDistance: Number.POSITIVE_INFINITY,
        },
        label: {
          text: isMoon ? `🌕 ${body.name}` : `🛰️ ${body.name.split(' (')[0]}`,
          font: isSelected ? 'bold 12px "Inter", sans-serif' : '500 11px "Inter", sans-serif',
          fillColor: isSelected ? Cesium.Color.fromCssColorString('#38bdf8') : Cesium.Color.WHITE,
          outlineColor: Cesium.Color.BLACK,
          outlineWidth: 3,
          style: Cesium.LabelStyle.FILL_AND_OUTLINE,
          pixelOffset: new Cesium.Cartesian2(0, -14),
          disableDepthTestDistance: Number.POSITIVE_INFINITY,
          distanceDisplayCondition: new Cesium.DistanceDisplayCondition(0, 1.2e8),
        },
      });

      bodyEntityIdsRef.current.set(body.id, entity);
    });

    return () => {
      bodyEntityIdsRef.current.forEach((e) => viewer.entities.remove(e));
      bodyEntityIdsRef.current.clear();
    };
  }, [viewer, showOrbits, selectedOrbitalBodyId]);

  // 3. ScreenSpaceEventHandler: Click detection to select and track body
  useEffect(() => {
    if (!showOrbits) return;

    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);

    handler.setInputAction(
      (click: Cesium.ScreenSpaceEventHandler.PositionedEvent) => {
        const picked = viewer.scene.pick(click.position);
        if (picked?.id instanceof Cesium.Entity) {
          const id = picked.id.id;
          if (id.startsWith('orbit-body-')) {
            const bodyId = id.replace('orbit-body-', '');
            const body = ORBITAL_BODIES.find((b) => b.id === bodyId);
            if (body) {
              setSelectedOrbitalBody(bodyId);
              setActivePanel('radar');

              // Smoothly fly camera to orbit altitude
              const state = getBodyState(body, new Date());
              const dest = Cesium.Cartesian3.multiplyByScalar(
                Cesium.Cartesian3.normalize(state.position, new Cesium.Cartesian3()),
                Cesium.Cartesian3.magnitude(state.position) * 1.35,
                new Cesium.Cartesian3(),
              );

              viewer.camera.flyTo({
                destination: dest,
                duration: 2.0,
                easingFunction: Cesium.EasingFunction.CUBIC_IN_OUT,
              });
            }
          }
        }
      },
      Cesium.ScreenSpaceEventType.LEFT_CLICK,
    );

    return () => {
      handler.destroy();
    };
  }, [viewer, showOrbits, setSelectedOrbitalBody, setActivePanel]);

  return null;
};
