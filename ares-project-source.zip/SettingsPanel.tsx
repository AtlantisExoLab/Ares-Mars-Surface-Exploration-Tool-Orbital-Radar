/**
 * SettingsPanel.tsx
 * Application settings drawer: terrain exaggeration, solar illumination, intro replay,
 * keyboard shortcuts, data attribution, and compulsory NASA Data & Resources Hub.
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGlobeStore } from '../../store/globeStore';
import { useSettingsStore } from '../../store/settingsStore';
import { setTerrainExaggeration } from '../../globe/CameraController';
import { AttributionModal } from './AttributionModal';

interface NASAResource {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  url: string;
  icon: string;
  badge: string;
  badgeColor: 'emerald' | 'amber' | 'sky' | 'purple';
  subLinks?: { label: string; url: string }[];
}

const NASA_RESOURCES: NASAResource[] = [
  {
    id: 'mars-trek',
    title: 'JPL Mars Trek',
    subtitle: 'NASA Jet Propulsion Laboratory',
    description:
      "NASA's official web portal for multi-spectral exploration of Mars. Showcases data collected at landing sites including MOLA topography, Viking imagery, and THEMIS thermal overlays.",
    url: 'https://trek.nasa.gov/mars/',
    icon: '🛰️',
    badge: 'ACTIVE',
    badgeColor: 'emerald',
    subLinks: [
      {
        label: 'MOLA Topography',
        url: 'https://trek.nasa.gov/mars/#v=0.1&x=0&y=0&z=1&b=mars&l=Mars_MGS_MOLA_Shade_global_463m%2Ctrue%2C1%2C1',
      },
      {
        label: 'THEMIS Day IR',
        url: 'https://trek.nasa.gov/mars/#v=0.1&x=0&y=0&z=1&l=THEMIS_DayIR_ControlledMosaics_100m_v2_oct2018%2Ctrue%2C1%2C1',
      },
    ],
  },
  {
    id: 'usgs-geology',
    title: 'USGS Planetary Geologic Mapping',
    subtitle: 'USGS Astrogeology Science Center + NASA',
    description:
      'High-quality, standardized geologic maps of Mars produced by USGS in partnership with NASA. Includes the global geologic map (Tanaka et al., 2014) mapping 44 geologic units across 4.6 billion years of Martian history.',
    url: 'https://www.usgs.gov/centers/astrogeology-science-center/planetary-geologic-mapping',
    icon: '🗺️',
    badge: 'PDS ARCHIVE',
    badgeColor: 'amber',
    subLinks: [
      {
        label: 'Global Mars Geologic Map (PDF)',
        url: 'https://pubs.usgs.gov/sim/3292/pdf/sim3292_map.pdf',
      },
      {
        label: 'USGS Astrogeology Maps',
        url: 'https://astrogeology.usgs.gov/maps/mars-viking-montes-geologic-map',
      },
    ],
  },
  {
    id: 'curiosity-route',
    title: 'Curiosity Rover Route Map',
    subtitle: 'NASA JPL Mars Science Laboratory',
    description:
      "Animated route visualization showing Curiosity's traverse across Gale Crater and lower Mount Sharp (Aeolis Mons), with annotated scientific exploration waypoints.",
    url: 'https://science.nasa.gov/mars/curiosity-route-map/',
    icon: '🤖',
    badge: 'ACTIVE ROVER',
    badgeColor: 'emerald',
    subLinks: [
      {
        label: 'Live Traverse Map',
        url: 'https://mars.nasa.gov/msl/mission/whereistheroversNow/',
      },
      {
        label: 'Curiosity Raw Images',
        url: 'https://mars.nasa.gov/msl/multimedia/raw-images/',
      },
    ],
  },
  {
    id: 'nasa-worldview',
    title: 'NASA Worldview',
    subtitle: 'NASA Earthdata / GIBS',
    description:
      'Visually explore dynamic planetary surfaces from a satellite perspective. Part of NASA Earthdata, Worldview provides satellite imagery from GIBS covering planetary surfaces and atmospheric events.',
    url: 'https://worldview.earthdata.nasa.gov/',
    icon: '🌍',
    badge: 'NASA EARTHDATA',
    badgeColor: 'sky',
    subLinks: [
      {
        label: 'Open Worldview',
        url: 'https://worldview.earthdata.nasa.gov/',
      },
      {
        label: 'Mars Collection',
        url: 'https://worldview.earthdata.nasa.gov/?t=2023-01-01-T00%3A00%3A00Z',
      },
    ],
  },
  {
    id: 'perseverance-raw',
    title: 'Mars Perseverance Raw Images',
    subtitle: 'NASA JPL Mars 2020 Mission',
    description:
      'Over 1 million raw images captured across Jezero Crater by 23 cameras (Mastcam-Z, Navcam, Hazcam, SuperCam, WATSON). Searchable by sol, camera, and date.',
    url: 'https://mars.nasa.gov/mars2020/multimedia/raw-images/',
    icon: '📸',
    badge: '1M+ IMAGES',
    badgeColor: 'purple',
    subLinks: [
      {
        label: 'Browse All Raw Images',
        url: 'https://mars.nasa.gov/mars2020/multimedia/raw-images/',
      },
      {
        label: 'NASA Image Archive',
        url: 'https://images.nasa.gov/search?q=perseverance+mars&media_type=image',
      },
    ],
  },
];

const BADGE_COLORS: Record<string, string> = {
  emerald: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  amber: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
  sky: 'bg-sky-500/15 text-sky-400 border-sky-500/30',
  purple: 'bg-purple-500/15 text-purple-400 border-purple-500/30',
};

export const SettingsPanel: React.FC = () => {
  const viewer = useGlobeStore((s) => s.viewer);
  const terrainExaggeration = useGlobeStore((s) => s.terrainExaggeration);
  const setStoreTerrainExaggeration = useGlobeStore((s) => s.setTerrainExaggeration);
  const setActivePanel = useGlobeStore((s) => s.setActivePanel);
  const solarLighting = useGlobeStore((s) => s.solarLighting);
  const toggleSolarLighting = useGlobeStore((s) => s.toggleSolarLighting);

  const replayIntro = useSettingsStore((s) => s.replayIntro);

  const [showAttributionModal, setShowAttributionModal] = useState(false);
  const [expandedResource, setExpandedResource] = useState<string | null>(null);

  const handleExaggerationChange = (val: number) => {
    setStoreTerrainExaggeration(val);
    if (viewer) {
      setTerrainExaggeration(viewer, val);
    }
  };

  const handleReplayIntro = () => {
    replayIntro();
    window.location.reload();
  };

  const shortcuts = [
    { key: 'Left Drag', desc: 'Rotate / Pan Mars globe' },
    { key: 'Right Drag / Wheel', desc: 'Zoom camera in & out' },
    { key: 'Ctrl + Left Drag', desc: 'Tilt 3D pitch & camera roll' },
    { key: 'Double Click', desc: 'Fly smoothly to targeted surface feature' },
    { key: 'R', desc: 'Reset North orientation' },
    { key: 'H', desc: 'Reset to full planetary orbit view' },
  ];

  return (
    <>
      <motion.div
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: -20, opacity: 0 }}
        transition={{ duration: 0.25, ease: 'easeOut' }}
        className="fixed top-16 left-20 w-88 md:w-[460px] bottom-16 bg-[#0a0d14] border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col z-30 overflow-hidden pointer-events-auto"
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-700/80 bg-[#0f1420] flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-lg">⚙️</span>
            <div>
              <h2 className="text-white font-display font-semibold text-base">Settings &amp; Resources</h2>
              <p className="text-[11px] text-white/50">Planetary controls &amp; NASA scientific databases</p>
            </div>
          </div>
          <button
            onClick={() => setActivePanel(null)}
            className="text-white/40 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
            title="Close"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6 text-xs text-white/80">
          {/* Solar Day / Night Terminator Lighting Toggle */}
          <div className="p-4 rounded-xl bg-space-800/40 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-semibold text-white">Solar Day / Night Illumination</div>
                <div className="text-white/50 text-[11px] mt-0.5">
                  {solarLighting
                    ? 'Realistic Sun shadows & planetary terminator active'
                    : 'Uniform true-colour NASA basemap mode (no night shadows)'}
                </div>
              </div>
              <button
                onClick={toggleSolarLighting}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  solarLighting
                    ? 'bg-amber-500 text-black shadow-[0_0_12px_rgba(245,158,11,0.5)]'
                    : 'bg-white/10 text-white/70 hover:text-white hover:bg-white/20'
                }`}
              >
                {solarLighting ? '☀️ Solar Active' : '🗺️ Map Mode'}
              </button>
            </div>
          </div>

          {/* NASA DATA & RESOURCES SECTION (Moved inside Settings) */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-[#0c111d] to-[#111726] border border-mars-500/40 space-y-3.5 shadow-lg">
            <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
              <div className="flex items-center gap-2">
                <span className="text-base">🚀</span>
                <div>
                  <div className="font-semibold text-white">NASA Data &amp; Resources</div>
                  <div className="text-white/50 text-[10px]">5 Compulsory Planetary Exploration Portals</div>
                </div>
              </div>
              <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-mars-500/20 text-mars-300 border border-mars-500/30 font-bold uppercase">
                Official NASA Portals
              </span>
            </div>

            <p className="text-white/70 text-[11px] leading-relaxed">
              Curated official data repositories from NASA JPL, USGS Astrogeology, and Earthdata covering GIS maps, traverse tracks, and raw imagery.
            </p>

            <div className="space-y-2.5 pt-1">
              {NASA_RESOURCES.map((res) => {
                const isExpanded = expandedResource === res.id;
                return (
                  <div
                    key={res.id}
                    className="p-3 rounded-xl bg-black/40 border border-white/10 hover:border-mars-500/40 transition-colors space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-base">{res.icon}</span>
                        <div>
                          <div className="font-semibold text-white text-xs">{res.title}</div>
                          <div className="text-[10px] text-white/40">{res.subtitle}</div>
                        </div>
                      </div>
                      <span
                        className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border ${
                          BADGE_COLORS[res.badgeColor] || 'text-white/60 border-white/20'
                        }`}
                      >
                        {res.badge}
                      </span>
                    </div>

                    <p className="text-[11px] text-white/60 leading-relaxed">{res.description}</p>

                    <div className="flex items-center justify-between pt-1 border-t border-white/5 text-[11px]">
                      {res.subLinks && res.subLinks.length > 0 && (
                        <button
                          onClick={() => setExpandedResource(isExpanded ? null : res.id)}
                          className="text-mars-400 hover:text-mars-300 font-mono text-[10px] flex items-center gap-1 transition-colors"
                        >
                          <span>{isExpanded ? '▲ Hide sub-links' : '▼ View sub-links'}</span>
                        </button>
                      )}
                      <a
                        href={res.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="ml-auto py-1 px-2.5 rounded-lg bg-mars-600/30 hover:bg-mars-600 text-white font-medium text-[10px] flex items-center gap-1 transition-colors"
                      >
                        <span>Open Portal</span>
                        <span>↗</span>
                      </a>
                    </div>

                    {/* Sublinks Accordion */}
                    <AnimatePresence>
                      {isExpanded && res.subLinks && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="pt-2 space-y-1 overflow-hidden"
                        >
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                            {res.subLinks.map((sub, idx) => (
                              <a
                                key={idx}
                                href={sub.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-2 py-1 rounded bg-white/5 hover:bg-white/15 text-[10px] text-sky-300 flex items-center justify-between truncate transition-colors"
                              >
                                <span className="truncate">{sub.label}</span>
                                <span className="text-[9px] opacity-60">↗</span>
                              </a>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Cinematic Prologue Replay */}
          <div className="p-4 rounded-xl bg-space-800/40 border border-white/10 space-y-2">
            <div className="font-semibold text-white">Cinematic Prologue</div>
            <p className="text-white/60 text-[11px] leading-relaxed">
              Re-experience the 8-second cinematic approach animation from deep space into Mars orbit.
            </p>
            <button
              onClick={handleReplayIntro}
              className="px-4 py-2 rounded-lg bg-mars-600/30 hover:bg-mars-600/50 text-mars-300 border border-mars-500/40 font-medium text-xs transition-colors"
            >
              🎬 Replay Cinematic Intro
            </button>
          </div>

          {/* Terrain Exaggeration Slider */}
          <div className="p-4 rounded-xl bg-space-800/40 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-white">Topographic Elevation Scale</span>
              <span className="font-mono text-mars-400 font-bold">{terrainExaggeration}×</span>
            </div>
            <p className="text-white/60 text-[11px]">
              Multiplies vertical elevation relief to accentuate crater walls, canyon scarps, and shield volcanoes.
            </p>
            <input
              type="range"
              min="1"
              max="5"
              step="0.5"
              value={terrainExaggeration}
              onChange={(e) => handleExaggerationChange(parseFloat(e.target.value))}
              className="w-full accent-mars-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-white/40 font-mono">
              <span>1.0× (True Physical)</span>
              <span>3.0×</span>
              <span>5.0× (Exaggerated)</span>
            </div>
          </div>

          {/* Keyboard & Mouse Shortcuts */}
          <div className="p-4 rounded-xl bg-space-800/40 border border-white/10 space-y-2.5">
            <div className="font-semibold text-white">Navigation Controls</div>
            <div className="space-y-2">
              {shortcuts.map((sc, i) => (
                <div key={i} className="flex items-center justify-between text-[11px]">
                  <span className="text-white/60">{sc.desc}</span>
                  <span className="px-2 py-0.5 rounded bg-black/40 border border-white/10 font-mono text-white/90">
                    {sc.key}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Attribution Modal Button */}
          <div className="p-4 rounded-xl bg-space-800/40 border border-white/10 space-y-2">
            <div className="font-semibold text-white">Data &amp; Provenance</div>
            <p className="text-white/60 text-[11px]">
              Review scientific credit and official licenses for all NASA, USGS, ESA, CNSA, and ISRO datasets.
            </p>
            <button
              onClick={() => setShowAttributionModal(true)}
              className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-xs transition-colors"
            >
              📜 View Full Attribution &amp; Credits
            </button>
          </div>
        </div>
      </motion.div>

      {/* Attribution Modal */}
      {showAttributionModal && (
        <AttributionModal onClose={() => setShowAttributionModal(false)} />
      )}
    </>
  );
};
