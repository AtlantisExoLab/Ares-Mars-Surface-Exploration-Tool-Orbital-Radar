"""
Ares AI Enhancement Backend (Optional)
Run: uvicorn main:app --reload
"""
from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
import io

app = FastAPI(title="Ares AI Image Enhancement API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def health_check():
    return {"status": "ok", "service": "Ares AI Enhancement Service"}

@app.post("/enhance")
async def enhance_tile(file: UploadFile = File(...)):
    """
    Accepts a Mars imagery tile and applies super-resolution / contrast-sharpening.
    """
    content = await file.read()
    try:
        from PIL import Image, ImageFilter, ImageEnhance
        img = Image.open(io.BytesIO(content)).convert("RGB")
        # Unsharp mask and micro-contrast enhancement
        sharpened = img.filter(ImageFilter.UnsharpMask(radius=1.5, percent=140, threshold=2))
        enhanced = ImageEnhance.Contrast(sharpened).enhance(1.08)
        
        output = io.BytesIO()
        enhanced.save(output, format="JPEG", quality=95)
        return Response(content=output.getvalue(), media_type="image/jpeg")
    except Exception as e:
        # Fallback to returning original bytes if PIL is not installed
        return Response(content=content, media_type="image/jpeg")
