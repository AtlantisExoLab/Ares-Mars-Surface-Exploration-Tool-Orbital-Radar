/**
 * CesiumViewer.tsx
 *
 * React component that initialises and owns the Cesium Viewer for the
 * Ares Mars web application.
 *
 * The viewer is configured for Mars:
 *  - Mars reference ellipsoid (semi-major 3 396 190 m, semi-minor 3 376 200 m)
 *  - NASA Viking MDIM 2.1 4096x2048 4K Equirectangular base texture
 *  - High-resolution deep-space 3D SkyBox with starry nebulae and stellar spectra
 *  - High-performance 60fps inertial camera controls
 *  - Terrain exaggeration and dynamic solar illumination support
 */

import React, { useEffect, useRef } from 'react';
import * as Cesium from 'cesium';

import { createMarsBaseImageryProvider } from './MarsImagery';
import { createMarsTerrainProvider } from './MarsTerrain';
import { useGlobeStore } from '../store/globeStore';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Mars 2000 reference ellipsoid (semi-major = 3 396 190 m, semi-minor = 3 376 200 m) */
const MARS_ELLIPSOID = new Cesium.Ellipsoid(3_396_190, 3_396_190, 3_376_200);

/** Initial camera altitude in metres — reveals the whole Mars globe */
const INITIAL_ALTITUDE_M = 8_500_000;

/** Minimum zoom altitude in metres — close-up surface exploration */
const MIN_ZOOM_M = 25_000;

/** Maximum zoom altitude in metres */
const MAX_ZOOM_M = 45_000_000;

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export interface CesiumViewerProps {
  /** Called once the Viewer is fully constructed and ready for use. */
  onReady: (viewer: Cesium.Viewer) => void;
}

export const CesiumViewer: React.FC<CesiumViewerProps> = ({ onReady }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<Cesium.Viewer | null>(null);
  const onReadyRef = useRef(onReady);
  onReadyRef.current = onReady;

  const solarLighting = useGlobeStore((s) => s.solarLighting);

  // Sync solar lighting whenever changed in store
  useEffect(() => {
    if (!viewerRef.current || viewerRef.current.isDestroyed()) return;
    const { scene } = viewerRef.current;
    scene.globe.enableLighting = solarLighting;
    if (scene.sun) {
      scene.sun.show = solarLighting;
    }
    scene.requestRender();
  }, [solarLighting]);

  useEffect(() => {
    if (!containerRef.current || viewerRef.current) return;

    // Optional Ion token
    const ionToken = (import.meta as any).env?.VITE_CESIUM_ION_TOKEN as string | undefined;
    if (ionToken) {
      Cesium.Ion.defaultAccessToken = ionToken;
    }

    const marsProjection = new Cesium.GeographicProjection(MARS_ELLIPSOID);

    // Realistic deep-space 3D SkyBox
    const skyBox = new Cesium.SkyBox({
      sources: {
        positiveX: '/textures/skybox/px.jpg',
        negativeX: '/textures/skybox/nx.jpg',
        positiveY: '/textures/skybox/py.jpg',
        negativeY: '/textures/skybox/ny.jpg',
        positiveZ: '/textures/skybox/pz.jpg',
        negativeZ: '/textures/skybox/nz.jpg',
      },
      show: true,
    });

    // Create the Viewer
    const viewer = new Cesium.Viewer(containerRef.current, {
      globe: new Cesium.Globe(MARS_ELLIPSOID),
      baseLayer: false as any,
      terrainProvider: new Cesium.EllipsoidTerrainProvider({
        ellipsoid: MARS_ELLIPSOID,
      }),
      mapProjection: marsProjection,
      skyBox,

      // UI Chrome disabled (we build our own HUD)
      animation: false,
      timeline: false,
      geocoder: false,
      homeButton: false,
      sceneModePicker: false,
      navigationHelpButton: false,
      baseLayerPicker: false,
      fullscreenButton: false,
      infoBox: false,
      selectionIndicator: false,

      sceneMode: Cesium.SceneMode.SCENE3D,
      scene3DOnly: false,
      orderIndependentTranslucency: true,
      contextOptions: {
        webgl: {
          alpha: false,
          preserveDrawingBuffer: true, // required for AI canvas capture
        },
      },
    });

    viewerRef.current = viewer;
    const { scene } = viewer;

    // Remove any default Earth layers
    scene.imageryLayers.removeAll();

    // 1. Photorealistic NASA Viking MDIM 2.1 4K Equirectangular Base Texture (Instant load)
    const baseProvider = createMarsBaseImageryProvider();
    const baseLayer = scene.imageryLayers.addImageryProvider(baseProvider);
    (baseLayer as any)._aresLayerId = 'nasa-base';
    baseLayer.alpha = 1.0;

    // -----------------------------------------------------------------------
    // Visual & Atmospheric Tuning matching NASA's official 3D Mars Model
    // -----------------------------------------------------------------------
    scene.backgroundColor = Cesium.Color.fromCssColorString('#02040a');

    // Disable Earth Moon in Mars orbit
    if (scene.moon) {
      scene.moon.show = false;
    }

    if (scene.sun) {
      scene.sun.show = false;
    }

    // Default: Uniform true-colour planetary illumination for optimal map exploration
    scene.globe.enableLighting = false;
    scene.globe.showGroundAtmosphere = false;
    if (scene.skyAtmosphere) {
      scene.skyAtmosphere.show = false;
    }
    scene.globe.baseColor = Cesium.Color.fromCssColorString('#9c361e');

    // Subtle Martian atmospheric depth
    scene.fog.enabled = true;
    scene.fog.density = 0.00003;

    // -----------------------------------------------------------------------
    // Camera Controller & Trackpad Gesture Controls
    // -----------------------------------------------------------------------
    const cameraCtrl = scene.screenSpaceCameraController;
    cameraCtrl.inertiaSpin = 0.88;
    cameraCtrl.inertiaTranslate = 0.88;
    cameraCtrl.inertiaZoom = 0.82;
    cameraCtrl.minimumZoomDistance = MIN_ZOOM_M;
    cameraCtrl.maximumZoomDistance = MAX_ZOOM_M;

    // Enable all trackpad / touchpad two-finger zoom events
    cameraCtrl.zoomEventTypes = [
      Cesium.CameraEventType.WHEEL,
      Cesium.CameraEventType.PINCH,
      {
        eventType: Cesium.CameraEventType.WHEEL,
        modifier: Cesium.KeyboardEventModifier.CTRL,
      },
    ];

    // High-precision laptop trackpad pinch-to-zoom listener
    const container = containerRef.current;
    const handleTouchpadWheel = (e: WheelEvent) => {
      // Laptop trackpad two-finger pinch emits wheel events with e.ctrlKey = true
      if (e.ctrlKey) {
        e.preventDefault();
        const alt = viewer.camera.positionCartographic.height;
        const zoomDelta = e.deltaY;
        const zoomScale = Math.min(0.25, Math.max(0.02, Math.abs(zoomDelta) * 0.0035));
        if (zoomDelta < 0) {
          // Pinch out / spread two fingers -> Zoom In
          viewer.camera.zoomIn(Math.max(500, alt * zoomScale));
        } else if (zoomDelta > 0) {
          // Pinch in -> Zoom Out
          viewer.camera.zoomOut(Math.max(500, alt * zoomScale));
        }
      }
    };

    container.addEventListener('wheel', handleTouchpadWheel, { passive: false });

    // Initial viewpoint: Full Mars globe facing Valles Marineris & Tharsis
    viewer.camera.setView({
      destination: Cesium.Cartesian3.fromDegrees(-50, 5, INITIAL_ALTITUDE_M, MARS_ELLIPSOID),
      orientation: {
        heading: Cesium.Math.toRadians(0),
        pitch: Cesium.Math.toRadians(-90),
        roll: 0,
      },
    });

    // Async terrain upgrade (non-blocking)
    void createMarsTerrainProvider().then((terrainProvider) => {
      if (!viewerRef.current || viewerRef.current.isDestroyed()) return;
      viewer.terrainProvider = terrainProvider;
    });

    onReadyRef.current(viewer);

    return () => {
      container.removeEventListener('wheel', handleTouchpadWheel);
      if (viewerRef.current && !viewerRef.current.isDestroyed()) {
        viewerRef.current.destroy();
        viewerRef.current = null;
      }
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="w-full h-full cursor-grab active:cursor-grabbing select-none"
      style={{ touchAction: 'none' }}
    />
  );
};
