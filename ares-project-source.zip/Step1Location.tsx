/**
 * Step1Location.tsx
 * Mission Planner Step 1: Base Location Selection.
 */

import React, { useState } from 'react';
import { useGlobeStore } from '../../../store/globeStore';
import { usePlannerStore } from '../../../store/plannerStore';
import { DEMO_SCENARIOS, getDemoScenarioById } from '../../../data/demoScenarios';
import { flyTo } from '../../../globe/CameraController';

export const Step1Location: React.FC = () => {
  const viewer = useGlobeStore((s) => s.viewer);
  const baseLocation = usePlannerStore((s) => s.baseLocation);
  const setBaseLocation = usePlannerStore((s) => s.setBaseLocation);
  const setObjective = usePlannerStore((s) => s.setObjective);
  const addWaypoint = usePlannerStore((s) => s.addWaypoint);
  const setStep = usePlannerStore((s) => s.setStep);

  const [inputLat, setInputLat] = useState(baseLocation ? baseLocation.lat.toString() : '-4.68');
  const [inputLon, setInputLon] = useState(baseLocation ? baseLocation.lon.toString() : '137.38');
  const [inputName, setInputName] = useState(baseLocation ? baseLocation.name : 'Gale Crater');

  const presets = [
    { name: 'Gale Crater (Mount Sharp)', lat: -4.68, lon: 137.38, desc: 'Curiosity boxwork & clay layers' },
    { name: 'Jezero Crater (Neretva Delta)', lat: 18.45, lon: 77.45, desc: 'Perseverance delta fan deposits' },
    { name: 'Olympus Mons Caldera Base', lat: 18.65, lon: 226.2, desc: 'Volcanic lava tubes and cliffs' },
    { name: 'Planum Australe (South Pole)', lat: -85.0, lon: 180.0, desc: 'Perennial water & CO2 polar ice' },
  ];

  const handleApplyCustom = () => {
    const lat = parseFloat(inputLat);
    const lon = parseFloat(inputLon);
    if (!isNaN(lat) && !isNaN(lon)) {
      setBaseLocation({ lat, lon, name: inputName || 'Custom Mars Coordinates' });
      if (viewer) flyTo(viewer, lat, lon, 250, 2);
    }
  };

  const handleSelectPreset = (p: typeof presets[0]) => {
    setInputLat(p.lat.toString());
    setInputLon(p.lon.toString());
    setInputName(p.name);
    setBaseLocation({ lat: p.lat, lon: p.lon, name: p.name });
    if (viewer) flyTo(viewer, p.lat, p.lon, 250, 2);
  };

  const handleLoadDemo = (scenarioId: string) => {
    const demo = getDemoScenarioById(scenarioId);
    if (!demo) return;

    // Load base location
    setBaseLocation({
      lat: demo.location.lat,
      lon: demo.location.lon,
      name: demo.location.name,
    });

    // Load objective
    setObjective(demo.objective);

    // Clear existing waypoints and populate demo waypoints
    const store = usePlannerStore.getState();
    // Reset waypoints
    usePlannerStore.setState({ waypoints: [] });
    demo.waypoints.forEach((w) => {
      usePlannerStore.getState().addWaypoint(w.lat, w.lon);
    });

    if (viewer) {
      flyTo(viewer, demo.location.lat, demo.location.lon, 150, 2.5);
    }

    setStep(4); // Jump directly to route review
  };

  return (
    <div className="space-y-6 text-xs text-white/80">
      {/* Intro Description */}
      <div className="p-3.5 rounded-xl bg-space-800/60 border border-white/10 space-y-1.5">
        <div className="font-semibold text-white flex items-center gap-1.5">
          <span>🚀</span>
          <span>1. Select Mission Base & Staging Site</span>
        </div>
        <p className="text-white/60 leading-relaxed text-[11px]">
          Define the habitat landing coordinate or touchdown base. You can load a curated NASA exploration scenario or configure custom coordinates.
        </p>
      </div>

      {/* Preloaded Demo Scenarios Banner */}
      <div className="p-3.5 rounded-xl bg-mars-950/50 border border-mars-500/30 space-y-2.5">
        <div className="font-semibold text-mars-300 flex items-center gap-1.5">
          <span>⚡</span>
          <span>Load NASA Science Traverse Preset</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {DEMO_SCENARIOS.map((demo) => (
            <button
              key={demo.id}
              onClick={() => handleLoadDemo(demo.id)}
              className="p-2.5 rounded-lg bg-mars-900/40 hover:bg-mars-800/60 border border-mars-600/30 text-left transition-colors group"
            >
              <div className="font-semibold text-white text-xs group-hover:text-mars-200">
                {demo.name}
              </div>
              <div className="text-[10px] text-white/50 mt-1 line-clamp-2">
                {demo.description}
              </div>
              <div className="text-[10px] text-mars-400 font-mono mt-1.5">
                Load Complete Plan →
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Recommended Mars Exploration Presets */}
      <div>
        <div className="text-white/50 font-mono text-[11px] uppercase mb-2">
          Recommended Exploration Regions
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {presets.map((p) => {
            const isSelected = baseLocation?.name === p.name;
            return (
              <button
                key={p.name}
                onClick={() => handleSelectPreset(p)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-mars-600/30 border-mars-500 text-white'
                    : 'bg-space-800/40 border-white/10 text-white/70 hover:bg-space-800/80 hover:text-white'
                }`}
              >
                <div className="font-semibold text-xs text-white">{p.name}</div>
                <div className="text-[10px] text-white/50 mt-0.5">{p.desc}</div>
                <div className="text-[10px] font-mono text-mars-400/80 mt-1">
                  {p.lat}°N, {p.lon}°E
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Manual Coordinate Input */}
      <div className="p-3.5 rounded-xl bg-space-800/40 border border-white/10 space-y-3">
        <div className="text-white/70 font-semibold">Custom Martian Coordinates</div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-[10px] text-white/40 block mb-1">Latitude (-90 to 90)</label>
            <input
              type="number"
              step="0.001"
              value={inputLat}
              onChange={(e) => setInputLat(e.target.value)}
              className="w-full px-3 py-1.5 rounded-lg bg-black/40 border border-white/15 text-white text-xs font-mono"
            />
          </div>
          <div>
            <label className="text-[10px] text-white/40 block mb-1">Longitude (0 to 360° E)</label>
            <input
              type="number"
              step="0.001"
              value={inputLon}
              onChange={(e) => setInputLon(e.target.value)}
              className="w-full px-3 py-1.5 rounded-lg bg-black/40 border border-white/15 text-white text-xs font-mono"
            />
          </div>
        </div>
        <button
          onClick={handleApplyCustom}
          className="w-full py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-xs transition-colors"
        >
          Set Base Coordinates & Fly To Location
        </button>
      </div>

      {/* Current Selection summary */}
      {baseLocation && (
        <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between">
          <span>Staging Site: <strong>{baseLocation.name}</strong></span>
          <span className="font-mono text-[11px]">
            {baseLocation.lat}°N, {baseLocation.lon}°E
          </span>
        </div>
      )}
    </div>
  );
};
