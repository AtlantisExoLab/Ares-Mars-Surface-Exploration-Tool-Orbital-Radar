const https = require('https');

function check(url) {
  return new Promise((resolve) => {
    https.get(url, (res) => {
      resolve({
        url,
        status: res.statusCode,
        type: res.headers['content-type'],
        length: res.headers['content-length'],
      });
    }).on('error', (e) => resolve({ url, error: e.message }));
  });
}

async function run() {
  const layer = 'Mars_MOLA_blend200ppx_HRSC_ClrShade_clon0dd_200mpp_lzw';
  const ext = 'png';

  console.log('--- Zoom 0 ---');
  console.log('0/0/0:', await check(`https://trek.nasa.gov/tiles/Mars/EQ/${layer}/1.0.0/default/default028mm/0/0/0.${ext}`));
  console.log('0/0/1:', await check(`https://trek.nasa.gov/tiles/Mars/EQ/${layer}/1.0.0/default/default028mm/0/0/1.${ext}`));

  console.log('--- Zoom 1 ---');
  console.log('1/0/0:', await check(`https://trek.nasa.gov/tiles/Mars/EQ/${layer}/1.0.0/default/default028mm/1/0/0.${ext}`));
  console.log('1/0/1:', await check(`https://trek.nasa.gov/tiles/Mars/EQ/${layer}/1.0.0/default/default028mm/1/0/1.${ext}`));
  console.log('1/1/0:', await check(`https://trek.nasa.gov/tiles/Mars/EQ/${layer}/1.0.0/default/default028mm/1/1/0.${ext}`));
  console.log('1/1/1:', await check(`https://trek.nasa.gov/tiles/Mars/EQ/${layer}/1.0.0/default/default028mm/1/1/1.${ext}`));
  console.log('1/0/2:', await check(`https://trek.nasa.gov/tiles/Mars/EQ/${layer}/1.0.0/default/default028mm/1/0/2.${ext}`));
  console.log('1/0/3:', await check(`https://trek.nasa.gov/tiles/Mars/EQ/${layer}/1.0.0/default/default028mm/1/0/3.${ext}`));
}

run();
