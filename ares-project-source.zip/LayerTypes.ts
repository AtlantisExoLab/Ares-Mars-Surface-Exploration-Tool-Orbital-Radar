/**
 * LayerTypes.ts
 * Types for imagery, terrain, and atmospheric layers.
 */

export type LayerId =
  | 'viking-mdim21'
  | 'mola-shaded-relief'
  | 'mola-color-dem'
  | 'themis-day-ir'
  | 'themis-night-ir'
  | 'ctx-mosaic'
  | 'crism-fe-mineral'
  | 'crism-hydrated'
  | 'usgs-geologic';

export interface LayerConfig {
  id: LayerId;
  name: string;
  description: string;
  type: 'optical' | 'thermal' | 'topographic' | 'spectral' | 'geologic';
  resolution: string;
  source: string;
  sourceUrl: string;
  license: string;
  defaultOpacity: number;
  defaultVisible: boolean;
}

export interface ActiveLayerState {
  id: LayerId;
  opacity: number;
  visible: boolean;
  order: number;
}
