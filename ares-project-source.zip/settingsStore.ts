import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface SettingsStore {
  introPlayed: boolean;
  setIntroPlayed: (v: boolean) => void;
  replayIntro: () => void;
  theme: 'dark';
  showAttribution: boolean;
  setShowAttribution: (v: boolean) => void;
}

export const useSettingsStore = create<SettingsStore>()(
  persist(
    (set) => ({
      introPlayed: false,
      setIntroPlayed: (v) => set({ introPlayed: v }),
      replayIntro: () => set({ introPlayed: false }),
      theme: 'dark' as const,
      showAttribution: true,
      setShowAttribution: (v) => set({ showAttribution: v }),
    }),
    {
      name: 'ares.settings',
      partialize: (state) => ({ introPlayed: state.introPlayed, showAttribution: state.showAttribution }),
    }
  )
);
