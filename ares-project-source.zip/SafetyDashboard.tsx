/**
 * SafetyDashboard.tsx
 * Astronaut Safety & Hazard Dashboard evaluating terrain risks, mobility limits,
 * space radiation dosage, line-of-sight communication with Habitat, and EVA duration.
 */

import React, { useMemo } from 'react';
import { estimateSlopeDeg } from '../../routing/AStarRouter';
import type { SafetyMetrics } from '../../types/MissionTypes';

interface SafetyDashboardProps {
  waypoints: Array<{ lat: number; lon: number; label: string }>;
  evaSpeedKmh: number;
  evaTimeLimitHours: number;
  evaMode: 'astronaut-pair' | 'rover-assisted';
}

export const SafetyDashboard: React.FC<SafetyDashboardProps> = ({
  waypoints,
  evaSpeedKmh,
  evaTimeLimitHours,
  evaMode,
}) => {
  const metrics = useMemo<SafetyMetrics>(() => {
    if (waypoints.length < 2) {
      return {
        totalDistanceKm: 0,
        estimatedDurationHours: 0,
        maxSlopeDeg: 0,
        meanSlopeDeg: 0,
        elevationGainM: 0,
        elevationLossM: 0,
        temperatureRangeC: { min: -78, max: -18 },
        radiationDoseRateMGyDay: 0.64, // MSL RAD archive baseline
        habitatDistanceKm: 0,
        habitatLosMaintained: true,
        warnings: [],
      };
    }

    let totalDistKm = 0;
    const slopes: number[] = [];

    for (let i = 0; i < waypoints.length; i++) {
      const slope = estimateSlopeDeg(waypoints[i].lat, waypoints[i].lon);
      slopes.push(slope);

      if (i > 0) {
        const p1 = waypoints[i - 1];
        const p2 = waypoints[i];
        const dLat = (p2.lat - p1.lat) * 59.2;
        const dLon = (p2.lon - p1.lon) * 59.2 * Math.cos((p1.lat * Math.PI) / 180);
        totalDistKm += Math.sqrt(dLat * dLat + dLon * dLon);
      }
    }

    const maxSlope = slopes.length > 0 ? Math.max(...slopes) : 0;
    const meanSlope = slopes.length > 0 ? slopes.reduce((a, b) => a + b, 0) / slopes.length : 0;

    // Effective speed with slope and mode adjustments
    const modeMultiplier = evaMode === 'rover-assisted' ? 2.5 : 1.0;
    const effectiveSpeed = Math.max(0.4, (evaSpeedKmh * modeMultiplier) * (1 - (meanSlope / 40)));
    const estHours = Number((totalDistKm / effectiveSpeed).toFixed(1));

    // Habitat distance (from first waypoint = Camp / Hab)
    const lastWp = waypoints[waypoints.length - 1];
    const habWp = waypoints[0];
    const dLatH = (lastWp.lat - habWp.lat) * 59.2;
    const dLonH = (lastWp.lon - habWp.lon) * 59.2 * Math.cos((habWp.lat * Math.PI) / 180);
    const habDistKm = Number(Math.sqrt(dLatH * dLatH + dLonH * dLonH).toFixed(2));

    // Line of sight: blocked if hab distance > 3.5 km and mean slope > 12°
    const los = !(habDistKm > 3.5 && meanSlope > 12);

    // Hazard warnings
    const warnings: SafetyMetrics['warnings'] = [];

    if (maxSlope >= 28) {
      warnings.push({
        id: 'slope-critical',
        level: 'critical',
        title: 'Impassable Slope Exceeded (>28°)',
        detail: 'Exceeds pressurized space suit mechanical articulation limit (30° max). High rollover/fall hazard.',
      });
    } else if (maxSlope > 18) {
      warnings.push({
        id: 'slope-warn',
        level: 'warning',
        title: 'Moderate Slope Hazard (18°–28°)',
        detail: 'Significant metabolic exertion penalty; suit joints under elevated strain.',
      });
    }

    if (estHours > evaTimeLimitHours) {
      warnings.push({
        id: 'oxygen-budget',
        level: 'critical',
        title: 'Life Support / Oxygen Budget Overrun',
        detail: `Estimated traverse (${estHours} hrs) exceeds primary consumable limit (${evaTimeLimitHours} hrs).`,
      });
    } else if (estHours > evaTimeLimitHours * 0.8) {
      warnings.push({
        id: 'oxygen-warn',
        level: 'warning',
        title: 'Close to Life Support Margin',
        detail: 'Less than 20% contingency oxygen remaining for abort return.',
      });
    }

    if (!los) {
      warnings.push({
        id: 'los-warn',
        level: 'warning',
        title: 'Direct Habitat Comms Shadow',
        detail: 'Topographic ridge obstructs direct line-of-sight. Relay through Mars Reconnaissance Orbiter required.',
      });
    }

    return {
      totalDistanceKm: Number(totalDistKm.toFixed(2)),
      estimatedDurationHours: estHours,
      maxSlopeDeg: Number(maxSlope.toFixed(1)),
      meanSlopeDeg: Number(meanSlope.toFixed(1)),
      elevationGainM: 140,
      elevationLossM: 85,
      temperatureRangeC: { min: -75, max: -22 },
      radiationDoseRateMGyDay: 0.64,
      habitatDistanceKm: habDistKm,
      habitatLosMaintained: los,
      warnings,
    };
  }, [waypoints, evaSpeedKmh, evaTimeLimitHours, evaMode]);

  return (
    <div className="space-y-4">
      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="p-3 rounded-xl bg-space-950/60 border border-white/10">
          <div className="text-[11px] text-white/50 uppercase font-mono">Traverse Distance</div>
          <div className="text-xl font-display font-bold text-white mt-0.5">
            {metrics.totalDistanceKm} <span className="text-xs font-normal text-white/50">km</span>
          </div>
          <div className="text-[10px] text-white/40 mt-1">
            Hab Distance: {metrics.habitatDistanceKm} km
          </div>
        </div>

        <div className="p-3 rounded-xl bg-space-950/60 border border-white/10">
          <div className="text-[11px] text-white/50 uppercase font-mono">Estimated EVA Duration</div>
          <div className="text-xl font-display font-bold text-white mt-0.5">
            {metrics.estimatedDurationHours} <span className="text-xs font-normal text-white/50">hrs</span>
          </div>
          <div className="text-[10px] text-white/40 mt-1">
            Budget: {evaTimeLimitHours} hrs max
          </div>
        </div>

        <div className="p-3 rounded-xl bg-space-950/60 border border-white/10">
          <div className="text-[11px] text-white/50 uppercase font-mono">Terrain Slopes</div>
          <div className="text-base font-semibold text-white mt-0.5">
            Max: <span className={metrics.maxSlopeDeg > 20 ? 'text-rose-400' : 'text-white'}>{metrics.maxSlopeDeg}°</span>
            <span className="text-white/40 font-normal text-xs ml-2">Mean: {metrics.meanSlopeDeg}°</span>
          </div>
          <div className="text-[10px] text-white/40 mt-1">
            Limit: 30° suit mobility limit
          </div>
        </div>

        <div className="p-3 rounded-xl bg-space-950/60 border border-white/10">
          <div className="text-[11px] text-white/50 uppercase font-mono">Habitat Comms (LOS)</div>
          <div className="text-sm font-semibold mt-0.5 flex items-center gap-1.5">
            <span
              className={`w-2 h-2 rounded-full ${
                metrics.habitatLosMaintained ? 'bg-emerald-400' : 'bg-amber-400'
              }`}
            />
            <span className={metrics.habitatLosMaintained ? 'text-emerald-300' : 'text-amber-300'}>
              {metrics.habitatLosMaintained ? 'Direct LOS Maintained' : 'Relay Required'}
            </span>
          </div>
          <div className="text-[10px] text-white/40 mt-1">
            Direct RF line-of-sight check
          </div>
        </div>
      </div>

      {/* Environmental Baseline Card */}
      <div className="p-3 rounded-xl bg-space-950/80 border border-white/10 text-xs space-y-2">
        <div className="flex items-center justify-between text-white/80 font-medium">
          <span>In-Situ Environmental Conditions</span>
          <span className="text-[10px] font-mono text-white/40">Real PDS Archival Baseline</span>
        </div>
        <div className="grid grid-cols-2 gap-2 text-[11px] text-white/70">
          <div>
            🌡️ Surface Temp:{' '}
            <span className="text-white font-mono">
              {metrics.temperatureRangeC.min}°C to {metrics.temperatureRangeC.max}°C
            </span>
          </div>
          <div>
            ☢️ Radiation:{' '}
            <span className="text-white font-mono">~0.64 mGy/day</span>
          </div>
        </div>
        <div className="text-[10px] text-white/40 leading-relaxed">
          Source: Curiosity MSL REMS/RAD & InSight TWINS archival data. Actual solar flare activity can increase ionizing dosage.
        </div>
      </div>

      {/* Warnings & Alerts List */}
      {metrics.warnings.length > 0 && (
        <div className="space-y-2">
          <div className="text-xs font-mono uppercase tracking-wider text-amber-400/90 flex items-center gap-1.5">
            <span>⚠️</span> Active Hazard Warnings ({metrics.warnings.length})
          </div>
          {metrics.warnings.map((w) => (
            <div
              key={w.id}
              className={`p-3 rounded-xl border text-xs leading-relaxed ${
                w.level === 'critical'
                  ? 'bg-rose-950/50 border-rose-500/40 text-rose-200'
                  : 'bg-amber-950/40 border-amber-500/30 text-amber-200'
              }`}
            >
              <div className="font-semibold flex items-center gap-1.5 mb-0.5">
                <span>{w.level === 'critical' ? '🔴' : '🟡'}</span>
                <span>{w.title}</span>
              </div>
              <div className="text-white/70 text-[11px]">{w.detail}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
