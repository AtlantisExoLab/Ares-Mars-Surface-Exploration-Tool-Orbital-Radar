import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import type { LayerConfig } from '../../globe/MarsImagery';
import { OpacitySlider } from './OpacitySlider';

interface Props {
  layerId: string;
  config: LayerConfig;
  isVisible: boolean;
  opacity: number; // 0–100
  onToggle: () => void;
  onOpacityChange: (v: number) => void;
  onInfoClick: () => void;
}

/** Distinct badge styles per layer type */
const TYPE_STYLES: Record<string, { bg: string; text: string; border: string }> = {
  optical: { bg: 'bg-sky-500/20', text: 'text-sky-300', border: 'border-sky-400/40' },
  topographic: { bg: 'bg-lime-500/20', text: 'text-lime-300', border: 'border-lime-400/40' },
  thermal: { bg: 'bg-amber-500/20', text: 'text-amber-300', border: 'border-amber-400/40' },
  geophysical: { bg: 'bg-purple-500/20', text: 'text-purple-300', border: 'border-purple-400/40' },
};

export const LayerToggle: React.FC<Props> = ({
  layerId,
  config,
  isVisible,
  opacity,
  onToggle,
  onOpacityChange,
  onInfoClick,
}) => {
  const typeStyle = TYPE_STYLES[config.type] ?? {
    bg: 'bg-slate-700/40',
    text: 'text-slate-200',
    border: 'border-slate-600',
  };

  return (
    <div
      className={`rounded-xl p-3.5 transition-all shadow-md select-none ${
        isVisible
          ? 'bg-[#151c2c] border-2 border-mars-500/50 shadow-[0_4px_16px_rgba(0,0,0,0.5)]'
          : 'bg-[#101522] border border-slate-700/80 hover:border-slate-500/80 hover:bg-[#141b2a]'
      }`}
    >
      {/* Top Row: Clickable Header to Toggle */}
      <div className="flex items-center justify-between gap-3">
        {/* Toggle Button & Title Area */}
        <button
          onClick={onToggle}
          className="flex-1 flex items-center gap-3 text-left focus:outline-none group"
          aria-label={isVisible ? `Disable ${config.name}` : `Enable ${config.name}`}
        >
          {/* Custom Toggle Switch */}
          <div
            className={`w-10 h-5 rounded-full transition-colors relative flex items-center p-0.5 flex-shrink-0 ${
              isVisible ? 'bg-mars-500' : 'bg-slate-700 group-hover:bg-slate-600'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white shadow-md transform transition-transform ${
                isVisible ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </div>

          {/* Name & Type Badge */}
          <div className="min-w-0 flex-1">
            <div className="text-[13px] font-bold text-white tracking-wide truncate group-hover:text-mars-200 transition-colors">
              {config.name}
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              <span
                className={`text-[10px] font-semibold px-2 py-0.2 rounded-full border uppercase tracking-wider ${typeStyle.bg} ${typeStyle.text} ${typeStyle.border}`}
              >
                {config.type}
              </span>
              <span className="text-[11px] font-mono text-slate-300 font-medium">
                {config.resolution}
              </span>
            </div>
          </div>
        </button>

        {/* Info / Metadata Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onInfoClick();
          }}
          className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors flex-shrink-0 border border-slate-600/60"
          title={`View scientific details for ${config.name}`}
          aria-label={`Info for ${config.name}`}
        >
          <span className="text-xs font-bold">ℹ</span>
        </button>
      </div>

      {/* Description Preview */}
      <p className="mt-2 text-[11px] text-slate-300 leading-relaxed font-sans line-clamp-2">
        {config.description}
      </p>

      {/* Expandable Opacity Controls when Visible */}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            key="opacity-row"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden pt-3 mt-2.5 border-t border-slate-700/60"
          >
            <div className="flex items-center justify-between text-xs font-mono text-slate-200 mb-1.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                Layer Opacity
              </span>
              <span className="text-mars-400 font-bold">{Math.round(opacity)}%</span>
            </div>
            <OpacitySlider
              id={`opacity-${layerId}`}
              value={opacity}
              onChange={onOpacityChange}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default LayerToggle;
