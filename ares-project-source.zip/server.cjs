/**
 * server.cjs
 *
 * Secure zero-dependency Node.js backend for ARES MISSION INTELLIGENCE.
 * Serves grounded telemetry endpoints for Mars landing sites, orbital mechanics,
 * remote-sensing catalogs, and interactive AI queries.
 *
 * Run: node backend/server.cjs
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3001;
const LANDING_SITES_PATH = path.join(__dirname, '..', 'public', 'data', 'landing-sites.json');
const GAZETTEER_PATH = path.join(__dirname, '..', 'public', 'data', 'gazetteer-features.json');

// Cache datasets in memory
let landingSites = [];
let gazetteerFeatures = [];

try {
  if (fs.existsSync(LANDING_SITES_PATH)) {
    landingSites = JSON.parse(fs.readFileSync(LANDING_SITES_PATH, 'utf-8'));
  }
  if (fs.existsSync(GAZETTEER_PATH)) {
    gazetteerFeatures = JSON.parse(fs.readFileSync(GAZETTEER_PATH, 'utf-8'));
  }
} catch (err) {
  console.error('Error loading initial datasets:', err);
}

// NASA GISS Mars24 Timing calculations (server-side)
function getMarsSolDate(date = new Date()) {
  const timeMs = date.getTime();
  const jdUT = 2440587.5 + timeMs / 86400000;
  const jdTT = jdUT + 69.184 / 86400;
  const deltaJ2000 = jdTT - 2451545.0;
  return (deltaJ2000 - 4.5) / 1.027491252 + 44796.0 - 0.00096;
}

function getSolarLongitude(msd) {
  const m = (19.3870 + 0.52402075 * (msd - 51549.0)) % 360.0;
  const mRad = (m * Math.PI) / 180.0;
  const pbs =
    0.0071 * Math.cos((0.998647 * (msd - 51549.0) * Math.PI) / 180.0) +
    0.0057 * Math.cos((0.500000 * (msd - 51549.0) * Math.PI) / 180.0);
  const nuM =
    (10.691 + 3.0 * (1.0 / 100000.0) * (msd - 51549.0)) * Math.sin(mRad) +
    0.623 * Math.sin(2.0 * mRad) +
    0.050 * Math.sin(3.0 * mRad) +
    0.005 * Math.sin(4.0 * mRad) +
    pbs;
  const ls = (270.3863 + 0.52403840 * (msd - 51549.0) + nuM) % 360.0;
  return (ls + 360.0) % 360.0;
}

// Security headers helper
function setSecurityHeaders(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.setHeader('Content-Type', 'application/json');
}

// Request dispatcher
const server = http.createServer((req, res) => {
  setSecurityHeaders(res);

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  // 1. Health check
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/api/health')) {
    res.writeHead(200);
    res.end(
      JSON.stringify({
        status: 'ok',
        service: 'ARES MISSION INTELLIGENCE API',
        version: '2.0.0',
        datasets: {
          landingSites: landingSites.length,
          gazetteerFeatures: gazetteerFeatures.length,
        },
        timestamp: new Date().toISOString(),
      })
    );
    return;
  }

  // 2. Landing sites endpoint
  if (req.method === 'GET' && url.pathname === '/api/sites') {
    res.writeHead(200);
    res.end(JSON.stringify(landingSites));
    return;
  }

  // 3. Mars telemetry endpoint
  if (req.method === 'GET' && url.pathname === '/api/telemetry') {
    const msd = getMarsSolDate();
    const ls = getSolarLongitude(msd);
    res.writeHead(200);
    res.end(
      JSON.stringify({
        marsSolDate: msd,
        solarLongitude: ls,
        timestamp: new Date().toISOString(),
      })
    );
    return;
  }

  // 4. Grounded Chat Query endpoint
  if (req.method === 'POST' && url.pathname === '/api/chat') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 1024 * 64) {
        // 64KB max request payload limit
        req.destroy();
      }
    });

    req.on('end', () => {
      try {
        const payload = JSON.parse(body || '{}');
        const query = (payload.query || payload.prompt || '').trim();
        const geminiApiKey = (payload.apiKey || process.env.GEMINI_API_KEY || '').trim();

        // If Gemini API key is present, query Google Gemini API
        if (geminiApiKey && query) {
          const geminiReqBody = JSON.stringify({
            system_instruction: {
              parts: [{
                text: "You are the ARES Mars Mission AI, a specialized scientific assistant embedded within the ARES Mars Surface Exploration Tool. Provide authoritative, scientifically accurate explanations about Mars missions, rovers (Perseverance, Curiosity, Zhurong, Spirit, Opportunity, Viking), landers, orbiters, moons (Phobos, Deimos), and surface geology. Format your answers with clear Markdown."
              }]
            },
            contents: [{ role: 'user', parts: [{ text: query }] }],
            generationConfig: { temperature: 0.7, maxOutputTokens: 1024 }
          });

          const geminiReq = https.request({
            hostname: 'generativelanguage.googleapis.com',
            path: `/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiApiKey}`,
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Content-Length': Buffer.byteLength(geminiReqBody)
            }
          }, (geminiRes) => {
            let geminiData = '';
            geminiRes.on('data', (d) => { geminiData += d; });
            geminiRes.on('end', () => {
              try {
                const parsed = JSON.parse(geminiData);
                const replyText = parsed?.candidates?.[0]?.content?.parts?.[0]?.text;
                if (replyText) {
                  res.writeHead(200);
                  res.end(JSON.stringify({ content: replyText, source: 'gemini' }));
                  return;
                }
              } catch (e) {
                // fall through to local fallback
              }
              // Fallback
              handleLocalChat(query.toLowerCase(), res);
            });
          });

          geminiReq.on('error', () => {
            handleLocalChat(query.toLowerCase(), res);
          });

          geminiReq.write(geminiReqBody);
          geminiReq.end();
          return;
        }

        handleLocalChat(query.toLowerCase(), res);
      } catch (err) {
        res.writeHead(400);
        res.end(JSON.stringify({ error: 'Invalid JSON request payload', details: err.message }));
      }
    });
    return;
  }

  // 5. Image Download Proxy endpoint (enables in-app downloading without CORS restrictions)
  if (req.method === 'GET' && url.pathname === '/api/download-image') {
    const targetUrl = url.searchParams.get('url');
    let filename = url.searchParams.get('filename') || 'mars_rover_image.jpg';
    if (!filename.match(/\.(jpg|jpeg|png)$/i)) {
      filename += '.jpg';
    }

    if (!targetUrl || !targetUrl.startsWith('http')) {
      res.writeHead(400);
      res.end(JSON.stringify({ error: 'Valid URL parameter required' }));
      return;
    }

    try {
      const parsedTarget = new URL(targetUrl);
      const client = parsedTarget.protocol === 'https:' ? https : http;

      client.get(targetUrl, (proxyRes) => {
        if (proxyRes.statusCode >= 300 && proxyRes.statusCode < 400 && proxyRes.headers.location) {
          const redirectClient = proxyRes.headers.location.startsWith('https') ? https : http;
          redirectClient.get(proxyRes.headers.location, (redirRes) => {
            res.writeHead(200, {
              'Content-Type': redirRes.headers['content-type'] || 'image/jpeg',
              'Content-Disposition': `attachment; filename="${filename}"`,
              'Access-Control-Allow-Origin': '*',
            });
            redirRes.pipe(res);
          }).on('error', (e) => {
            res.writeHead(500);
            res.end(JSON.stringify({ error: e.message }));
          });
          return;
        }

        res.writeHead(200, {
          'Content-Type': proxyRes.headers['content-type'] || 'image/jpeg',
          'Content-Disposition': `attachment; filename="${filename}"`,
          'Access-Control-Allow-Origin': '*',
        });
        proxyRes.pipe(res);
      }).on('error', (err) => {
        res.writeHead(500);
        res.end(JSON.stringify({ error: err.message }));
      });
    } catch (err) {
      res.writeHead(400);
      res.end(JSON.stringify({ error: 'Invalid URL', details: err.message }));
    }
    return;
  }

  // 404 Not Found
  res.writeHead(404);
  res.end(JSON.stringify({ error: 'Endpoint not found' }));
});

function handleLocalChat(query, res) {
  let reply = '';
  const sources = [];
  const actions = [];

  const site = landingSites.find(
    (s) =>
      query.includes(s.name.toLowerCase()) ||
      query.includes(s.id.toLowerCase()) ||
      query.includes(s.locationName.toLowerCase())
  );

  if (site) {
    reply = `### 🔴 ${site.name} (${site.agency}) — ${site.type}\n\n` +
      `**Status:** \`${site.status.toUpperCase()}\` | **Coordinates:** \`${site.lat}°N, ${site.lon}°E\` (${site.locationName})\n` +
      `**Landing Date:** ${site.landingDate}\n\n` +
      `#### 🎯 Primary Objectives:\n${site.objectives.map((o) => `- ${o}`).join('\n')}\n\n` +
      `#### 🔬 Instruments:\n${site.instruments.map((i) => `\`${i}\``).join(' • ')}\n\n` +
      `#### 🏆 Key Discoveries:\n${site.keyDiscoveries.slice(0, 3).map((d) => `- ${d}`).join('\n')}`;

    sources.push({
      id: site.id,
      name: `${site.name} Archive`,
      agency: site.agency,
      product: 'NASA PDS / Official Mission Records',
      url: site.officialUrl,
    });
  } else if (query.includes('phobos') || query.includes('deimos') || query.includes('moon')) {
    reply = `### 🛰️ Martian Natural Satellites (Moons)\n\n` +
      `- **Phobos:** Altitude ~5,980 km, Period 7.65 hrs, Dimensions 26.8 × 22.4 × 18.4 km. Orbits faster than Mars rotates.\n` +
      `- **Deimos:** Altitude ~20,060 km, Period 30.3 hrs, Dimensions 15.0 × 12.2 × 10.4 km.\n\n` +
      `*Both trajectories simulated via 3D Keplerian orbital mechanics in ARES.*`;

    sources.push({
      id: 'horizons',
      name: 'NASA JPL Horizons Ephemeris',
      agency: 'NASA JPL',
      product: 'Martian Satellite Ephemeris',
      url: 'https://ssd.jpl.nasa.gov/horizons/',
    });
  } else {
    const msd = getMarsSolDate();
    const ls = getSolarLongitude(msd);
    reply = `### 🤖 ARES MARS AI // Grounded Knowledge\n\n` +
      `**Current Mars Sol Date:** \`${msd.toFixed(4)}\` | **$L_s$:** \`${ls.toFixed(2)}°\`\n\n` +
      `ARES maintains verified scientific catalogs for **${landingSites.length} verified surface sites**, **${gazetteerFeatures.length} IAU landmarks**, and **9 orbital bodies**.\n\n` +
      `- **Surface Explorations:** Ask about Perseverance (Jezero Crater), Curiosity (Gale Crater / Mount Sharp), Zhurong (Utopia Planitia), or Viking 1 & 2.\n` +
      `- **Orbital Fleet:** Track Phobos, Deimos, MRO, ExoMars TGO, and Mars Express.\n` +
      `- **Planetary Systems:** Inquire about MOXIE oxygen generation, Ingenuity atmospheric flight, radiation, or topography.`;

    sources.push({
      id: 'ares-node-backend',
      name: 'ARES Planetary Knowledge Database',
      agency: 'NASA / USGS / ESA / CNSA',
      product: 'Ares Mission Intelligence Engine v2.0',
    });
  }

  res.writeHead(200);
  res.end(JSON.stringify({ content: reply, sources, actions }));
}

server.listen(PORT, () => {
  console.log(`[ARES AI Backend] Running on http://localhost:${PORT}`);
  console.log(`[ARES AI Backend] Loaded ${landingSites.length} landing sites and ${gazetteerFeatures.length} IAU features.`);
});
