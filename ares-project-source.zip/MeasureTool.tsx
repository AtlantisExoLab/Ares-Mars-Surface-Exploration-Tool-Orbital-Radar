/**
 * MeasureTool.tsx
 *
 * Robust, high-precision Mars surface distance measurement tool.
 * Enables astronauts and operators to click/tap points across Mars,
 * calculates true planetocentric geodesic surface distances across the Martian ellipsoid,
 * and renders glowing polylines and segment coordinate badges with trackpad-proof event handling.
 */

import React, { useState, useEffect, useRef } from 'react';
import * as Cesium from 'cesium';
import { useGlobeStore } from '../../store/globeStore';
import { measureDistance } from '../../globe/CameraController';
import { formatMarsCoords, formatElevation, cesiumLonToMars } from '../../globe/CoordinateUtils';

interface MeasureToolProps {
  viewer: Cesium.Viewer;
}

const MARS_ELLIPSOID = new Cesium.Ellipsoid(3_396_190, 3_396_190, 3_376_200);

export const MeasureTool: React.FC<MeasureToolProps> = ({ viewer }) => {
  const isMeasuring = useGlobeStore((s) => s.isMeasuring);
  const toggleMeasure = useGlobeStore((s) => s.toggleMeasure);

  const [points, setPoints] = useState<{ carto: Cesium.Cartographic; cartesian: Cesium.Cartesian3; lat: number; lon: number; elev: number }[]>([]);
  const [totalMeters, setTotalMeters] = useState(0);

  const entityIdsRef = useRef<string[]>([]);

  // Clear all measurement entities
  const clearEntities = () => {
    entityIdsRef.current.forEach((id) => {
      const e = viewer.entities.getById(id);
      if (e) viewer.entities.remove(e);
    });
    entityIdsRef.current = [];
  };

  const handleClear = () => {
    clearEntities();
    setPoints([]);
    setTotalMeters(0);
    viewer.scene.requestRender();
  };

  const handleExit = () => {
    clearEntities();
    setPoints([]);
    setTotalMeters(0);
    toggleMeasure();
    viewer.scene.requestRender();
  };

  // Add a measured point on Mars
  const addPoint = (cartesian: Cesium.Cartesian3) => {
    const carto = Cesium.Cartographic.fromCartesian(cartesian, MARS_ELLIPSOID);
    const lat = Cesium.Math.toDegrees(carto.latitude);
    const lon = cesiumLonToMars(Cesium.Math.toDegrees(carto.longitude));
    const elev = Math.round(carto.height);

    setPoints((prev) => {
      const next = [...prev, { carto, cartesian, lat, lon, elev }];
      const dist = measureDistance(viewer, next.map((p) => p.carto));
      setTotalMeters(dist);

      const ptLetter = String.fromCharCode(65 + (next.length - 1));
      const ptId = `measure-marker-${next.length}-${Date.now()}`;

      // Elevated position (+1200m) so pins never clip through terrain
      const elevatedPos = Cesium.Cartesian3.fromRadians(
        carto.longitude,
        carto.latitude,
        carto.height + 1500,
        MARS_ELLIPSOID,
      );

      viewer.entities.add({
        id: ptId,
        position: elevatedPos,
        point: {
          pixelSize: 12,
          color: Cesium.Color.fromCssColorString('#38bdf8'),
          outlineColor: Cesium.Color.WHITE,
          outlineWidth: 2.5,
          disableDepthTestDistance: Number.POSITIVE_INFINITY,
        },
        label: {
          text: `Point ${ptLetter}\n${formatMarsCoords(lat, lon)} (${formatElevation(elev)})`,
          font: 'bold 11px "Inter", sans-serif',
          fillColor: Cesium.Color.WHITE,
          outlineColor: Cesium.Color.BLACK,
          outlineWidth: 3,
          style: Cesium.LabelStyle.FILL_AND_OUTLINE,
          showBackground: true,
          backgroundColor: Cesium.Color.fromCssColorString('rgba(10, 15, 25, 0.88)'),
          backgroundPadding: new Cesium.Cartesian2(6, 4),
          pixelOffset: new Cesium.Cartesian2(0, -32),
          disableDepthTestDistance: Number.POSITIVE_INFINITY,
        },
      });
      entityIdsRef.current.push(ptId);

      // If >= 2 points, draw / update geodesic polyline
      if (next.length >= 2) {
        const lineId = 'measure-active-line';
        const existingLine = viewer.entities.getById(lineId);
        if (existingLine) viewer.entities.remove(existingLine);

        // Slightly elevate polyline points (+1500m) so the great-circle arc
        // renders cleanly across the Mars ellipsoid without GroundPolyline errors
        const linePositions = next.map((p) =>
          Cesium.Cartesian3.fromRadians(
            p.carto.longitude,
            p.carto.latitude,
            p.carto.height + 1500,
            MARS_ELLIPSOID,
          )
        );

        viewer.entities.add({
          id: lineId,
          polyline: {
            positions: linePositions,
            width: 3.5,
            material: new Cesium.PolylineGlowMaterialProperty({
              glowPower: 0.35,
              color: Cesium.Color.fromCssColorString('#38bdf8'),
            }),
            arcType: Cesium.ArcType.GEODESIC,
          },
        });
        if (!entityIdsRef.current.includes(lineId)) {
          entityIdsRef.current.push(lineId);
        }
      }

      viewer.scene.requestRender();
      return next;
    });
  };

  useEffect(() => {
    if (!isMeasuring || !viewer?.scene?.canvas) {
      clearEntities();
      setPoints([]);
      setTotalMeters(0);
      return;
    }

    const canvas = viewer.scene.canvas;
    canvas.style.cursor = 'crosshair';

    // Trackpad-proof Pointer event listener: detects clicks even with slight touchpad finger shifts
    let startX = 0;
    let startY = 0;
    let isPointerDown = false;

    const handlePointerDown = (e: PointerEvent) => {
      if (e.button !== 0) return; // only left click
      startX = e.clientX;
      startY = e.clientY;
      isPointerDown = true;
    };

    const handlePointerUp = (e: PointerEvent) => {
      if (!isPointerDown) return;
      isPointerDown = false;

      // Distance moved between down and up (allow up to 8px movement for laptop trackpad tap tolerance)
      const distMoved = Math.hypot(e.clientX - startX, e.clientY - startY);
      if (distMoved > 8) return; // user dragged to pan camera, ignore

      const rect = canvas.getBoundingClientRect();
      const winPos = new Cesium.Cartesian2(e.clientX - rect.left, e.clientY - rect.top);

      const ray = viewer.camera.getPickRay(winPos);
      if (!ray) return;

      let cartesian = viewer.scene.globe.pick(ray, viewer.scene);
      if (!cartesian) {
        cartesian = viewer.camera.pickEllipsoid(winPos, MARS_ELLIPSOID);
      }

      if (cartesian) {
        addPoint(cartesian);
      }
    };

    canvas.addEventListener('pointerdown', handlePointerDown);
    canvas.addEventListener('pointerup', handlePointerUp);

    return () => {
      canvas.style.cursor = '';
      canvas.removeEventListener('pointerdown', handlePointerDown);
      canvas.removeEventListener('pointerup', handlePointerUp);
    };
  }, [isMeasuring, viewer]);

  if (!isMeasuring) return null;

  const totalKm = (totalMeters / 1000).toFixed(2);
  const totalMi = (totalMeters / 1609.34).toFixed(2);

  return (
    <div className="fixed top-20 right-16 z-40 pointer-events-auto select-none">
      <div className="w-80 md:w-88 rounded-2xl bg-[#090d16] border-2 border-sky-400/80 shadow-[0_8px_32px_rgba(0,0,0,0.85)] p-4 text-white flex flex-col gap-3">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-700/80">
          <div className="flex items-center gap-2">
            <span className="text-lg">📏</span>
            <h3 className="font-display font-bold text-sm tracking-wide text-white">
              Surface Distance Tool
            </h3>
          </div>
          <button
            onClick={handleExit}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
            title="Exit measurement"
            aria-label="Exit measurement"
          >
            ✕
          </button>
        </div>

        {/* Guidance Prompt */}
        <div className="p-2.5 rounded-xl bg-[#111726] border border-sky-500/30 text-xs">
          {points.length === 0 && (
            <div className="flex items-center gap-2 text-sky-300 font-medium">
              <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping flex-shrink-0" />
              <span>Click anywhere on Mars to place <strong>Point A</strong></span>
            </div>
          )}
          {points.length === 1 && (
            <div className="flex items-center gap-2 text-amber-300 font-medium">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse flex-shrink-0" />
              <span>Point A set. Click a second location for <strong>Point B</strong></span>
            </div>
          )}
          {points.length >= 2 && (
            <div className="flex items-center gap-2 text-emerald-300 font-medium">
              <span>✓</span>
              <span>Distance measured. Click further points to extend path.</span>
            </div>
          )}
        </div>

        {/* Measurement Readouts */}
        {points.length >= 2 && (
          <div className="p-3 rounded-xl bg-[#0d1320] border border-slate-700 flex flex-col gap-1.5 font-mono">
            <div className="text-[11px] text-slate-400 uppercase tracking-wider">
              Geodesic Surface Distance
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-sky-300 tracking-tight">
                {totalKm}
              </span>
              <span className="text-sm font-semibold text-sky-400">km</span>
              <span className="text-xs text-slate-400 ml-auto">
                ({totalMi} miles)
              </span>
            </div>
          </div>
        )}

        {/* Points List */}
        {points.length > 0 && (
          <div className="space-y-1.5 max-h-36 overflow-y-auto text-xs font-mono">
            {points.map((p, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-1.5 rounded-lg bg-[#141b2a] border border-slate-700/60"
              >
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-sky-500/30 text-sky-300 font-bold flex items-center justify-center text-[10px]">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="text-slate-200">{formatMarsCoords(p.lat, p.lon)}</span>
                </div>
                <span className="text-slate-400">{formatElevation(p.elev)}</span>
              </div>
            ))}
          </div>
        )}

        {/* Action Controls */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-700/80">
          <button
            onClick={handleClear}
            disabled={points.length === 0}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-medium text-slate-200 transition-colors"
          >
            Clear Points
          </button>
          <button
            onClick={handleExit}
            className="px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs transition-colors shadow-lg shadow-sky-900/40"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

export default MeasureTool;
