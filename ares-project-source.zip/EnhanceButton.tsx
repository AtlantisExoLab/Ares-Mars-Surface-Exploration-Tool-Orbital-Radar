/**
 * EnhanceButton.tsx
 * Floating AI Enhance button with real-time progress indicator, state transitions,
 * and invocation of the Before/After comparison modal.
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGlobeStore } from '../../store/globeStore';
import { captureViewerCanvas, enhanceImageryCanvas, type EnhancementTier } from './OnnxEnhancer';
import { BeforeAfterSlider } from './BeforeAfterSlider';

export const EnhanceButton: React.FC = () => {
  const viewer = useGlobeStore((s) => s.viewer);
  const [status, setStatus] = useState<'idle' | 'processing' | 'ready'>('idle');
  const [progress, setProgress] = useState(0);
  const [showSlider, setShowSlider] = useState(false);
  const [originalUrl, setOriginalUrl] = useState<string | null>(null);
  const [enhancedUrl, setEnhancedUrl] = useState<string | null>(null);
  const [tierLabel, setTierLabel] = useState<string>('');

  const handleEnhance = async () => {
    if (!viewer) return;
    setStatus('processing');
    setProgress(10);

    try {
      const snap = captureViewerCanvas(viewer);
      if (!snap) {
        throw new Error('Unable to capture viewport');
      }

      const origData = snap.toDataURL('image/jpeg', 0.92);
      setOriginalUrl(origData);

      const result = await enhanceImageryCanvas(snap, (pct) => {
        setProgress(pct);
      });

      const enhData = result.canvas.toDataURL('image/jpeg', 0.95);
      setEnhancedUrl(enhData);
      setTierLabel(result.tierLabel);
      setStatus('ready');
      setShowSlider(true);
    } catch (err) {
      console.error('[EnhanceButton] Error during enhancement:', err);
      setStatus('idle');
    }
  };

  return (
    <>
      <div className="fixed bottom-12 left-20 z-20 flex items-center gap-2 pointer-events-auto">
        {status === 'idle' && (
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            onClick={handleEnhance}
            className="flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-space-800/80 hover:bg-space-700/90 text-white font-medium text-xs tracking-wide border border-white/15 backdrop-blur-md shadow-lg transition-all"
            title="Enhance current viewport with AI super-resolution and denoising"
          >
            <span className="text-amber-400 text-sm">✨</span>
            <span>Enhance Map with AI</span>
          </motion.button>
        )}

        {status === 'processing' && (
          <div className="flex items-center gap-3 px-4 py-2 rounded-xl bg-space-900/90 border border-amber-400/40 backdrop-blur-md shadow-lg text-xs text-white">
            <div className="w-4 h-4 border-2 border-amber-400/30 border-t-amber-400 rounded-full animate-spin" />
            <span>AI Super-Resolution ({progress}%)</span>
          </div>
        )}

        {status === 'ready' && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowSlider(true)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-400/40 text-xs font-medium backdrop-blur-md transition-colors"
            >
              <span>🔍 Compare Before / After</span>
            </button>
            <button
              onClick={() => {
                setStatus('idle');
                setShowSlider(false);
              }}
              className="px-2.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white/70 hover:text-white text-xs border border-white/10 backdrop-blur-md transition-colors"
              title="Reset to default unaltered NASA data"
            >
              Reset
            </button>
          </div>
        )}
      </div>

      <AnimatePresence>
        {showSlider && originalUrl && enhancedUrl && (
          <BeforeAfterSlider
            originalDataUrl={originalUrl}
            enhancedDataUrl={enhancedUrl}
            tierLabel={tierLabel}
            onClose={() => setShowSlider(false)}
          />
        )}
      </AnimatePresence>
    </>
  );
};
