/**
 * Step2Objective.tsx
 * Mission Planner Step 2: Primary Science Objective Selection.
 */

import React from 'react';
import { useGlobeStore } from '../../../store/globeStore';
import { usePlannerStore } from '../../../store/plannerStore';
import { flyTo } from '../../../globe/CameraController';

export const Step2Objective: React.FC = () => {
  const viewer = useGlobeStore((s) => s.viewer);
  const objective = usePlannerStore((s) => s.objective);
  const setObjective = usePlannerStore((s) => s.setObjective);
  const setBaseLocation = usePlannerStore((s) => s.setBaseLocation);

  const scienceObjectives = [
    {
      id: 'boxwork',
      title: 'Boxwork Mineral Formations',
      icon: '🔬',
      summary: 'Investigate polygonal groundwater cementation ridges discovered by Curiosity (2025).',
      candidates: [
        { name: 'Gale Crater (Mount Sharp Gediz Ridge)', lat: -4.68, lon: 137.38 },
      ],
      recommendedLayers: ['ctx-mosaic', 'themis-night-ir', 'crism-hydrated'],
    },
    {
      id: 'river-delta',
      title: 'Ancient River Delta & Biosignatures',
      icon: '🌊',
      summary: 'Search for fossilized organic compounds preserved in smectite clay delta mudstones.',
      candidates: [
        { name: 'Jezero Crater Western Delta', lat: 18.45, lon: 77.45 },
        { name: 'Eberswalde Crater Delta', lat: -23.86, lon: 326.74 },
      ],
      recommendedLayers: ['ctx-mosaic', 'crism-hydrated', 'mola-shaded-relief'],
    },
    {
      id: 'sulfate-clay',
      title: 'Sulfate / Clay Stratigraphy Transition',
      icon: '🪨',
      summary: 'Examine the fundamental climatic drying transition from warm-wet Mars to cold-arid Mars.',
      candidates: [
        { name: 'Mawrth Vallis Layered Clays', lat: 23.99, lon: 341.04 },
      ],
      recommendedLayers: ['crism-hydrated', 'crism-fe-mineral', 'themis-day-ir'],
    },
    {
      id: 'volcanic',
      title: 'Volcanic Calderas & Subsurface Lava Tubes',
      icon: '🌋',
      summary: 'Map collapsed lava tube skylights for potential astronaut habitat shielding against radiation.',
      candidates: [
        { name: 'Pavonis Mons Lava Tube Skylights', lat: 0.8, lon: 246.6 },
        { name: 'Olympus Mons Basal Scarp', lat: 18.65, lon: 226.2 },
      ],
      recommendedLayers: ['mola-shaded-relief', 'themis-night-ir', 'ctx-mosaic'],
    },
    {
      id: 'polar-ice',
      title: 'Perennial Polar Ice & Clathrates',
      icon: '🧊',
      summary: 'Sample layered deposits of H2O and CO2 ice to reconstruct Martian paleoclimate cycles.',
      candidates: [
        { name: 'Planum Boreum (North Polar Chasma)', lat: 84.5, lon: 0.0 },
      ],
      recommendedLayers: ['themis-day-ir', 'mola-color-dem'],
    },
  ];

  const handleSelectCandidate = (name: string, lat: number, lon: number) => {
    setBaseLocation({ lat, lon, name });
    if (viewer) flyTo(viewer, lat, lon, 200, 2);
  };

  return (
    <div className="space-y-6 text-xs text-white/80">
      <div className="p-3.5 rounded-xl bg-space-800/60 border border-white/10 space-y-1">
        <div className="font-semibold text-white flex items-center gap-1.5">
          <span>🎯</span>
          <span>2. Select Primary Science Objective</span>
        </div>
        <p className="text-white/60 leading-relaxed text-[11px]">
          Choose the scientific goal of your surface traverse. Ares will recommend the best remote sensing datasets and candidate geological targets.
        </p>
      </div>

      {/* Objectives Grid */}
      <div className="space-y-3">
        {scienceObjectives.map((item) => {
          const isSelected = objective === item.id;
          return (
            <div
              key={item.id}
              onClick={() => setObjective(item.id)}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-mars-950/60 border-mars-500 shadow-lg ring-1 ring-mars-500/50'
                  : 'bg-space-800/40 border-white/10 hover:bg-space-800/70 hover:border-white/20'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <span className="text-xl select-none">{item.icon}</span>
                  <div>
                    <div className="font-semibold text-sm text-white">{item.title}</div>
                    <p className="text-[11px] text-white/60 mt-1 leading-relaxed">
                      {item.summary}
                    </p>
                  </div>
                </div>
                {isSelected && (
                  <span className="text-mars-400 font-bold text-sm">✓</span>
                )}
              </div>

              {/* Candidate sites under selected objective */}
              {isSelected && item.candidates.length > 0 && (
                <div className="mt-3 pt-3 border-t border-white/10">
                  <div className="text-[10px] uppercase font-mono text-white/40 mb-1.5">
                    Suggested High-Priority Sites:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {item.candidates.map((c) => (
                      <button
                        key={c.name}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectCandidate(c.name, c.lat, c.lon);
                        }}
                        className="px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/20 text-white text-[11px] font-medium flex items-center gap-1 transition-colors"
                      >
                        <span>📍 {c.name}</span>
                        <span className="text-mars-400 font-mono text-[10px]">Fly →</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
