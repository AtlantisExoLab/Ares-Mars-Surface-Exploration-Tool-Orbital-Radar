import React, { useEffect } from 'react';
import { motion, useReducedMotion, AnimatePresence } from 'framer-motion';

interface TitleRevealProps {
  onComplete: () => void;
}

const ARES_LETTERS = ['A', 'R', 'E', 'S'];

export const TitleReveal: React.FC<TitleRevealProps> = ({ onComplete }) => {
  const prefersReduced = useReducedMotion();

  useEffect(() => {
    // After subtitle + tagline animation settle (~3s total), call onComplete
    const timeout = window.setTimeout(onComplete, prefersReduced ? 100 : 3200);
    return () => clearTimeout(timeout);
  }, [onComplete, prefersReduced]);

  const letterVariants = {
    hidden: prefersReduced
      ? { opacity: 1, y: 0, filter: 'blur(0px)' }
      : { opacity: 0, y: 20, filter: 'blur(4px)' },
    visible: {
      opacity: 1,
      y: 0,
      filter: 'blur(0px)',
      transition: { duration: prefersReduced ? 0 : 0.6, ease: [0.16, 1, 0.3, 1] as const },
    },
  };

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: prefersReduced ? 0 : 0.08,
        delayChildren: prefersReduced ? 0 : 0.2,
      },
    },
  };

  const subtitleVariants = {
    hidden: { opacity: 0, letterSpacing: '0.5em' },
    visible: {
      opacity: 1,
      letterSpacing: '0.3em',
      transition: { duration: prefersReduced ? 0 : 0.8, delay: prefersReduced ? 0 : 0.7, ease: 'easeOut' as const },
    },
  };

  const taglineVariants = {
    hidden: { opacity: 0, y: 8 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: prefersReduced ? 0 : 0.7, delay: prefersReduced ? 0 : 1.6, ease: 'easeOut' as const },
    },
  };

  return (
    <div className="flex flex-col items-center justify-center select-none pointer-events-none">
      {/* ARES letters */}
      <motion.div
        className="flex gap-2 md:gap-4"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {ARES_LETTERS.map((letter) => (
          <motion.span
            key={letter}
            variants={letterVariants}
            style={{
              fontFamily: "'Space Grotesk', 'Inter', system-ui, sans-serif",
              fontWeight: 700,
              fontSize: 'clamp(72px, 12vw, 120px)',
              lineHeight: 1,
              color: '#fff',
              textShadow: '0 0 60px rgba(232,82,26,0.5), 0 0 120px rgba(232,82,26,0.2)',
              display: 'inline-block',
            }}
          >
            {letter}
          </motion.span>
        ))}
      </motion.div>

      {/* Subtitle */}
      <motion.p
        variants={subtitleVariants}
        initial="hidden"
        animate="visible"
        style={{
          fontFamily: "'Inter', system-ui, sans-serif",
          fontSize: 'clamp(10px, 1.6vw, 14px)',
          fontWeight: 500,
          color: 'rgba(255,255,255,0.65)',
          textTransform: 'uppercase',
          letterSpacing: '0.3em',
          marginTop: '1rem',
        }}
      >
        Mars Surface Exploration Tool
      </motion.p>

      {/* Divider line */}
      <motion.div
        initial={{ scaleX: 0, opacity: 0 }}
        animate={{ scaleX: 1, opacity: 1 }}
        transition={{ duration: prefersReduced ? 0 : 0.6, delay: prefersReduced ? 0 : 1.2, ease: [0.16, 1, 0.3, 1] }}
        style={{
          width: '200px',
          height: '1px',
          background: 'linear-gradient(90deg, transparent, rgba(232,82,26,0.6), transparent)',
          marginTop: '1.5rem',
          transformOrigin: 'center',
        }}
      />

      {/* Tagline */}
      <motion.p
        variants={taglineVariants}
        initial="hidden"
        animate="visible"
        style={{
          fontFamily: "'Inter', system-ui, sans-serif",
          fontSize: 'clamp(12px, 1.4vw, 15px)',
          color: 'rgba(255,255,255,0.45)',
          marginTop: '1rem',
          fontStyle: 'italic',
          textAlign: 'center',
        }}
      >
        Every mission. Every discovery. Navigate the Red Planet.
      </motion.p>
    </div>
  );
};
