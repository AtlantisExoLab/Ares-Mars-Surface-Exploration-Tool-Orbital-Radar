/**
 * MissionExport.ts
 * Export tools for the Astronaut Mission Planner:
 *  - GeoJSON standard format download for NASA GIS tools
 *  - PDF Mission Briefing document generation via jsPDF
 *  - Shareable URL generator
 */

import { jsPDF } from 'jspdf';
import type { SafetyMetrics } from '../../types/MissionTypes';

export function exportGeoJSON(
  missionName: string,
  waypoints: Array<{ lat: number; lon: number; label: string; note?: string }>,
  metadata: {
    objective: string;
    evaMode: string;
    totalKm: number;
    estimatedHours: number;
  }
): void {
  const geojson = {
    type: 'FeatureCollection',
    metadata: {
      generator: 'Ares Mars Mission Planner',
      timestamp: new Date().toISOString(),
      targetPlanet: 'Mars (Mars 2000 Planetocentric datum)',
      missionName,
      ...metadata,
    },
    features: [
      // LineString of the traverse
      {
        type: 'Feature',
        properties: {
          name: `${missionName} Traverse Path`,
          totalDistanceKm: metadata.totalKm,
          estimatedDurationHours: metadata.estimatedHours,
        },
        geometry: {
          type: 'LineString',
          // GeoJSON coordinates are [longitude, latitude]
          coordinates: waypoints.map((w) => [w.lon, w.lat]),
        },
      },
      // Individual point waypoints
      ...waypoints.map((w, index) => ({
        type: 'Feature',
        properties: {
          name: w.label,
          order: index + 1,
          note: w.note || '',
          elevationDatum: 'MOLA (Mars 2000)',
        },
        geometry: {
          type: 'Point',
          coordinates: [w.lon, w.lat],
        },
      })),
    ],
  };

  const blob = new Blob([JSON.stringify(geojson, null, 2)], {
    type: 'application/geo+json',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${missionName.toLowerCase().replace(/[^a-z0-9]/g, '-')}-traverse.geojson`;
  a.click();
  URL.revokeObjectURL(url);
}

export function exportPDFBrief(
  missionName: string,
  waypoints: Array<{ lat: number; lon: number; label: string; note?: string }>,
  metrics: SafetyMetrics,
  objective: string,
  baseLocationName: string
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  // Dark header
  doc.setFillColor(13, 20, 36);
  doc.rect(0, 0, 210, 40, 'F');

  // Title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('ARES // ASTRONAUT MISSION BRIEF', 15, 20);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(232, 82, 26);
  doc.text('NASA HUMAN EXPLORATION & SURFACE MOBILITY DIRECTIVE', 15, 28);

  doc.setTextColor(150, 160, 180);
  doc.text(`Generated: ${new Date().toUTCString()} · Mars 2000 Datum`, 15, 34);

  // Section: Mission Parameters
  doc.setTextColor(30, 40, 60);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('1. Mission Profile & Scientific Target', 15, 52);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Mission Plan: ${missionName}`, 15, 60);
  doc.text(`Base Location: ${baseLocationName}`, 15, 66);
  doc.text(`Primary Objective: ${objective}`, 15, 72);
  doc.text(`Traverse Distance: ${metrics.totalDistanceKm} km`, 15, 78);
  doc.text(`Estimated Duration: ${metrics.estimatedDurationHours} hours`, 15, 84);

  // Section: Environmental & Safety Assessment
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('2. Environmental & Mobility Safety Assessment', 15, 98);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Max Slope: ${metrics.maxSlopeDeg}° (Suit mobility limit: 30°)`, 15, 106);
  doc.text(`Mean Slope: ${metrics.meanSlopeDeg}°`, 15, 112);
  doc.text(
    `Direct Habitat Comms: ${metrics.habitatLosMaintained ? 'Direct Line-of-Sight Maintained' : 'Relay Satellite Required'}`,
    15,
    118
  );
  doc.text(
    `Radiation Baseline (MSL RAD): ~${metrics.radiationDoseRateMGyDay} mGy/day`,
    15,
    124
  );
  doc.text(
    `Surface Temperature Range: ${metrics.temperatureRangeC.min}°C to ${metrics.temperatureRangeC.max}°C`,
    15,
    130
  );

  // Section: Waypoint Manifest
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('3. Tactical Waypoint Manifest', 15, 145);

  let y = 153;
  waypoints.forEach((wp, idx) => {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(232, 82, 26);
    doc.text(`${idx + 1}. ${wp.label}`, 15, y);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(60, 70, 90);
    doc.text(
      `Coords: ${wp.lat >= 0 ? wp.lat + '°N' : Math.abs(wp.lat) + '°S'}, ${wp.lon}°E`,
      20,
      y + 5
    );
    if (wp.note) {
      doc.text(`Notes: ${wp.note}`, 20, y + 10);
      y += 16;
    } else {
      y += 12;
    }
  });

  // Footer
  doc.setFontSize(8);
  doc.setTextColor(140, 150, 160);
  doc.text(
    'Notice: Mission brief compiled via Ares Surface Navigation System using NASA Mars Trek, USGS Astrogeology, and PDS archival products.',
    15,
    285
  );

  doc.save(`${missionName.toLowerCase().replace(/[^a-z0-9]/g, '-')}-brief.pdf`);
}

export function generateShareUrl(state: {
  lat: number;
  lon: number;
  altKm: number;
  siteId?: string | null;
}): string {
  const params = new URLSearchParams();
  params.set('lat', state.lat.toFixed(4));
  params.set('lon', state.lon.toFixed(4));
  params.set('alt', state.altKm.toFixed(0));
  if (state.siteId) params.set('site', state.siteId);
  return `${window.location.origin}${window.location.pathname}#${params.toString()}`;
}
