/**
 * SearchAutocomplete.tsx
 * Dropdown list of autocomplete results with category tags, coordinates, and smooth navigation.
 */

import React from 'react';
import { motion } from 'framer-motion';
import type { SearchResultItem } from '../../data/gazeteerIndex';

interface SearchAutocompleteProps {
  results: SearchResultItem[];
  selectedIndex: number;
  onSelect: (item: SearchResultItem) => void;
}

export const SearchAutocomplete: React.FC<SearchAutocompleteProps> = ({
  results,
  selectedIndex,
  onSelect,
}) => {
  if (results.length === 0) return null;

  const getCategoryIcon = (category: string, type: string) => {
    if (category === 'Landing Site') return '📍';
    if (type.includes('Mons')) return '🏔️';
    if (type.includes('Crater')) return '🕳️';
    if (type.includes('Valles') || type.includes('Chasma')) return '🏜️';
    if (type.includes('Planitia') || type.includes('Planum')) return '🪐';
    return '🛰️';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -6 }}
      className="absolute top-full left-0 right-0 mt-2 rounded-xl bg-space-900/95 border border-white/15 backdrop-blur-xl shadow-2xl overflow-hidden z-50 max-h-96 overflow-y-auto"
    >
      <div className="py-1">
        {results.map((item, idx) => {
          const isSelected = idx === selectedIndex;
          const icon = getCategoryIcon(item.category, item.type);

          return (
            <button
              key={item.id}
              onClick={() => onSelect(item)}
              className={`w-full text-left px-4 py-2.5 flex items-start gap-3 transition-colors ${
                isSelected
                  ? 'bg-mars-600/30 text-white'
                  : 'text-white/80 hover:bg-white/10 hover:text-white'
              }`}
            >
              <span className="text-base mt-0.5 select-none">{icon}</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm text-white truncate">{item.name}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-white/60 uppercase tracking-wider font-mono">
                    {item.type}
                  </span>
                </div>
                <div className="text-xs text-white/50 truncate mt-0.5">
                  {item.description}
                </div>
                <div className="text-[10px] font-mono text-mars-400/80 mt-0.5">
                  {item.lat >= 0 ? `${item.lat.toFixed(2)}°N` : `${Math.abs(item.lat).toFixed(2)}°S`}
                  {' · '}
                  {item.lon.toFixed(2)}°E
                  {item.diameterKm ? ` · ⌀${item.diameterKm} km` : ''}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </motion.div>
  );
};
