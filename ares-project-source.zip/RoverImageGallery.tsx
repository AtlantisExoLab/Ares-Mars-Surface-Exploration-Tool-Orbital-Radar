/**
 * RoverImageGallery.tsx
 *
 * Live NASA Images API integration for surface rover photographs.
 * Sources: images-api.nasa.gov (NASA Image and Video Library)
 * Integrates Perseverance, Curiosity, Opportunity, Spirit surface imagery.
 *
 * Also links to the official Perseverance Raw Images Gallery:
 * https://mars.nasa.gov/mars2020/multimedia/raw-images/
 */

import React, { useState, useEffect } from 'react';
import type { LandingSite } from '../../types/MarsTypes';
import { useGlobeStore } from '../../store/globeStore';

interface NASAImage {
  id: string;
  title: string;
  description: string;
  thumb: string;
  date: string;
  nasaId: string;
}

interface RoverImageGalleryProps {
  site: LandingSite;
}

// Rover-specific search queries for NASA Images API
const ROVER_QUERIES: Record<string, { q: string; raw: string }> = {
  perseverance: {
    q: 'perseverance rover jezero mars surface sol',
    raw: 'https://mars.nasa.gov/mars2020/multimedia/raw-images/',
  },
  curiosity: {
    q: 'curiosity rover gale crater mars surface',
    raw: 'https://mars.nasa.gov/msl/multimedia/raw-images/',
  },
  opportunity: {
    q: 'opportunity rover meridiani mars surface panorama',
    raw: 'https://mars.nasa.gov/mer/gallery/all/',
  },
  spirit: {
    q: 'spirit rover gusev crater columbia hills mars',
    raw: 'https://mars.nasa.gov/mer/gallery/all/',
  },
  insight: {
    q: 'InSight lander mars surface elysium seismometer',
    raw: 'https://mars.nasa.gov/insight/multimedia/raw-images/',
  },
  phoenix: {
    q: 'phoenix lander mars arctic surface soil trench',
    raw: 'https://www.lpl.arizona.edu/~phl/phoenix_images.html',
  },
  pathfinder: {
    q: 'pathfinder sojourner mars surface ares vallis panorama',
    raw: 'https://www.jpl.nasa.gov/missions/pathfinder',
  },
};

function getRoverQuery(site: LandingSite): { q: string; raw: string } | null {
  const nameLow = site.name.toLowerCase();
  for (const [key, val] of Object.entries(ROVER_QUERIES)) {
    if (nameLow.includes(key)) return val;
  }
  // Generic query for any Mars surface mission
  return {
    q: `${site.name} mars surface`,
    raw: 'https://images.nasa.gov/search?q=' + encodeURIComponent(site.name + ' mars'),
  };
}

export const RoverImageGallery: React.FC<RoverImageGalleryProps> = ({ site }) => {
  const [images, setImages] = useState<NASAImage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<NASAImage | null>(null);
  const [galleryModalUrl, setGalleryModalUrl] = useState<string>('');
  const [galleryOrigUrl, setGalleryOrigUrl] = useState<string>('');

  useEffect(() => {
    if (!selectedImage) {
      setGalleryModalUrl('');
      setGalleryOrigUrl('');
      return;
    }
    const cleanThumb = (selectedImage.thumb || '').replace(/^http:\/\//i, 'https://');
    setGalleryModalUrl(cleanThumb);
    setGalleryOrigUrl(cleanThumb.replace(/~(thumb|small|medium|large)\.jpg/i, '~orig.jpg'));

    fetch(`https://images-api.nasa.gov/asset/${encodeURIComponent(selectedImage.nasaId)}`)
      .then((r) => r.json())
      .then((data) => {
        const items = data.collection?.items || [];
        const urls: string[] = items
          .map((i: any) => (i.href || '').replace(/^http:\/\//i, 'https://'))
          .filter((u: string) => /\.(jpg|jpeg|png)$/i.test(u));

        const large = urls.find((u) => u.includes('~large.jpg'));
        const medium = urls.find((u) => u.includes('~medium.jpg'));
        const orig = urls.find((u) => u.includes('~orig.jpg'));
        const small = urls.find((u) => u.includes('~small.jpg'));
        const best = large || medium || orig || small || cleanThumb;
        setGalleryModalUrl(best);
        if (orig) setGalleryOrigUrl(orig);
      })
      .catch(() => {});
  }, [selectedImage]);

  const roverInfo = getRoverQuery(site);

  useEffect(() => {
    if (!roverInfo) return;
    setLoading(true);
    setError(null);
    setImages([]);

    const query = encodeURIComponent(roverInfo.q);
    const url = `https://images-api.nasa.gov/search?q=${query}&media_type=image&page_size=12`;

    fetch(url, { headers: { Accept: 'application/json' } })
      .then((r) => r.json())
      .then((data) => {
        const items: NASAImage[] = (data.collection?.items || [])
          .map((item: any) => ({
            id: item.data?.[0]?.nasa_id || Math.random().toString(),
            nasaId: item.data?.[0]?.nasa_id || '',
            title: item.data?.[0]?.title || 'Mars Surface Image',
            description: item.data?.[0]?.description || '',
            thumb: item.links?.[0]?.href || '',
            date: item.data?.[0]?.date_created?.slice(0, 10) || '',
          }))
          .filter((img: NASAImage) => img.thumb);
        setImages(items);
        setLoading(false);
      })
      .catch(() => {
        setError('Failed to load images. Check your connection.');
        setLoading(false);
      });
  }, [site.id]);

  if (!roverInfo) return null;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="p-4 rounded-xl bg-space-800/60 border border-white/10 text-xs text-white/80 space-y-3">
        <div className="font-semibold text-white flex items-center gap-2 text-sm">
          <span>📷</span>
          <span>NASA Surface Imagery</span>
          <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full bg-mars-500/20 text-mars-300 border border-mars-500/30 font-mono">
            NASA Images API
          </span>
        </div>
        <p className="text-white/60 leading-relaxed">
          Authentic surface images captured by {site.name} from the Martian surface. 
          Sourced from the NASA Image and Video Library archive.
        </p>

        {/* Quick links to data sources */}
        <div className="flex flex-wrap gap-2 pt-1">
          <button
            onClick={() => {
              useGlobeStore.getState().setActivePanel('live-images');
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-mars-600 hover:bg-mars-500 text-white font-medium text-xs transition-colors"
          >
            <span>📷</span> Open Live Imagery Explorer →
          </button>
          <a
            href={roverInfo.raw}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-xs transition-colors"
          >
            <span>🛰️</span> Raw Images Archive ↗
          </a>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-8 gap-3 text-white/40">
          <div className="w-5 h-5 border-2 border-mars-500/40 border-t-mars-500 rounded-full animate-spin" />
          <span className="text-xs">Fetching from NASA Images API…</span>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/30 text-xs text-rose-300">
          {error}
        </div>
      )}

      {/* Image Grid */}
      {!loading && images.length > 0 && (
        <div className="grid grid-cols-2 gap-2">
          {images.map((img) => (
            <button
              key={img.id}
              onClick={() => setSelectedImage(img)}
              className="rounded-xl overflow-hidden border border-white/10 bg-black/40 hover:border-mars-500/50 hover:scale-[1.02] transition-all group text-left"
            >
              <div className="relative">
                <img
                  src={img.thumb}
                  alt={img.title}
                  className="w-full h-28 object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2">
                  <span className="text-[9px] text-white font-medium line-clamp-2">{img.title}</span>
                </div>
              </div>
              <div className="px-2 py-1.5">
                <p className="text-[10px] text-white/70 line-clamp-1 leading-tight">{img.title}</p>
                {img.date && <p className="text-[9px] text-white/30 mt-0.5 font-mono">{img.date}</p>}
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Lightbox */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-[200] bg-black/90 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div
            className="relative max-w-2xl w-full bg-space-900 rounded-2xl border border-white/20 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-3 right-3 z-10 w-8 h-8 bg-black/60 text-white rounded-full flex items-center justify-center hover:bg-black/80 transition-colors"
            >
              ✕
            </button>
            <img
              src={galleryModalUrl || selectedImage.thumb}
              alt={selectedImage.title}
              onError={() => {
                if (galleryModalUrl !== selectedImage.thumb) {
                  setGalleryModalUrl(selectedImage.thumb);
                }
              }}
              className="w-full object-contain max-h-96"
            />
            <div className="p-4 space-y-2">
              <h3 className="text-white text-sm font-semibold">{selectedImage.title}</h3>
              {selectedImage.description && (
                <p className="text-white/60 text-xs leading-relaxed line-clamp-4">
                  {selectedImage.description}
                </p>
              )}
              <div className="flex items-center justify-between pt-2 border-t border-white/10">
                <span className="text-[11px] text-white/40 font-mono">{selectedImage.date}</span>
                <button
                  onClick={() => {
                    const dlUrl = galleryOrigUrl || galleryModalUrl || selectedImage.thumb;
                    const filename = `NASA_${site.name}_${selectedImage.nasaId || 'image'}.jpg`;
                    const proxyUrl = `/api/download-image?url=${encodeURIComponent(dlUrl)}&filename=${encodeURIComponent(filename)}`;
                    const a = document.createElement('a');
                    a.href = proxyUrl;
                    a.download = filename;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-mars-600 hover:bg-mars-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <span>📥</span>
                  <span>Download Image</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Attribution */}
      <div className="text-[10px] text-white/30 text-center pt-1">
        Source: NASA Image and Video Library (images-api.nasa.gov) · images.nasa.gov ·
        <a href="https://mars.nasa.gov/mars2020/multimedia/raw-images/" target="_blank" rel="noopener noreferrer" className="text-mars-400/60 hover:text-mars-400 ml-1">
          Perseverance Raw Images Gallery
        </a>
      </div>
    </div>
  );
};
