/**
 * ElevationProfile.tsx
 * Interactive elevation profile chart using Recharts showing elevation (m)
 * versus cumulative traverse distance (km) across planned waypoints.
 */

import React, { useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
} from 'recharts';
import { estimateElevationM, estimateSlopeDeg } from '../../routing/AStarRouter';

interface ElevationProfileProps {
  waypoints: Array<{ lat: number; lon: number; label: string }>;
}

export const ElevationProfile: React.FC<ElevationProfileProps> = ({ waypoints }) => {
  const chartData = useMemo(() => {
    if (waypoints.length < 2) return [];

    const data: Array<{
      distKm: number;
      elevation: number;
      slope: number;
      label?: string;
    }> = [];

    let totalDist = 0;
    const samplesPerSegment = 8;

    for (let i = 0; i < waypoints.length - 1; i++) {
      const p1 = waypoints[i];
      const p2 = waypoints[i + 1];

      // Segment distance in km
      const dLat = (p2.lat - p1.lat) * 59.2;
      const dLon = (p2.lon - p1.lon) * 59.2 * Math.cos((p1.lat * Math.PI) / 180);
      const segDist = Math.sqrt(dLat * dLat + dLon * dLon);

      for (let s = 0; s < samplesPerSegment; s++) {
        const t = s / samplesPerSegment;
        const lat = p1.lat + (p2.lat - p1.lat) * t;
        const lon = p1.lon + (p2.lon - p1.lon) * t;

        const elev = estimateElevationM(lat, lon);
        const slope = estimateSlopeDeg(lat, lon);

        data.push({
          distKm: Number((totalDist + segDist * t).toFixed(2)),
          elevation: elev,
          slope: Number(slope.toFixed(1)),
          label: s === 0 ? p1.label : undefined,
        });
      }
      totalDist += segDist;
    }

    // Add final endpoint
    const last = waypoints[waypoints.length - 1];
    data.push({
      distKm: Number(totalDist.toFixed(2)),
      elevation: estimateElevationM(last.lat, last.lon),
      slope: estimateSlopeDeg(last.lat, last.lon),
      label: last.label,
    });

    return data;
  }, [waypoints]);

  if (chartData.length === 0) {
    return (
      <div className="h-32 flex items-center justify-center bg-black/30 rounded-xl border border-white/5 text-white/40 text-xs">
        Add at least 2 waypoints to display the elevation profile.
      </div>
    );
  }

  const minElev = Math.min(...chartData.map((d) => d.elevation));
  const maxElev = Math.max(...chartData.map((d) => d.elevation));
  const yDomain = [minElev - 50, maxElev + 50];

  return (
    <div className="bg-space-950/60 p-3.5 rounded-xl border border-white/10 space-y-2">
      <div className="flex items-center justify-between text-xs text-white/70">
        <span className="font-semibold text-white">Traverse Elevation Profile</span>
        <span className="font-mono text-[11px] text-white/50">
          Range: {minElev} m to {maxElev} m
        </span>
      </div>

      <div className="h-28 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="marsElevGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#e8521a" stopOpacity={0.6} />
                <stop offset="95%" stopColor="#e8521a" stopOpacity={0.05} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="distKm"
              unit=" km"
              stroke="rgba(255,255,255,0.3)"
              tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.5)' }}
            />
            <YAxis
              domain={yDomain}
              unit="m"
              stroke="rgba(255,255,255,0.3)"
              tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.5)' }}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const d = payload[0].payload;
                  return (
                    <div className="bg-space-900 border border-white/20 p-2 rounded-lg text-xs shadow-xl">
                      <div className="text-white font-semibold">
                        {d.label ? `${d.label} (${d.distKm} km)` : `${d.distKm} km`}
                      </div>
                      <div className="text-mars-400 font-mono">Elevation: {d.elevation} m</div>
                      <div className="text-white/60 font-mono">Slope: {d.slope}°</div>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Area
              type="monotone"
              dataKey="elevation"
              stroke="#e8521a"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#marsElevGrad)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
