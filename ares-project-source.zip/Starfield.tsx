import React, { useRef, useEffect } from 'react';

interface Star {
  x: number;
  y: number;
  z: number; // depth 0–1 (parallax weight)
  brightness: number;
  size: number;
}

export const Starfield: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const gl = canvas.getContext('webgl', { antialias: false, alpha: true });
    if (!gl) {
      // Fallback: 2D canvas if WebGL not available
      return;
    }

    // ── Resize ──────────────────────────────────────────────────────────────
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      gl.viewport(0, 0, canvas.width, canvas.height);
    };
    resize();
    const resizeObs = new ResizeObserver(resize);
    resizeObs.observe(document.documentElement);

    // ── Generate stars ───────────────────────────────────────────────────────
    const STAR_COUNT = 2000;
    const stars: Star[] = Array.from({ length: STAR_COUNT }, () => ({
      x: Math.random() * 2 - 1, // NDC-ish
      y: Math.random() * 2 - 1,
      z: Math.random(),          // depth
      brightness: 0.3 + Math.random() * 0.7,
      size: 0.5 + Math.random() * 2.0,
    }));

    // ── Shaders ──────────────────────────────────────────────────────────────
    const vsSource = `
      attribute vec2 a_pos;
      attribute float a_brightness;
      attribute float a_size;
      uniform vec2 u_parallax;
      uniform vec2 u_resolution;
      varying float v_brightness;
      void main() {
        vec2 pos = a_pos + u_parallax;
        // Keep in NDC
        pos = mod(pos + 1.0, 2.0) - 1.0;
        gl_Position = vec4(pos, 0.0, 1.0);
        gl_PointSize = a_size;
        v_brightness = a_brightness;
      }
    `;

    const fsSource = `
      precision mediump float;
      varying float v_brightness;
      void main() {
        vec2 coord = gl_PointCoord - vec2(0.5);
        float dist = length(coord);
        if (dist > 0.5) discard;
        float alpha = (1.0 - dist * 2.0) * v_brightness;
        gl_FragColor = vec4(1.0, 1.0, 1.0, alpha);
      }
    `;

    function compileShader(type: number, src: string) {
      const s = gl!.createShader(type)!;
      gl!.shaderSource(s, src);
      gl!.compileShader(s);
      return s;
    }

    const vs = compileShader(gl.VERTEX_SHADER, vsSource);
    const fs = compileShader(gl.FRAGMENT_SHADER, fsSource);
    const prog = gl.createProgram()!;
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    gl.useProgram(prog);

    // ── Buffer data ──────────────────────────────────────────────────────────
    const posData = new Float32Array(STAR_COUNT * 2);
    const brightnessData = new Float32Array(STAR_COUNT);
    const sizeData = new Float32Array(STAR_COUNT);
    // Interleave parallax depths in a separate array for CPU use
    const depthData = new Float32Array(STAR_COUNT);

    stars.forEach((s, i) => {
      posData[i * 2] = s.x;
      posData[i * 2 + 1] = s.y;
      brightnessData[i] = s.brightness;
      sizeData[i] = s.size;
      depthData[i] = s.z;
    });

    const posBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, posBuf);
    gl.bufferData(gl.ARRAY_BUFFER, posData, gl.STATIC_DRAW);
    const aPosLoc = gl.getAttribLocation(prog, 'a_pos');
    gl.enableVertexAttribArray(aPosLoc);
    gl.vertexAttribPointer(aPosLoc, 2, gl.FLOAT, false, 0, 0);

    const brightBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, brightBuf);
    gl.bufferData(gl.ARRAY_BUFFER, brightnessData, gl.STATIC_DRAW);
    const aBrightLoc = gl.getAttribLocation(prog, 'a_brightness');
    gl.enableVertexAttribArray(aBrightLoc);
    gl.vertexAttribPointer(aBrightLoc, 1, gl.FLOAT, false, 0, 0);

    const sizeBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, sizeBuf);
    gl.bufferData(gl.ARRAY_BUFFER, sizeData, gl.STATIC_DRAW);
    const aSizeLoc = gl.getAttribLocation(prog, 'a_size');
    gl.enableVertexAttribArray(aSizeLoc);
    gl.vertexAttribPointer(aSizeLoc, 1, gl.FLOAT, false, 0, 0);

    const uParallaxLoc = gl.getUniformLocation(prog, 'u_parallax');
    const uResLoc = gl.getUniformLocation(prog, 'u_resolution');

    // ── 2D nebula overlay (drawn after WebGL via offscreen 2D canvas) ────────
    const nebCanvas = document.createElement('canvas');
    const nCtx = nebCanvas.getContext('2d')!;

    function drawNebula(w: number, h: number) {
      nebCanvas.width = w;
      nebCanvas.height = h;
      nCtx.clearRect(0, 0, w, h);

      // Deep purple/blue nebula in bottom-right quadrant
      const grad1 = nCtx.createRadialGradient(w * 0.85, h * 0.75, 0, w * 0.85, h * 0.75, w * 0.45);
      grad1.addColorStop(0, 'rgba(80, 20, 120, 0.18)');
      grad1.addColorStop(0.5, 'rgba(30, 20, 80, 0.10)');
      grad1.addColorStop(1, 'rgba(0,0,0,0)');
      nCtx.fillStyle = grad1;
      nCtx.fillRect(0, 0, w, h);

      // Secondary blue tinge
      const grad2 = nCtx.createRadialGradient(w * 0.7, h * 0.6, 0, w * 0.7, h * 0.6, w * 0.35);
      grad2.addColorStop(0, 'rgba(20, 40, 100, 0.12)');
      grad2.addColorStop(1, 'rgba(0,0,0,0)');
      nCtx.fillStyle = grad2;
      nCtx.fillRect(0, 0, w, h);

      // Warm Mars glow — centre-right
      const grad3 = nCtx.createRadialGradient(w * 0.65, h * 0.5, 0, w * 0.65, h * 0.5, w * 0.3);
      grad3.addColorStop(0, 'rgba(140, 50, 20, 0.08)');
      grad3.addColorStop(0.6, 'rgba(80, 20, 10, 0.04)');
      grad3.addColorStop(1, 'rgba(0,0,0,0)');
      nCtx.fillStyle = grad3;
      nCtx.fillRect(0, 0, w, h);
    }

    // We'll composite the nebula over the WebGL canvas using a second canvas element
    // The nebula canvas is inserted into the DOM as a sibling
    const nebulaEl = document.createElement('canvas');
    nebulaEl.style.cssText =
      'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0;';
    canvas.parentElement?.appendChild(nebulaEl);
    const nebulaCtx = nebulaEl.getContext('2d')!;

    function updateNebula() {
      nebulaEl.width = window.innerWidth;
      nebulaEl.height = window.innerHeight;
      drawNebula(nebulaEl.width, nebulaEl.height);
      nebulaCtx.drawImage(nebCanvas, 0, 0);
    }
    updateNebula();

    // ── Mouse parallax ───────────────────────────────────────────────────────
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = {
        x: (e.clientX / window.innerWidth - 0.5) * 2,
        y: (e.clientY / window.innerHeight - 0.5) * 2,
      };
    };
    window.addEventListener('mousemove', handleMouseMove);

    // ── Render loop ──────────────────────────────────────────────────────────
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
    gl.clearColor(0, 0, 0, 0);

    function render() {
      gl!.clear(gl!.COLOR_BUFFER_BIT);
      gl!.uniform2f(uResLoc, canvas!.width, canvas!.height);

      // Per-star parallax needs to be computed on GPU via depth; we approximate
      // by passing a single overall parallax and letting the shader use a_pos offset
      // For true per-depth parallax we'd need a uniform per star — instead we
      // apply light global shift (maximum 0.015 NDC = barely visible)
      const px = mouseRef.current.x * 0.015;
      const py = -mouseRef.current.y * 0.015;
      gl!.uniform2f(uParallaxLoc, px, py);

      gl!.drawArrays(gl!.POINTS, 0, STAR_COUNT);
      rafRef.current = requestAnimationFrame(render);
    }
    render();

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('mousemove', handleMouseMove);
      resizeObs.disconnect();
      nebulaEl.remove();
      gl.deleteProgram(prog);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%',
        zIndex: -1,
        pointerEvents: 'none',
        background: 'transparent',
      }}
    />
  );
};
