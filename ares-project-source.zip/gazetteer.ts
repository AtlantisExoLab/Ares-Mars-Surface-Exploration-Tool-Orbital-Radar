/**
 * gazetteer.ts
 * Re-export of IAU Gazetteer of Planetary Nomenclature features and search utilities.
 */

export * from './gazeteerIndex';
export { GAZETTEER_FEATURES } from './gazeteerIndex';
