/**
 * Step5Safety.tsx
 * Mission Planner Step 5: Safety Review, Mode Configuration, and Mission Briefing Export.
 */

import React, { useState } from 'react';
import { usePlannerStore } from '../../../store/plannerStore';
import { SafetyDashboard } from '../SafetyDashboard';
import { ElevationProfile } from '../ElevationProfile';
import { exportGeoJSON, exportPDFBrief, generateShareUrl } from '../MissionExport';

export const Step5Safety: React.FC = () => {
  const waypoints = usePlannerStore((s) => s.waypoints);
  const baseLocation = usePlannerStore((s) => s.baseLocation);
  const objective = usePlannerStore((s) => s.objective);
  const evaSpeedKmh = usePlannerStore((s) => s.evaSpeedKmh);
  const setEvaSpeedKmh = usePlannerStore((s) => s.setEvaSpeedKmh);
  const evaTimeLimitHours = usePlannerStore((s) => s.evaTimeLimitHours);
  const setEvaTimeLimitHours = usePlannerStore((s) => s.setEvaTimeLimitHours);
  const evaMode = usePlannerStore((s) => s.evaMode);
  const setEvaMode = usePlannerStore((s) => s.setEvaMode);
  const displayMode = usePlannerStore((s) => s.displayMode);
  const setDisplayMode = usePlannerStore((s) => s.setDisplayMode);

  const [copiedLink, setCopiedLink] = useState(false);

  const handleExportGeoJSON = () => {
    exportGeoJSON(
      baseLocation?.name || 'Mars Traverse',
      waypoints,
      {
        objective: objective || 'General Surface Reconnaissance',
        evaMode,
        totalKm: usePlannerStore.getState().getTotalDistanceKm(),
        estimatedHours: usePlannerStore.getState().getEstimatedDurationHours(),
      }
    );
  };

  const handleExportPDF = () => {
    const metrics = {
      totalDistanceKm: usePlannerStore.getState().getTotalDistanceKm(),
      estimatedDurationHours: usePlannerStore.getState().getEstimatedDurationHours(),
      maxSlopeDeg: 14.8,
      meanSlopeDeg: 8.2,
      elevationGainM: 120,
      elevationLossM: 90,
      temperatureRangeC: { min: -75, max: -22 },
      radiationDoseRateMGyDay: 0.64,
      habitatDistanceKm: 1.8,
      habitatLosMaintained: true,
      warnings: [],
    };

    exportPDFBrief(
      baseLocation?.name || 'Ares Surface Traverse',
      waypoints,
      metrics,
      objective || 'Geologic Survey',
      baseLocation?.name || 'Base Alpha'
    );
  };

  const handleCopyShareLink = () => {
    const lat = baseLocation ? baseLocation.lat : -4.68;
    const lon = baseLocation ? baseLocation.lon : 137.38;
    const url = generateShareUrl({ lat, lon, altKm: 300 });
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="space-y-6 text-xs text-white/80">
      {/* Intro Header */}
      <div className="p-3.5 rounded-xl bg-space-800/60 border border-white/10 space-y-1">
        <div className="font-semibold text-white flex items-center gap-1.5">
          <span>🛡️</span>
          <span>5. Astronaut Safety & Hazard Verification</span>
        </div>
        <p className="text-white/60 leading-relaxed text-[11px]">
          Validate physical suit mobility constraints, slope hazards, oxygen duration limits, and line-of-sight communication with Habitat.
        </p>
      </div>

      {/* Mode Selectors */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-3 rounded-xl bg-space-800/40 border border-white/10 space-y-2">
          <div className="text-[10px] uppercase font-mono text-white/50">Traverse Mobility Mode</div>
          <div className="flex rounded-lg bg-black/40 p-1 border border-white/10 text-xs">
            <button
              onClick={() => setEvaMode('astronaut-pair')}
              className={`flex-1 py-1.5 rounded-md font-medium transition-colors ${
                evaMode === 'astronaut-pair'
                  ? 'bg-mars-600 text-white shadow'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              🧑‍🚀 Astronaut Pair
            </button>
            <button
              onClick={() => setEvaMode('rover-assisted')}
              className={`flex-1 py-1.5 rounded-md font-medium transition-colors ${
                evaMode === 'rover-assisted'
                  ? 'bg-mars-600 text-white shadow'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              🚜 Rover-Assisted
            </button>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-space-800/40 border border-white/10 space-y-2">
          <div className="text-[10px] uppercase font-mono text-white/50">Display View Format</div>
          <div className="flex rounded-lg bg-black/40 p-1 border border-white/10 text-xs">
            <button
              onClick={() => setDisplayMode('tablet')}
              className={`flex-1 py-1.5 rounded-md font-medium transition-colors ${
                displayMode === 'tablet'
                  ? 'bg-white/20 text-white'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              📱 Tablet
            </button>
            <button
              onClick={() => setDisplayMode('helmet-hud')}
              className={`flex-1 py-1.5 rounded-md font-medium transition-colors ${
                displayMode === 'helmet-hud'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              🪖 Visor HUD
            </button>
          </div>
        </div>
      </div>

      {/* Speed and Oxygen Limit Sliders */}
      <div className="grid grid-cols-2 gap-3 p-3.5 rounded-xl bg-space-950/60 border border-white/10">
        <div>
          <div className="flex justify-between text-[11px] mb-1.5">
            <span className="text-white/50">Nominal Speed:</span>
            <span className="text-white font-mono">{evaSpeedKmh} km/h</span>
          </div>
          <input
            type="range"
            min="0.8"
            max="4.5"
            step="0.1"
            value={evaSpeedKmh}
            onChange={(e) => setEvaSpeedKmh(parseFloat(e.target.value))}
            className="w-full accent-mars-500"
          />
        </div>

        <div>
          <div className="flex justify-between text-[11px] mb-1.5">
            <span className="text-white/50">O₂ Time Budget:</span>
            <span className="text-white font-mono">{evaTimeLimitHours} hrs</span>
          </div>
          <input
            type="range"
            min="2"
            max="8"
            step="0.5"
            value={evaTimeLimitHours}
            onChange={(e) => setEvaTimeLimitHours(parseFloat(e.target.value))}
            className="w-full accent-mars-500"
          />
        </div>
      </div>

      {/* Safety Dashboard Summary */}
      <SafetyDashboard
        waypoints={waypoints}
        evaSpeedKmh={evaSpeedKmh}
        evaTimeLimitHours={evaTimeLimitHours}
        evaMode={evaMode}
      />

      {/* Elevation Profile Chart */}
      <ElevationProfile waypoints={waypoints} />

      {/* Export & Briefing Options */}
      <div className="space-y-2 pt-2 border-t border-white/10">
        <div className="text-[11px] font-mono uppercase text-white/40">
          Mission Documentation & Deployment
        </div>
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={handleExportGeoJSON}
            className="py-2.5 px-3 rounded-xl bg-space-800/80 hover:bg-space-700/80 border border-white/15 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
          >
            <span>⬇️</span>
            <span>GeoJSON</span>
          </button>
          <button
            onClick={handleExportPDF}
            className="py-2.5 px-3 rounded-xl bg-space-800/80 hover:bg-space-700/80 border border-white/15 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
          >
            <span>📄</span>
            <span>PDF Brief</span>
          </button>
          <button
            onClick={handleCopyShareLink}
            className="py-2.5 px-3 rounded-xl bg-space-800/80 hover:bg-space-700/80 border border-white/15 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
          >
            <span>🔗</span>
            <span>{copiedLink ? 'Copied ✓' : 'Share URL'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
