/**
 * CameraController.ts
 *
 * Camera utility functions for the Ares Mars viewer.
 * All coordinate inputs use:
 *   - lat: planetocentric degrees, positive = north
 *   - lon: 0–360° east-positive (converted to Cesium's −180–180 internally)
 *   - altitude: metres above the Mars reference ellipsoid (unless noted as km)
 */

import * as Cesium from 'cesium';
import { marsLonToCesium } from './CoordinateUtils';

// ---------------------------------------------------------------------------
// Mars ellipsoid — same constants as CoordinateUtils / CesiumViewer
// ---------------------------------------------------------------------------
const MARS_ELLIPSOID = new Cesium.Ellipsoid(3_396_190, 3_396_190, 3_376_200);

/** Default "whole globe visible" altitude in metres */
const GLOBE_VIEW_ALT_M = 8_000_000; // 8 000 km

/** Intro deep-space start altitude in metres */
const DEEP_SPACE_ALT_M = 50_000_000; // 50 000 km

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface CameraState {
  /** Planetocentric latitude in degrees */
  lat: number;
  /** East-positive longitude 0–360° */
  lon: number;
  /** Camera altitude above ellipsoid in kilometres */
  altKm: number;
  /** Camera heading in degrees (0 = north, clockwise) */
  heading: number;
  /** Camera pitch in degrees (negative = looking down) */
  pitch: number;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Convert degrees to radians */
const toRad = (d: number) => Cesium.Math.toRadians(d);

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Fly the camera to a specific location on Mars.
 *
 * @param viewer       The Cesium Viewer instance
 * @param lat          Planetocentric latitude (degrees)
 * @param lon360       East-positive longitude 0–360°
 * @param altitudeKm   Camera altitude in km (default 500 km)
 * @param durationSec  Fly-to animation duration in seconds (default 2 s)
 */
export function flyTo(
  viewer: Cesium.Viewer,
  lat: number,
  lon360: number,
  altitudeKm = 500,
  durationSec = 2,
): void {
  const lon180 = marsLonToCesium(lon360);
  const destination = Cesium.Cartesian3.fromDegrees(
    lon180,
    lat,
    altitudeKm * 1000,
    MARS_ELLIPSOID,
  );

  viewer.camera.flyTo({
    destination,
    orientation: {
      heading: toRad(0),
      pitch: toRad(-45),
      roll: 0,
    },
    duration: durationSec,
    easingFunction: Cesium.EasingFunction.CUBIC_IN_OUT,
  });
}

/**
 * Cinematic intro: animate the camera from deep space (50 000 km) to a
 * comfortable orbit (8 000 km) centred on Mars.
 *
 * @param viewer      The Cesium Viewer instance
 * @param durationSec Duration of the animation in seconds
 */
export function flyInFromDeepSpace(viewer: Cesium.Viewer, durationSec: number): void {
  // Snap to deep-space position first
  viewer.camera.setView({
    destination: Cesium.Cartesian3.fromDegrees(0, 20, DEEP_SPACE_ALT_M, MARS_ELLIPSOID),
    orientation: {
      heading: toRad(0),
      pitch: toRad(-90),
      roll: 0,
    },
  });

  // Then fly in to globe-view altitude
  viewer.camera.flyTo({
    destination: Cesium.Cartesian3.fromDegrees(0, 0, GLOBE_VIEW_ALT_M, MARS_ELLIPSOID),
    orientation: {
      heading: toRad(0),
      pitch: toRad(-90),
      roll: 0,
    },
    duration: durationSec,
    easingFunction: Cesium.EasingFunction.QUINTIC_IN_OUT,
  });
}

/**
 * Reset the camera to the full-globe overview (8 000 km, centred on 0°N 0°E).
 */
export function resetToGlobeView(viewer: Cesium.Viewer): void {
  viewer.camera.flyTo({
    destination: Cesium.Cartesian3.fromDegrees(0, 0, GLOBE_VIEW_ALT_M, MARS_ELLIPSOID),
    orientation: {
      heading: toRad(0),
      pitch: toRad(-90),
      roll: 0,
    },
    duration: 1.5,
    easingFunction: Cesium.EasingFunction.CUBIC_IN_OUT,
  });
}

/**
 * Reset the camera heading to north (heading = 0) while keeping the same
 * position and pitch.
 */
export function resetNorth(viewer: Cesium.Viewer): void {
  const { camera } = viewer;
  camera.flyTo({
    destination: camera.position,
    orientation: {
      heading: toRad(0),
      pitch: camera.pitch,
      roll: 0,
    },
    duration: 0.8,
  });
}

/**
 * Toggle the scene between 3-D and 2-D Columbus-View / SCENE2D mode.
 * Cycles: SCENE3D → COLUMBUS_VIEW → SCENE2D → SCENE3D
 */
export function toggleSceneMode(viewer: Cesium.Viewer): void {
  const { scene } = viewer;
  switch (scene.mode) {
    case Cesium.SceneMode.SCENE3D:
      scene.morphToColumbusView(0.6);
      break;
    case Cesium.SceneMode.COLUMBUS_VIEW:
      scene.morphTo2D(0.6);
      break;
    case Cesium.SceneMode.SCENE2D:
    default:
      scene.morphTo3D(0.6);
      break;
  }
}

/**
 * Set vertical terrain exaggeration.
 * @param factor  1.0 = true scale, 2.0 = 2× exaggeration
 */
export function setTerrainExaggeration(viewer: Cesium.Viewer, factor: number): void {
  viewer.scene.verticalExaggeration = factor;
}

/**
 * Capture the current camera state for URL-based sharing / bookmarking.
 */
export function getCameraState(viewer: Cesium.Viewer): CameraState {
  const { camera } = viewer;
  const carto = Cesium.Cartographic.fromCartesian(camera.position, MARS_ELLIPSOID);

  return {
    lat: parseFloat(Cesium.Math.toDegrees(carto.latitude).toFixed(6)),
    lon: parseFloat(
      (((Cesium.Math.toDegrees(carto.longitude) % 360) + 360) % 360).toFixed(6),
    ),
    altKm: parseFloat((carto.height / 1000).toFixed(3)),
    heading: parseFloat(Cesium.Math.toDegrees(camera.heading).toFixed(2)),
    pitch: parseFloat(Cesium.Math.toDegrees(camera.pitch).toFixed(2)),
  };
}

/**
 * Restore a previously captured camera state (e.g. from URL parameters).
 */
export function restoreCameraState(viewer: Cesium.Viewer, state: CameraState): void {
  const lon180 = state.lon > 180 ? state.lon - 360 : state.lon;

  viewer.camera.flyTo({
    destination: Cesium.Cartesian3.fromDegrees(
      lon180,
      state.lat,
      state.altKm * 1000,
      MARS_ELLIPSOID,
    ),
    orientation: {
      heading: toRad(state.heading),
      pitch: toRad(state.pitch),
      roll: 0,
    },
    duration: 1.5,
    easingFunction: Cesium.EasingFunction.CUBIC_IN_OUT,
  });
}

/**
 * Compute the total geodesic path length for a series of positions.
 * Uses Cesium's EllipsoidGeodesic for each leg.
 *
 * @param viewer     The Cesium Viewer instance (used only for type context)
 * @param positions  Array of Cesium.Cartographic positions
 * @returns          Total distance in metres
 */
export function measureDistance(
  _viewer: Cesium.Viewer,
  positions: Cesium.Cartographic[],
): number {
  if (positions.length < 2) return 0;

  let totalMetres = 0;

  for (let i = 0; i < positions.length - 1; i++) {
    const geodesic = new Cesium.EllipsoidGeodesic(
      positions[i],
      positions[i + 1],
      MARS_ELLIPSOID,
    );
    totalMetres += geodesic.surfaceDistance;
  }

  return totalMetres;
}
