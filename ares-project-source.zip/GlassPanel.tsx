import { motion, type MotionProps } from 'framer-motion';
import React from 'react';

interface Props {
  className?: string;
  dark?: boolean;
  children: React.ReactNode;
  style?: React.CSSProperties;
  /** Direction the panel slides in from */
  slideFrom?: 'left' | 'right' | 'bottom' | 'top' | 'none';
}

const slideVariants = {
  left: {
    hidden: { x: -24, opacity: 0 },
    visible: { x: 0, opacity: 1 },
    exit: { x: -24, opacity: 0 },
  },
  right: {
    hidden: { x: 24, opacity: 0 },
    visible: { x: 0, opacity: 1 },
    exit: { x: 24, opacity: 0 },
  },
  bottom: {
    hidden: { y: 16, opacity: 0 },
    visible: { y: 0, opacity: 1 },
    exit: { y: 16, opacity: 0 },
  },
  top: {
    hidden: { y: -16, opacity: 0 },
    visible: { y: 0, opacity: 1 },
    exit: { y: -16, opacity: 0 },
  },
  none: {
    hidden: { opacity: 0 },
    visible: { opacity: 1 },
    exit: { opacity: 0 },
  },
};

const transition = { duration: 0.3, ease: [0.16, 1, 0.3, 1] as const };

export const GlassPanel: React.FC<Props> = ({
  className = '',
  dark = false,
  children,
  style,
  slideFrom = 'none',
}) => {
  const variants = slideVariants[slideFrom];

  return (
    <motion.div
      className={`${dark ? 'glass-panel-dark' : 'glass-panel'} ${className}`}
      style={style}
      variants={variants}
      initial="hidden"
      animate="visible"
      exit="exit"
      transition={transition}
    >
      {children}
    </motion.div>
  );
};

export default GlassPanel;
