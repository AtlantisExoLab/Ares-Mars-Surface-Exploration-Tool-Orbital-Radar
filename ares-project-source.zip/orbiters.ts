/**
 * orbiters.ts
 * Type-safe interface to the Mars orbiter missions database.
 */

import type { OrbiterMission } from '../types/MarsTypes';
import rawOrbiters from '../../public/data/orbiters.json';

export const ORBITERS: OrbiterMission[] = rawOrbiters as OrbiterMission[];

export function getAllOrbiters(): OrbiterMission[] {
  return ORBITERS;
}

export function getOrbiterById(id: string): OrbiterMission | undefined {
  return ORBITERS.find((o) => o.id === id);
}

export function getOrbitersByStatus(status: 'active' | 'ended' | 'lost'): OrbiterMission[] {
  return ORBITERS.filter((o) => o.status === status);
}

export function getOrbitersByAgency(agency: string): OrbiterMission[] {
  const norm = agency.toLowerCase();
  return ORBITERS.filter((o) => o.agency.toLowerCase().includes(norm));
}
