/**
 * App.tsx
 * Root component coordinating the Cesium Viewer, the cinematic intro sequence,
 * and the Google Earth-style Mars surface exploration interface.
 */

import React, { useState, useCallback } from 'react';
import * as Cesium from 'cesium';
import { useGlobeStore } from './store/globeStore';
import { useSettingsStore } from './store/settingsStore';
import { CesiumViewer } from './globe/CesiumViewer';
import { IntroScene } from './intro/IntroScene';
import { AppShell } from './ui/shell/AppShell';

export const App: React.FC = () => {
  const viewer = useGlobeStore((s) => s.viewer);
  const setViewer = useGlobeStore((s) => s.setViewer);

  const introPlayed = useSettingsStore((s) => s.introPlayed);
  const setIntroPlayed = useSettingsStore((s) => s.setIntroPlayed);

  const [isPlayingIntro, setIsPlayingIntro] = useState(!introPlayed);

  const handleViewerReady = useCallback((v: Cesium.Viewer) => {
    setViewer(v);
  }, [setViewer]);

  const handleIntroComplete = useCallback(() => {
    setIsPlayingIntro(false);
    setIntroPlayed(true);
  }, [setIntroPlayed]);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-black font-body text-white">
      {/* 3D Mars Globe Engine (always mounted for tile preloading) */}
      <div className="absolute inset-0 z-0">
        <CesiumViewer onReady={handleViewerReady} />
      </div>

      {/* Cinematic Intro Overlay */}
      {isPlayingIntro && (
        <div className="absolute inset-0 z-50">
          <IntroScene
            onComplete={handleIntroComplete}
            cesiumViewer={viewer}
          />
        </div>
      )}

      {/* Primary Google Earth-style Application Shell */}
      {viewer && !isPlayingIntro && (
        <div className="absolute inset-0 z-10 pointer-events-none">
          <AppShell viewer={viewer} />
        </div>
      )}
    </main>
  );
};

export default App;
