import React, { useEffect, useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { Starfield } from './Starfield';
import { TitleReveal } from './TitleReveal';

interface IntroSceneProps {
  onComplete: () => void;
  cesiumViewer: any | null;
}

type Phase = 0 | 1 | 2 | 3;

export const IntroScene: React.FC<IntroSceneProps> = ({ onComplete, cesiumViewer }) => {
  const prefersReduced = useReducedMotion();
  const [phase, setPhase] = useState<Phase>(0);
  const [showSkip, setShowSkip] = useState(false);
  const [titleDone, setTitleDone] = useState(false);
  const doneRef = useRef(false);
  const timersRef = useRef<number[]>([]);

  const complete = useCallback(() => {
    if (doneRef.current) return;
    doneRef.current = true;
    timersRef.current.forEach(clearTimeout);
    onComplete();
  }, [onComplete]);

  useEffect(() => {
    if (prefersReduced) {
      complete();
      return;
    }

    const t = (ms: number, fn: () => void) => {
      const id = window.setTimeout(fn, ms);
      timersRef.current.push(id);
    };

    // Skip button after 1s
    t(1000, () => setShowSkip(true));
    // Phase 1: Cesium fades in
    t(1000, () => setPhase(1));
    // Phase 2: Title reveals
    t(4000, () => setPhase(2));
    // Phase 3: Transition out
    t(6000, () => setPhase(3));
    // Complete
    t(8000, complete);

    return () => timersRef.current.forEach(clearTimeout);
  }, [prefersReduced, complete]);

  // Camera fly-in when Cesium becomes available in phase 1
  useEffect(() => {
    if (phase < 1 || !cesiumViewer || prefersReduced) return;
    try {
      const { Camera, Math: CesiumMath } = (window as any).Cesium ?? {};
      if (!cesiumViewer.camera) return;

      // Start high, fly to Mars orbit
      cesiumViewer.camera.flyTo({
        destination: (window as any).Cesium?.Cartesian3?.fromDegrees(137.4, -4.5, 8_000_000),
        orientation: {
          heading: CesiumMath?.toRadians(0) ?? 0,
          pitch: CesiumMath?.toRadians(-90) ?? -Math.PI / 2,
          roll: 0,
        },
        duration: 4,
        easingFunction: (window as any).Cesium?.EasingFunction?.QUINTIC_IN_OUT,
      });
    } catch {
      // Silently fail if Cesium API not ready
    }
  }, [phase, cesiumViewer, prefersReduced]);

  const cesiumOpacity =
    phase === 0 ? 0
    : phase === 1 ? 0.6
    : phase === 2 ? 0.85
    : 1;

  return (
    <div
      className="fixed inset-0 overflow-hidden"
      style={{ background: '#070b14', zIndex: 50 }}
    >
      {/* Starfield layer */}
      <div className="absolute inset-0" style={{ zIndex: 1 }}>
        <Starfield />
      </div>

      {/* Cesium globe — always mounted, opacity animated */}
      <motion.div
        className="absolute inset-0"
        style={{ zIndex: 2 }}
        animate={{ opacity: cesiumOpacity }}
        transition={{ duration: prefersReduced ? 0 : 2, ease: 'easeInOut' }}
      >
        {/* Cesium canvas is controlled by parent; this div provides the stacking context */}
      </motion.div>

      {/* Title overlay — phases 2 & 3 */}
      <AnimatePresence>
        {phase === 2 && (
          <motion.div
            key="title"
            className="absolute inset-0 flex items-center justify-center"
            style={{ zIndex: 10 }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: prefersReduced ? 0 : 0.6, ease: 'easeInOut' }}
          >
            <TitleReveal onComplete={() => setTitleDone(true)} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Vignette overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          zIndex: 5,
          background:
            'radial-gradient(ellipse at center, transparent 40%, rgba(7,11,20,0.7) 100%)',
        }}
      />

      {/* Skip button */}
      <AnimatePresence>
        {showSkip && phase < 3 && (
          <motion.button
            key="skip"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: prefersReduced ? 0 : 0.3 }}
            onClick={complete}
            className="btn-ghost"
            style={{
              position: 'absolute',
              bottom: '2rem',
              right: '2rem',
              zIndex: 20,
              fontSize: '13px',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
            }}
          >
            Skip Intro ›
          </motion.button>
        )}
      </AnimatePresence>

      {/* Loading pulse in phase 0 */}
      <AnimatePresence>
        {phase === 0 && (
          <motion.div
            key="loading"
            className="absolute inset-0 flex items-end justify-center pb-12"
            style={{ zIndex: 15 }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: prefersReduced ? 0 : 0.4 }}
          >
            <span
              style={{
                fontSize: '11px',
                color: 'rgba(255,255,255,0.3)',
                letterSpacing: '0.15em',
                textTransform: 'uppercase',
              }}
            >
              Initialising Mars Surface Data…
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
