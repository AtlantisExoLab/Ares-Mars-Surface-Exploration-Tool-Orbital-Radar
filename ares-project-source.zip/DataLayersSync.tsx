/**
 * DataLayersSync.tsx
 * Persistent synchronization layer between globeStore's layerVisibility / layerOpacities
 * and Cesium viewer.imageryLayers. Runs permanently in AppShell so layers remain active
 * on the 3D globe even when LayerPanel is closed.
 */

import React, { useEffect } from 'react';
import * as Cesium from 'cesium';
import { useGlobeStore } from '../store/globeStore';
import { LAYER_CONFIGS, createMarsImageryProvider, type LayerId } from './MarsImagery';

interface DataLayersSyncProps {
  viewer: Cesium.Viewer;
}

export const DataLayersSync: React.FC<DataLayersSyncProps> = ({ viewer }) => {
  const layerVisibility = useGlobeStore((s) => s.layerVisibility);
  const layerOpacities = useGlobeStore((s) => s.layerOpacities);

  useEffect(() => {
    if (!viewer?.imageryLayers || viewer.isDestroyed()) return;

    const layers = viewer.imageryLayers;

    (Object.keys(LAYER_CONFIGS) as LayerId[]).forEach((layerId) => {
      const isVisible = Boolean(layerVisibility[layerId]);
      const defaultAlpha = LAYER_CONFIGS[layerId]?.defaultOpacity ?? 0.75;
      const opacityPercent = layerOpacities[layerId] ?? defaultAlpha * 100;
      const alpha = opacityPercent / 100;

      // Find existing imagery layer
      let match: Cesium.ImageryLayer | null = null;
      for (let i = 0; i < layers.length; i++) {
        const l = layers.get(i);
        if ((l as any)._aresLayerId === layerId) {
          match = l;
          break;
        }
      }

      if (isVisible) {
        if (!match) {
          const provider = createMarsImageryProvider(layerId);
          if (provider) {
            const newLayer = layers.addImageryProvider(provider);
            (newLayer as any)._aresLayerId = layerId;
            newLayer.alpha = alpha;
            newLayer.show = true;
          }
        } else {
          match.show = true;
          match.alpha = alpha;
        }
      } else {
        if (match) {
          match.show = false;
        }
      }
    });

    if (viewer.scene && !viewer.isDestroyed()) {
      viewer.scene.requestRender();
    }
  }, [viewer, layerVisibility, layerOpacities]);

  return null;
};
