/**
 * MissionCard.tsx
 * Comprehensive slide-in drawer showing complete verified details for any
 * selected Mars surface mission, including instruments, scientific discoveries,
 * real surface POV imagery links, and a direct "Plan a Marswalk here" handoff.
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGlobeStore } from '../../store/globeStore';
import { usePlannerStore } from '../../store/plannerStore';
import { getSiteById } from '../../data/landingSites';
import { formatMarsCoords } from '../../globe/CoordinateUtils';
import { RoverImageGallery } from './RoverImageGallery';

export const MissionCard: React.FC = () => {
  const selectedSiteId = useGlobeStore((s) => s.selectedSiteId);
  const setSelectedSite = useGlobeStore((s) => s.setSelectedSite);
  const setActivePanel = useGlobeStore((s) => s.setActivePanel);

  const setBaseLocation = usePlannerStore((s) => s.setBaseLocation);
  const openPlanner = usePlannerStore((s) => s.openPlanner);
  const setStep = usePlannerStore((s) => s.setStep);

  const [activeTab, setActiveTab] = useState<'overview' | 'instruments' | 'gallery'>('overview');
  const [copiedCoords, setCopiedCoords] = useState(false);

  if (!selectedSiteId) return null;
  const site = getSiteById(selectedSiteId);
  if (!site) return null;

  const handlePlanMarswalk = () => {
    // Populate Mission Planner with this site's coordinates and open
    setBaseLocation({
      lat: site.lat,
      lon: site.lon,
      name: `${site.name} Landing Site (${site.locationName})`,
    });
    setStep(2); // advance to science objective step
    openPlanner();
    setActivePanel('planner');
  };

  const handleCopyCoords = () => {
    const text = `${site.lat >= 0 ? site.lat : Math.abs(site.lat) + ' S'}, ${site.lon} E`;
    navigator.clipboard.writeText(text);
    setCopiedCoords(true);
    setTimeout(() => setCopiedCoords(false), 2000);
  };

  return (
    <motion.div
      initial={{ x: 40, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 40, opacity: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="fixed top-16 right-4 md:right-16 w-88 md:w-[440px] bottom-16 bg-[#0a0d14] border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col z-30 overflow-hidden pointer-events-auto"
    >
      {/* Top Banner */}
      <div className="relative p-6 border-b border-slate-700/80 bg-[#0f1420]">
        <button
          onClick={() => setSelectedSite(null)}
          className="absolute top-4 right-4 text-white/50 hover:text-white w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 transition-colors"
          title="Close details"
        >
          ✕
        </button>

        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs px-2.5 py-0.5 rounded-full bg-white/10 text-white/80 font-mono">
            {site.agency}
          </span>
          <span className="text-xs text-white/50 font-medium">· {site.country}</span>
          <span
            className={`text-xs px-2 py-0.5 rounded-full ml-auto font-medium ${
              site.status === 'active'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : site.status === 'ended'
                ? 'bg-white/10 text-white/60'
                : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
            }`}
          >
            {site.status === 'active' ? '● Active' : site.status === 'ended' ? 'Mission Ended' : 'Lost / Impact'}
          </span>
        </div>

        <h1 className="text-2xl font-display font-bold text-white tracking-tight mb-1">
          {site.name}
        </h1>
        <div className="text-xs text-white/60 mb-3">
          {site.type} · Landed {site.landingDate} in {site.locationName}
          {site.coordsApproximate && ' (approximate landing zone)'}
        </div>

        {/* Coordinates Chip */}
        <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs font-mono text-white/80">
          <span>{formatMarsCoords(site.lat, site.lon)}</span>
          <button
            onClick={handleCopyCoords}
            className="text-[11px] text-mars-400 hover:text-mars-300 font-sans ml-2"
          >
            {copiedCoords ? 'Copied ✓' : 'Copy'}
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10 bg-space-950/40 text-xs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex-1 py-2.5 font-medium border-b-2 transition-colors ${
            activeTab === 'overview'
              ? 'border-mars-500 text-white bg-white/5'
              : 'border-transparent text-white/50 hover:text-white/80'
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => setActiveTab('instruments')}
          className={`flex-1 py-2.5 font-medium border-b-2 transition-colors ${
            activeTab === 'instruments'
              ? 'border-mars-500 text-white bg-white/5'
              : 'border-transparent text-white/50 hover:text-white/80'
          }`}
        >
          Instruments ({site.instruments.length})
        </button>
        <button
          onClick={() => setActiveTab('gallery')}
          className={`flex-1 py-2.5 font-medium border-b-2 transition-colors ${
            activeTab === 'gallery'
              ? 'border-mars-500 text-white bg-white/5'
              : 'border-transparent text-white/50 hover:text-white/80'
          }`}
        >
          Surface POV
        </button>
      </div>

      {/* Tab Body */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6 text-sm">
        {activeTab === 'overview' && (
          <>
            {/* Objectives */}
            <div>
              <h3 className="text-xs font-mono uppercase tracking-wider text-white/40 mb-2">
                Mission Objectives
              </h3>
              <ul className="space-y-1.5 text-xs text-white/80 leading-relaxed">
                {site.objectives.map((obj, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-mars-400 mt-0.5">•</span>
                    <span>{obj}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Key Discoveries */}
            <div>
              <h3 className="text-xs font-mono uppercase tracking-wider text-white/40 mb-2">
                Key Discoveries & Scientific Legacy
              </h3>
              <ul className="space-y-2 text-xs text-white/80 leading-relaxed">
                {site.keyDiscoveries.map((disc, i) => (
                  <li key={i} className="flex items-start gap-2 bg-white/5 p-2.5 rounded-lg border border-white/5">
                    <span className="text-amber-400 mt-0.5">✦</span>
                    <span>{disc}</span>
                  </li>
                ))}
              </ul>
            </div>
          </>
        )}

        {activeTab === 'instruments' && (
          <div>
            <h3 className="text-xs font-mono uppercase tracking-wider text-white/40 mb-3">
              Scientific Payload & Sensors
            </h3>
            <div className="grid grid-cols-1 gap-2">
              {site.instruments.map((inst, i) => (
                <div
                  key={i}
                  className="p-3 rounded-xl bg-space-800/40 border border-white/10 text-xs text-white/90 flex items-center gap-3"
                >
                  <span className="w-5 h-5 rounded-full bg-mars-500/20 text-mars-400 flex items-center justify-center text-[10px] font-mono">
                    {i + 1}
                  </span>
                  <span>{inst}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'gallery' && (
          <RoverImageGallery site={site} />
        )}
      </div>

      {/* Action Footer */}
      <div className="p-4 border-t border-white/10 bg-space-950/80 flex flex-col gap-2">
        <button
          onClick={handlePlanMarswalk}
          className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-mars-600 to-mars-500 hover:from-mars-500 hover:to-mars-400 text-white font-medium text-xs tracking-wide shadow-lg flex items-center justify-center gap-2 transition-all"
        >
          <span>🧭</span>
          <span>Plan a Marswalk Here (Mission Planner)</span>
        </button>

        <div className="flex items-center justify-between text-[11px] text-white/40 px-1 pt-1">
          <span>Source: NASA PDS & NSSDCA</span>
          <a
            href={site.officialUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-white/60 hover:text-white transition-colors"
          >
            Official Mission Page ↗
          </a>
        </div>
      </div>
    </motion.div>
  );
};
