/**
 * RightControls.tsx
 * Floating right-side toolbar: zoom in/out, compass reset, 2D/3D toggle,
 * home overview, measure distance tool, and fullscreen.
 */

import React, { useState } from 'react';
import { useGlobeStore } from '../../store/globeStore';
import { resetToGlobeView, resetNorth, toggleSceneMode } from '../../globe/CameraController';

export const RightControls: React.FC = () => {
  const viewer = useGlobeStore((s) => s.viewer);
  const is3D = useGlobeStore((s) => s.is3D);
  const toggleStore3D = useGlobeStore((s) => s.toggleSceneMode);
  const isMeasuring = useGlobeStore((s) => s.isMeasuring);
  const toggleMeasure = useGlobeStore((s) => s.toggleMeasure);

  const [isFullscreen, setIsFullscreen] = useState(false);

  const handleZoomIn = () => {
    if (!viewer) return;
    viewer.camera.zoomIn(viewer.camera.positionCartographic.height * 0.4);
  };

  const handleZoomOut = () => {
    if (!viewer) return;
    viewer.camera.zoomOut(viewer.camera.positionCartographic.height * 0.5);
  };

  const handleResetNorth = () => {
    if (viewer) resetNorth(viewer);
  };

  const handleHome = () => {
    if (viewer) resetToGlobeView(viewer);
  };

  const handleToggle3D = () => {
    if (!viewer) return;
    toggleSceneMode(viewer);
    toggleStore3D();
  };

  const handleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const controls = [
    { id: 'zoom-in', label: 'Zoom In (+)', icon: '＋', action: handleZoomIn },
    { id: 'zoom-out', label: 'Zoom Out (−)', icon: '－', action: handleZoomOut },
    { id: 'compass', label: 'Reset North (N)', icon: '🧭', action: handleResetNorth },
    { id: 'mode', label: is3D ? 'Switch to 2D Map' : 'Switch to 3D Globe', icon: is3D ? '🌐' : '🗺️', action: handleToggle3D },
    { id: 'home', label: 'Reset Orbit View (H)', icon: '🏠', action: handleHome },
    { id: 'measure', label: isMeasuring ? 'Exit Measure Tool' : 'Measure Distance', icon: '📏', action: toggleMeasure, active: isMeasuring },
    { id: 'fullscreen', label: isFullscreen ? 'Exit Fullscreen' : 'Fullscreen (F)', icon: isFullscreen ? '⤡' : '⤢', action: handleFullscreen },
  ];

  return (
    <div className="fixed right-4 top-20 z-20 flex flex-col items-center gap-1.5 p-1.5 rounded-2xl bg-space-950/75 border border-white/10 backdrop-blur-xl shadow-2xl select-none pointer-events-auto">
      {controls.map((btn) => (
        <div key={btn.id} className="relative group">
          <button
            onClick={btn.action}
            className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm font-semibold transition-all ${
              btn.active
                ? 'bg-mars-600 text-white shadow-[0_0_12px_rgba(232,82,26,0.6)]'
                : 'text-white/70 hover:text-white hover:bg-white/15'
            }`}
            aria-label={btn.label}
          >
            {btn.icon}
          </button>

          {/* Left-popping Tooltip */}
          <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-2.5 py-1 rounded-lg bg-space-900/95 border border-white/15 text-white text-[11px] font-medium whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity shadow-lg z-50">
            {btn.label}
          </div>
        </div>
      ))}
    </div>
  );
};
