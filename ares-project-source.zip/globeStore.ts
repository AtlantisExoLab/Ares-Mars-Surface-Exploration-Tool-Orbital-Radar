import { create } from 'zustand';

export interface GlobeStore {
  // Viewer ref
  viewer: any | null; // Cesium.Viewer
  setViewer: (v: any) => void;

  // Active site
  selectedSiteId: string | null;
  setSelectedSite: (id: string | null) => void;

  // Active panel
  activePanel: 'search' | 'layers' | 'sites' | 'planner' | 'settings' | 'radar' | 'nasa-resources' | 'live-images' | null;
  setActivePanel: (p: GlobeStore['activePanel']) => void;

  // Orbital Radar (moons & spacecraft)
  showOrbits: boolean;
  toggleOrbits: () => void;
  selectedOrbitalBodyId: string | null;
  setSelectedOrbitalBody: (id: string | null) => void;

  // Solar Illumination mode
  solarLighting: boolean;
  toggleSolarLighting: () => void;

  // Layers
  layerOpacities: Record<string, number>;
  setLayerOpacity: (id: string, opacity: number) => void;
  layerVisibility: Record<string, boolean>;
  toggleLayer: (id: string) => void;

  // Camera state
  cameraAltKm: number;
  setCameraAlt: (km: number) => void;
  cursorLat: number | null;
  cursorLon: number | null;
  cursorElevation: number | null;
  setCursorInfo: (lat: number | null, lon: number | null, elev: number | null) => void;

  // Scene mode
  is3D: boolean;
  toggleSceneMode: () => void;

  // Terrain exaggeration
  terrainExaggeration: number;
  setTerrainExaggeration: (v: number) => void;

  // Measure mode
  isMeasuring: boolean;
  toggleMeasure: () => void;
}

export const useGlobeStore = create<GlobeStore>((set) => ({
  viewer: null,
  setViewer: (v) => set({ viewer: v }),

  selectedSiteId: null,
  setSelectedSite: (id) => set({ selectedSiteId: id }),

  activePanel: null,
  setActivePanel: (p) =>
    set((state) => ({
      activePanel: state.activePanel === p ? null : p,
    })),

  solarLighting: false,
  toggleSolarLighting: () => set((state) => ({ solarLighting: !state.solarLighting })),

  layerOpacities: {
    'viking-mdim21': 100,
    'mola-shaded-relief': 80,
    'mola-color-dem': 75,
    'themis-day-ir': 75,
    'themis-night-ir': 75,
    'mola-roughness': 65,
    'tes-thermal-inertia': 65,
  },
  setLayerOpacity: (id, opacity) =>
    set((state) => ({
      layerOpacities: { ...state.layerOpacities, [id]: opacity },
    })),

  layerVisibility: {
    'viking-mdim21': false,
    'mola-shaded-relief': false,
    'mola-color-dem': false,
    'themis-day-ir': false,
    'themis-night-ir': false,
    'mola-roughness': false,
    'tes-thermal-inertia': false,
  },
  toggleLayer: (id) =>
    set((state) => {
      const current = Boolean(state.layerVisibility[id]);
      return {
        layerVisibility: {
          ...state.layerVisibility,
          [id]: !current,
        },
      };
    }),

  cameraAltKm: 3000,
  setCameraAlt: (km) => set({ cameraAltKm: km }),

  cursorLat: null,
  cursorLon: null,
  cursorElevation: null,
  setCursorInfo: (lat, lon, elev) =>
    set({ cursorLat: lat, cursorLon: lon, cursorElevation: elev }),

  is3D: true,
  toggleSceneMode: () => set((state) => ({ is3D: !state.is3D })),

  terrainExaggeration: 1,
  setTerrainExaggeration: (v) => set({ terrainExaggeration: v }),

  isMeasuring: false,
  toggleMeasure: () => set((state) => ({ isMeasuring: !state.isMeasuring })),

  showOrbits: true,
  toggleOrbits: () => set((state) => ({ showOrbits: !state.showOrbits })),
  selectedOrbitalBodyId: null,
  setSelectedOrbitalBody: (id) => set({ selectedOrbitalBodyId: id }),
}));
