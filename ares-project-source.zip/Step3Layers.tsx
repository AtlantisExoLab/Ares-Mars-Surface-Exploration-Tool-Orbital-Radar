/**
 * Step3Layers.tsx
 * Mission Planner Step 3: Multi-Sensor Data Layer Selection.
 * Requires combining at least 3 complementary data types (optical, thermal, topographic, spectral).
 */

import React, { useMemo } from 'react';
import { useGlobeStore } from '../../../store/globeStore';
import { LAYER_CONFIGS, type LayerId } from '../../../globe/MarsImagery';

export const Step3Layers: React.FC = () => {
  const layerVisibility = useGlobeStore((s) => s.layerVisibility);
  const layerOpacities = useGlobeStore((s) => s.layerOpacities);
  const toggleLayer = useGlobeStore((s) => s.toggleLayer);
  const setLayerOpacity = useGlobeStore((s) => s.setLayerOpacity);

  // Group active layers by type
  const activeCategories = useMemo(() => {
    const cats = new Set<string>();
    Object.keys(LAYER_CONFIGS).forEach((id) => {
      const lid = id as LayerId;
      const isVis = Boolean(layerVisibility[lid]);
      if (isVis) {
        cats.add(LAYER_CONFIGS[lid].type);
      }
    });
    return Array.from(cats);
  }, [layerVisibility]);

  const categoryMet = activeCategories.length >= 3;

  const layerJustifications: Record<LayerId, string> = {
    'viking-mdim21': 'Provides global true-colour context and broad landmark identification.',
    'mola-shaded-relief': 'Accurate slope and topographic shading essential for identifying cliff scarps and traversable inclines.',
    'mola-color-dem': 'Elevation false-colour coding for ascent/descent energy management.',
    'themis-day-ir': 'Thermal inertia distinguishing exposed bedrock from loose, wheel-trapping fine dust.',
    'themis-night-ir': 'Night-time thermal retention pinpointing solid rock outcrops vs sandy mantles.',
    'mola-roughness': 'MOLA baseline roughness evaluating surface vehicle trafficability and boulder hazards.',
    'tes-thermal-inertia': 'TES thermal inertia mapping surface particle grain size and consolidated crust.',
  };

  return (
    <div className="space-y-6 text-xs text-white/80">
      <div className="p-3.5 rounded-xl bg-space-800/60 border border-white/10 space-y-1">
        <div className="font-semibold text-white flex items-center gap-1.5">
          <span>🛰️</span>
          <span>3. Multi-Sensor Data Fusion (≥ 3 Categories)</span>
        </div>
        <p className="text-white/60 leading-relaxed text-[11px]">
          Combine optical imagery with thermal inertia, elevation topography, and mineral spectral maps to ensure optimal hazard avoidance and science targeting.
        </p>
      </div>

      {/* Categories Progress Requirement Bar */}
      <div
        className={`p-3 rounded-xl border flex items-center justify-between transition-colors ${
          categoryMet
            ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
            : 'bg-amber-950/40 border-amber-500/40 text-amber-300'
        }`}
      >
        <div className="flex items-center gap-2">
          <span>{categoryMet ? '✓' : '⚠️'}</span>
          <span className="font-medium">
            Active Data Types: {activeCategories.length} of 3 required
          </span>
        </div>
        <div className="flex items-center gap-1 font-mono text-[10px] uppercase">
          {['optical', 'topographic', 'thermal', 'spectral'].map((cat) => {
            const hasCat = activeCategories.includes(cat);
            return (
              <span
                key={cat}
                className={`px-1.5 py-0.5 rounded ${
                  hasCat ? 'bg-white/20 text-white font-bold' : 'bg-black/30 text-white/30'
                }`}
              >
                {cat.slice(0, 4)}
              </span>
            );
          })}
        </div>
      </div>

      {/* Layer Controls */}
      <div className="space-y-2.5">
        {Object.values(LAYER_CONFIGS).map((layer) => {
          const isVisible = Boolean(layerVisibility[layer.id]);
          const opacity = layerOpacities[layer.id] ?? layer.defaultOpacity * 100;

          return (
            <div
              key={layer.id}
              className={`p-3 rounded-xl border transition-all ${
                isVisible
                  ? 'bg-space-800/70 border-white/20 shadow-md'
                  : 'bg-space-900/40 border-white/5 opacity-70 hover:opacity-100'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={isVisible}
                    onChange={() => toggleLayer(layer.id)}
                    className="w-4 h-4 rounded accent-mars-500 cursor-pointer"
                  />
                  <span className="font-semibold text-white text-xs">{layer.name}</span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/10 text-white/60 uppercase">
                  {layer.type} · {layer.resolution}
                </span>
              </div>

              <div className="text-[11px] text-white/60 mb-2 pl-6">
                {layerJustifications[layer.id]}
              </div>

              {isVisible && (
                <div className="pl-6 flex items-center gap-3 pt-1 border-t border-white/5 text-[11px]">
                  <span className="text-white/40">Opacity:</span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={opacity}
                    onChange={(e) => setLayerOpacity(layer.id, Number(e.target.value))}
                    className="flex-1 accent-mars-500"
                  />
                  <span className="font-mono text-white/70 w-8 text-right">{opacity}%</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
