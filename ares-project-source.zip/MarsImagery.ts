/**
 * MarsImagery.ts
 *
 * Cesium imagery provider factories for Mars remote-sensing layers.
 * Uses official verified NASA Trek tile endpoints with direct CORS support
 * and high-fidelity planetary imagery layers.
 */

import {
  UrlTemplateImageryProvider,
  SingleTileImageryProvider,
  GeographicTilingScheme,
  Rectangle,
  Credit,
  Ellipsoid,
} from 'cesium';

export const MARS_ELLIPSOID = new Ellipsoid(3_396_190, 3_396_190, 3_376_200);

// ---------------------------------------------------------------------------
// Layer type definitions
// ---------------------------------------------------------------------------

export type LayerId =
  | 'viking-mdim21'
  | 'mola-shaded-relief'
  | 'mola-color-dem'
  | 'themis-day-ir'
  | 'themis-night-ir'
  | 'mola-roughness'
  | 'tes-thermal-inertia';

export interface LayerConfig {
  id: LayerId;
  name: string;
  description: string;
  type: 'optical' | 'thermal' | 'topographic' | 'geophysical';
  resolution: string;
  source: string;
  sourceUrl: string;
  license: string;
  defaultOpacity: number;
  defaultVisible: boolean;
}

// ---------------------------------------------------------------------------
// Layer metadata catalogue (all endpoints verified 200 OK from NASA Trek)
// ---------------------------------------------------------------------------

export const LAYER_CONFIGS: Record<LayerId, LayerConfig> = {
  'viking-mdim21': {
    id: 'viking-mdim21',
    name: 'Viking MDIM 2.1 (Colour Mosaic)',
    description:
      'Global colour mosaic compiled from Viking Orbiter images. NASA reference basemap showing the true colour of the Martian surface at ~232 m/px.',
    type: 'optical',
    resolution: '232 m/px',
    source: 'NASA Viking Orbiter / USGS Astrogeology',
    sourceUrl: 'https://trek.nasa.gov/mars',
    license: 'Public Domain (US Government Work)',
    defaultOpacity: 1.0,
    defaultVisible: true,
  },

  'mola-shaded-relief': {
    id: 'mola-shaded-relief',
    name: 'MOLA Shaded Relief + HRSC',
    description:
      'Mars Orbiter Laser Altimeter blended shaded-relief with Mars Express HRSC colour hillshading at 200 m/px. Highlights canyons, craters, and volcano scarps.',
    type: 'topographic',
    resolution: '200 m/px',
    source: 'NASA MOLA / ESA HRSC / USGS',
    sourceUrl: 'https://trek.nasa.gov/mars',
    license: 'Public Domain',
    defaultOpacity: 0.8,
    defaultVisible: false,
  },

  'mola-color-dem': {
    id: 'mola-color-dem',
    name: 'MOLA Colourised Elevation (DEM)',
    description:
      'Planetary elevation colour-coded from deep blue (Hellas Basin, −8 km) to white (Olympus Mons summit, +21 km). Derived from MGS MOLA altimetry.',
    type: 'topographic',
    resolution: '463 m/px',
    source: 'NASA MOLA / USGS Astrogeology',
    sourceUrl: 'https://trek.nasa.gov/mars',
    license: 'Public Domain',
    defaultOpacity: 0.75,
    defaultVisible: false,
  },

  'themis-day-ir': {
    id: 'themis-day-ir',
    name: 'THEMIS Day IR Mosaic',
    description:
      'Daytime infrared mosaic from 2001 Mars Odyssey THEMIS. Warm, rocky surfaces appear bright; fine-grained dust mantles appear dark.',
    type: 'thermal',
    resolution: '100 m/px',
    source: 'NASA Mars Odyssey / ASU / USGS',
    sourceUrl: 'https://trek.nasa.gov/mars',
    license: 'Public Domain',
    defaultOpacity: 0.75,
    defaultVisible: false,
  },

  'themis-night-ir': {
    id: 'themis-night-ir',
    name: 'THEMIS Night IR (Thermal Inertia)',
    description:
      'Nighttime infrared revealing thermal inertia: bedrock and boulder fields retain daytime warmth (bright), while unconsolidated dust cools rapidly (dark).',
    type: 'thermal',
    resolution: '100 m/px',
    source: 'NASA Mars Odyssey / ASU / USGS',
    sourceUrl: 'https://trek.nasa.gov/mars',
    license: 'Public Domain',
    defaultOpacity: 0.75,
    defaultVisible: false,
  },

  'mola-roughness': {
    id: 'mola-roughness',
    name: 'MOLA Surface Roughness',
    description:
      'Quantifies baseline terrain roughness and obstacles across 0.6 km to 2.4 km baselines, critical for evaluating astronaut rover mobility and rover hazard avoidance.',
    type: 'geophysical',
    resolution: '200 m/px',
    source: 'NASA MOLA / Goddard Space Flight Center',
    sourceUrl: 'https://trek.nasa.gov/mars',
    license: 'Public Domain',
    defaultOpacity: 0.65,
    defaultVisible: false,
  },

  'tes-thermal-inertia': {
    id: 'tes-thermal-inertia',
    name: 'TES Thermal Inertia (MGS)',
    description:
      'Thermal Emission Spectrometer global thermal inertia mapping particle grain size and surface crust consolidation across Martian plains.',
    type: 'geophysical',
    resolution: '3000 m/px',
    source: 'NASA MGS TES / Arizona State University',
    sourceUrl: 'https://trek.nasa.gov/mars',
    license: 'Public Domain',
    defaultOpacity: 0.65,
    defaultVisible: false,
  },
};

// ---------------------------------------------------------------------------
// Verified NASA Mars Trek WMTS layer specifications
// ---------------------------------------------------------------------------

interface TrekLayerSpec {
  trekName: string;
  ext: 'jpg' | 'png';
  maxLevel: number;
}

const TREK_SPECS: Record<LayerId, TrekLayerSpec> = {
  'viking-mdim21': {
    trekName: 'Mars_Viking_MDIM21_ClrMosaic_global_232m',
    ext: 'jpg',
    maxLevel: 7,
  },
  'mola-shaded-relief': {
    trekName: 'Mars_MOLA_blend200ppx_HRSC_ClrShade_clon0dd_200mpp_lzw',
    ext: 'jpg',
    maxLevel: 7,
  },
  'mola-color-dem': {
    trekName: 'Mars_MGS_MOLA_ClrShade_merge_global_463m',
    ext: 'jpg',
    maxLevel: 6,
  },
  'themis-day-ir': {
    trekName: 'THEMIS_DayIR_ControlledMosaics_100m_v2_oct2018',
    ext: 'png',
    maxLevel: 7,
  },
  'themis-night-ir': {
    trekName: 'THEMIS_NightIR_ControlledMosaics_100m_v2_oct2018',
    ext: 'png',
    maxLevel: 7,
  },
  'mola-roughness': {
    trekName: 'mola_roughness',
    ext: 'png',
    maxLevel: 5,
  },
  'tes-thermal-inertia': {
    trekName: 'TES_Thermal_Inertia',
    ext: 'png',
    maxLevel: 5,
  },
};

// ---------------------------------------------------------------------------
// Providers
// ---------------------------------------------------------------------------

/**
 * Creates the photorealistic base layer provider using NASA's authentic 4096x2048 Viking MDIM 2.1 Color Mosaic.
 * Rendered in an exact 2:1 cylindrical equirectangular projection (-180 to 180, -90 to 90)
 * matching NASA's true Martian geography and coordinates.
 */
export function createMarsBaseImageryProvider(): SingleTileImageryProvider {
  return new SingleTileImageryProvider({
    url: '/textures/mars_viking_equirectangular_4096.jpg',
    rectangle: Rectangle.fromDegrees(-180, -90, 180, 90),
    credit: new Credit('NASA / USGS Astrogeology — Mars Viking MDIM 2.1 Color Global Mosaic (4K)', false),
    tileWidth: 4096,
    tileHeight: 2048,
  });
}

/**
 * Creates a Cesium imagery provider for high-resolution streaming NASA Trek Mars layers.
 * Uses GeographicTilingScheme(2x1 at zoom 0) matching NASA Trek's standard WMTS layout.
 */
export function createMarsImageryProvider(
  layerId: LayerId,
): UrlTemplateImageryProvider | null {
  const config = LAYER_CONFIGS[layerId];
  const spec = TREK_SPECS[layerId];
  if (!config || !spec) return null;

  try {
    const tilingScheme = new GeographicTilingScheme({
      ellipsoid: MARS_ELLIPSOID,
      numberOfLevelZeroTilesX: 2,
      numberOfLevelZeroTilesY: 1,
    });

    const baseHost = 'https://trek.nasa.gov';
    const url = `${baseHost}/tiles/Mars/EQ/${spec.trekName}/1.0.0/default/default028mm/{z}/{y}/{x}.${spec.ext}`;

    return new UrlTemplateImageryProvider({
      url,
      tilingScheme,
      rectangle: Rectangle.fromDegrees(-180, -90, 180, 90),
      minimumLevel: 0,
      maximumLevel: spec.maxLevel,
      credit: new Credit(`${config.name} — ${config.source}`, false),
    });
  } catch (err) {
    console.error(`[MarsImagery] Failed to create provider for "${layerId}":`, err);
    return null;
  }
}
