/**
 * marsTime.ts
 *
 * NASA GISS Mars24 standard algorithms for calculating:
 *  - Mars Sol Date (MSD)
 *  - Coordinated Mars Time (MTC)
 *  - Local Mean Solar Time (LMST) for any Mars longitude
 *  - Solar Longitude (Ls) and Martian seasons
 *  - Mission Sols for active rovers (Perseverance & Curiosity)
 *
 * Reference: Allison, M., and M. McEwen 2000. A post-Pathfinder evaluation of
 * areocentric solar coordinates with improved timing recipes for Mars seasonal/diurnal climate.
 * Planet. Space Sci., 48, 215-235.
 */

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Julian Date of J2000.0 epoch */
const JD_J2000 = 2451545.0;

/** Ratio of SI second length to Mars solar day (sol) */
const SOL_RATIO = 1.027491252;

/** Perseverance touchdown MSD: Feb 18, 2021 20:44 UTC -> MSD ~52333.1 */
export const PERSEVERANCE_LANDING_MSD = 52333.15;

/** Curiosity touchdown MSD: Aug 6, 2012 05:17 UTC -> MSD ~49268.2 */
export const CURIOSITY_LANDING_MSD = 49268.22;

/** Perseverance landing coordinates (Jezero Crater) */
export const JEZERO_LON_E = 77.45;

/** Curiosity landing coordinates (Gale Crater / Mount Sharp) */
export const GALE_LON_E = 137.38;

// ---------------------------------------------------------------------------
// Calculations
// ---------------------------------------------------------------------------

/**
 * Calculates the current Mars Sol Date (MSD) from a JavaScript Date.
 */
export function getMarsSolDate(date: Date = new Date()): number {
  const timeMs = date.getTime();
  // Julian Date in UTC
  const jdUT = 2440587.5 + timeMs / 86400000;
  // Terrestrial Time offset (leap seconds approx ~69.184s)
  const jdTT = jdUT + 69.184 / 86400;
  // Days since J2000.0
  const deltaJ2000 = jdTT - JD_J2000;
  // MSD equation (NASA GISS Mars24)
  const msd = (deltaJ2000 - 4.5) / SOL_RATIO + 44796.0 - 0.00096;
  return msd;
}

/**
 * Calculates Coordinated Mars Time (MTC) in decimal hours (0 to 24).
 */
export function getMTC(date: Date = new Date()): number {
  const msd = getMarsSolDate(date);
  return (24 * msd) % 24;
}

/**
 * Calculates Local Mean Solar Time (LMST) in decimal hours (0 to 24)
 * for a given planetocentric east longitude (0 to 360°).
 */
export function getLMST(lonEastDeg: number, date: Date = new Date()): number {
  const mtc = getMTC(date);
  let lmst = (mtc + (lonEastDeg * 24) / 360) % 24;
  if (lmst < 0) lmst += 24;
  return lmst;
}

/**
 * Formats decimal hours as "HH:MM:SS".
 */
export function formatMarsTime(decimalHours: number): string {
  const totalSec = Math.floor(decimalHours * 3600);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

/**
 * Calculates the Solar Longitude (Ls) in degrees (0 to 360°),
 * which determines the season on Mars.
 */
export function getSolarLongitude(date: Date = new Date()): number {
  const timeMs = date.getTime();
  const jdUT = 2440587.5 + timeMs / 86400000;
  const jdTT = jdUT + 69.184 / 86400;
  const deltaJ2000 = jdTT - JD_J2000;

  // Mars Mean Anomaly M in radians
  const M = ((19.387 + 0.52402075 * deltaJ2000) * Math.PI) / 180;

  // Fictitious Mean Sun alpha_FMS
  const alphaFMS = 270.3863 + 0.5240384 * deltaJ2000;

  // Equation of center perturbation v - M
  const vMinusM =
    (10.691 + 3.0e-7 * deltaJ2000) * Math.sin(M) +
    0.623 * Math.sin(2 * M) +
    0.05 * Math.sin(3 * M) +
    0.005 * Math.sin(4 * M);

  // Solar longitude Ls
  let ls = (alphaFMS + vMinusM) % 360;
  if (ls < 0) ls += 360;
  return parseFloat(ls.toFixed(1));
}

/**
 * Returns human-readable Martian seasonal description from Solar Longitude (Ls).
 */
export function getMarsSeason(ls: number): string {
  if (ls >= 0 && ls < 90) return 'Northern Spring / Southern Autumn';
  if (ls >= 90 && ls < 180) return 'Northern Summer / Southern Winter (Aphelion)';
  if (ls >= 180 && ls < 270) return 'Northern Autumn / Southern Spring';
  return 'Northern Winter / Southern Summer (Perihelion & Dust Season)';
}

/**
 * Returns the current mission Sol for a rover.
 */
export function getMissionSol(landingMSD: number, currentMSD: number = getMarsSolDate()): number {
  return Math.floor(currentMSD - landingMSD);
}
