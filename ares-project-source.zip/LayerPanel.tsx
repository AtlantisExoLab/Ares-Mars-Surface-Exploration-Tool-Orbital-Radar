/**
 * LayerPanel.tsx
 * Solid, high-contrast, fully opaque layer manager providing toggling,
 * opacity adjustments, and detailed scientific layer specifications.
 * Completely eliminates background surface bleed-through for crystal-clear readability.
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGlobeStore } from '../../store/globeStore';
import { LAYER_CONFIGS, type LayerConfig } from '../../globe/MarsImagery';
import { LayerToggle } from './LayerToggle';

export const LayerPanel: React.FC = () => {
  const layerVisibility = useGlobeStore((s) => s.layerVisibility);
  const layerOpacities = useGlobeStore((s) => s.layerOpacities);
  const toggleLayer = useGlobeStore((s) => s.toggleLayer);
  const setLayerOpacity = useGlobeStore((s) => s.setLayerOpacity);
  const setActivePanel = useGlobeStore((s) => s.setActivePanel);

  const [activeInfoLayer, setActiveInfoLayer] = useState<LayerConfig | null>(null);

  const opticalLayers = Object.values(LAYER_CONFIGS).filter((l) => l.type === 'optical');
  const scienceLayers = Object.values(LAYER_CONFIGS).filter((l) => l.type !== 'optical');

  return (
    <motion.div
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: -20, opacity: 0 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="fixed top-16 left-20 w-84 md:w-96 bottom-16 bg-[#0a0d14] border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col z-30 overflow-hidden pointer-events-auto"
    >
      {/* Solid Opaque Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-slate-700/80 bg-[#0f1420] flex-shrink-0">
        <div className="flex items-center gap-2.5">
          <span className="text-xl">🗂️</span>
          <div>
            <h2 className="text-white font-display font-bold text-base tracking-wide">
              Planetary Data Layers
            </h2>
            <div className="text-slate-400 text-xs">
              NASA Mars Trek & USGS Multi-Spectral Products
            </div>
          </div>
        </div>
        <button
          onClick={() => setActivePanel(null)}
          className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          title="Close"
          aria-label="Close"
        >
          ✕
        </button>
      </div>

      {/* Layer List Scroll Area */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6 bg-[#0a0d14]">
        {/* Optical & Basemap Group */}
        <div>
          <div className="text-[11px] font-mono font-bold tracking-wider text-slate-400 uppercase mb-2.5 px-1 flex items-center gap-2">
            <span>📷</span>
            <span>Visible Basemaps & Optical</span>
          </div>
          <div className="space-y-2.5">
            {opticalLayers.map((cfg) => (
              <LayerToggle
                key={cfg.id}
                layerId={cfg.id}
                config={cfg}
                isVisible={Boolean(layerVisibility[cfg.id])}
                opacity={layerOpacities[cfg.id] ?? cfg.defaultOpacity * 100}
                onToggle={() => toggleLayer(cfg.id)}
                onOpacityChange={(v) => setLayerOpacity(cfg.id, v)}
                onInfoClick={() => setActiveInfoLayer(cfg)}
              />
            ))}
          </div>
        </div>

        {/* Science & Spectral Group */}
        <div>
          <div className="text-[11px] font-mono font-bold tracking-wider text-slate-400 uppercase mb-2.5 px-1 flex items-center gap-2">
            <span>📡</span>
            <span>Topographic, Thermal & Spectral</span>
          </div>
          <div className="space-y-2.5">
            {scienceLayers.map((cfg) => (
              <LayerToggle
                key={cfg.id}
                layerId={cfg.id}
                config={cfg}
                isVisible={Boolean(layerVisibility[cfg.id])}
                opacity={layerOpacities[cfg.id] ?? cfg.defaultOpacity * 100}
                onToggle={() => toggleLayer(cfg.id)}
                onOpacityChange={(v) => setLayerOpacity(cfg.id, v)}
                onInfoClick={() => setActiveInfoLayer(cfg)}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Solid Opaque Footer Attribution */}
      <div className="px-5 py-3 border-t border-slate-700/80 bg-[#0f1420] text-xs text-slate-400 flex items-center justify-between flex-shrink-0">
        <span>NASA Mars Trek · 200 OK WMTS</span>
        <div className="flex items-center gap-3">
          <a
            href="https://worldview.earthdata.nasa.gov/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors"
          >
            NASA Worldview ↗
          </a>
          <a
            href="https://trek.nasa.gov/mars"
            target="_blank"
            rel="noopener noreferrer"
            className="text-mars-400 hover:text-mars-300 font-semibold transition-colors"
          >
            GetCapabilities ↗
          </a>
        </div>
      </div>

      {/* Solid, Fully Opaque Layer Scientific Specification Modal */}
      <AnimatePresence>
        {activeInfoLayer && (
          <div className="absolute inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-h-full bg-[#0d121f] border-2 border-slate-600 rounded-xl p-5 shadow-2xl flex flex-col justify-between overflow-y-auto text-white select-none"
            >
              <div>
                {/* Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-700 mb-3">
                  <span className="text-xs uppercase font-mono font-bold px-2.5 py-0.5 rounded bg-mars-500/20 text-mars-300 border border-mars-400/30">
                    {activeInfoLayer.type} DATA
                  </span>
                  <button
                    onClick={() => setActiveInfoLayer(null)}
                    className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors text-sm font-bold"
                  >
                    ✕
                  </button>
                </div>

                {/* Layer Title & Full Description */}
                <h3 className="text-white font-display font-bold text-lg mb-2">
                  {activeInfoLayer.name}
                </h3>
                <p className="text-slate-200 text-xs leading-relaxed mb-4 bg-[#141b2a] p-3 rounded-lg border border-slate-700/60">
                  {activeInfoLayer.description}
                </p>

                {/* Metadata Grid */}
                <div className="space-y-2 text-xs font-mono bg-[#111724] p-3 rounded-lg border border-slate-700/50">
                  <div className="flex justify-between items-center py-1 border-b border-slate-800">
                    <span className="text-slate-400">Resolution:</span>
                    <span className="text-cyan-300 font-bold">{activeInfoLayer.resolution}</span>
                  </div>
                  <div className="flex justify-between items-center py-1 border-b border-slate-800">
                    <span className="text-slate-400">Scientific Source:</span>
                    <span className="text-slate-200 font-medium">{activeInfoLayer.source}</span>
                  </div>
                  <div className="flex justify-between items-center py-1">
                    <span className="text-slate-400">Data License:</span>
                    <span className="text-emerald-400 font-medium">{activeInfoLayer.license}</span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="pt-4 mt-4 border-t border-slate-700 flex justify-between items-center text-xs">
                <div className="flex items-center gap-2">
                  <a
                    href={activeInfoLayer.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-mars-600/30 hover:bg-mars-600/50 text-mars-300 border border-mars-500/40 font-semibold transition-colors"
                  >
                    NASA Mars Trek Portal ↗
                  </a>
                  <a
                    href="https://worldview.earthdata.nasa.gov/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/40 text-cyan-300 border border-cyan-500/30 font-semibold transition-colors"
                  >
                    NASA Worldview ↗
                  </a>
                </div>
                <button
                  onClick={() => setActiveInfoLayer(null)}
                  className="px-4 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white font-semibold transition-colors"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
