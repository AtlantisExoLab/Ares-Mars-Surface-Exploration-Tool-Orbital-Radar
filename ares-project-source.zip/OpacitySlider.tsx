import React from 'react';

interface Props {
  value: number; // 0–100
  onChange: (v: number) => void;
  disabled?: boolean;
  id?: string;
}

export const OpacitySlider: React.FC<Props> = ({ value, onChange, disabled = false, id }) => {
  const pct = `${value}%`;

  return (
    <div className="flex items-center gap-2.5 w-full">
      <input
        id={id}
        type="range"
        min={0}
        max={100}
        step={1}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
        aria-label="Layer Opacity"
        className="flex-1 h-2 rounded-lg cursor-pointer accent-mars-500 bg-slate-700"
        style={{
          background: `linear-gradient(to right, #ea580c 0%, #ea580c ${pct}, #334155 ${pct}, #334155 100%)`,
        }}
      />
      <span className="min-w-9 text-right text-xs font-mono font-bold text-white tabular-nums">
        {Math.round(value)}%
      </span>
    </div>
  );
};

export default OpacitySlider;
