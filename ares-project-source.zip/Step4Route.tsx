/**
 * Step4Route.tsx
 * Mission Planner Step 4: Waypoint Plotting and A* Optimal Route Calculation.
 */

import React, { useState } from 'react';
import { usePlannerStore } from '../../../store/plannerStore';
import { autoRouteAStar } from '../../../routing/AStarRouter';

export const Step4Route: React.FC = () => {
  const waypoints = usePlannerStore((s) => s.waypoints);
  const addWaypoint = usePlannerStore((s) => s.addWaypoint);
  const removeWaypoint = usePlannerStore((s) => s.removeWaypoint);
  const isAddingWaypoints = usePlannerStore((s) => s.isAddingWaypoints);
  const setAddingWaypoints = usePlannerStore((s) => s.setAddingWaypoints);
  const getTotalDistanceKm = usePlannerStore((s) => s.getTotalDistanceKm);
  const baseLocation = usePlannerStore((s) => s.baseLocation);

  const [isRouting, setIsRouting] = useState(false);

  const totalDist = getTotalDistanceKm();

  const handleAutoRoute = async () => {
    if (waypoints.length < 2) return;
    setIsRouting(true);

    try {
      const start = waypoints[0];
      const end = waypoints[waypoints.length - 1];
      const smoothPath = await autoRouteAStar(start, end, 6);

      // Reconstruct intermediate waypoints avoiding hazardous slopes
      const newWaypoints = [
        start,
        ...smoothPath.slice(1, -1).map((pt, i) => ({
          id: `auto-wp-${Date.now()}-${i}`,
          lat: pt.lat,
          lon: pt.lon,
          label: `A* Traverse WP ${i + 1}`,
          note: `Slope ~${pt.slopeDeg}°`,
        })),
        end,
      ];

      usePlannerStore.setState({ waypoints: newWaypoints });
    } catch (e) {
      console.error('[Step4Route] Auto-routing error:', e);
    } finally {
      setIsRouting(false);
    }
  };

  const handleClear = () => {
    usePlannerStore.setState({ waypoints: [] });
  };

  const handleAddSampleWp = () => {
    const latBase = baseLocation ? baseLocation.lat : -4.68;
    const lonBase = baseLocation ? baseLocation.lon : 137.38;
    const offset = (waypoints.length + 1) * 0.007;
    addWaypoint(latBase + offset, lonBase + offset);
  };

  return (
    <div className="space-y-6 text-xs text-white/80">
      <div className="p-3.5 rounded-xl bg-space-800/60 border border-white/10 space-y-1">
        <div className="font-semibold text-white flex items-center gap-1.5">
          <span>🧭</span>
          <span>4. Surface Route Planning & Navigation</span>
        </div>
        <p className="text-white/60 leading-relaxed text-[11px]">
          Plot tactical traverse waypoints. The A* router continuously penalizes slopes exceeding 15° and avoids impassable scarps (&gt;30°).
        </p>
      </div>

      {/* Control Buttons Bar */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => setAddingWaypoints(!isAddingWaypoints)}
          className={`py-2.5 px-3 rounded-xl border font-medium text-xs flex items-center justify-center gap-2 transition-all ${
            isAddingWaypoints
              ? 'bg-mars-600 border-mars-400 text-white shadow-lg animate-pulse'
              : 'bg-space-800/60 border-white/15 text-white/80 hover:bg-space-700/80 hover:text-white'
          }`}
        >
          <span>📍</span>
          <span>{isAddingWaypoints ? 'Click Globe to Add' : '+ Add Waypoints Mode'}</span>
        </button>

        <button
          onClick={handleAutoRoute}
          disabled={waypoints.length < 2 || isRouting}
          className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-40 text-white font-medium text-xs flex items-center justify-center gap-2 transition-all shadow-md"
        >
          <span>⚡</span>
          <span>{isRouting ? 'Computing A* Path...' : 'A* Auto-Route'}</span>
        </button>
      </div>

      {/* Quick Add sample buttons if no waypoints */}
      {waypoints.length === 0 && (
        <div className="p-4 rounded-xl bg-space-950/60 border border-dashed border-white/15 text-center space-y-3">
          <p className="text-white/50 text-[11px]">
            No waypoints plotted yet. Click directly on the Mars globe in Add mode or generate an initial point.
          </p>
          <button
            onClick={handleAddSampleWp}
            className="px-4 py-2 rounded-lg bg-mars-600/30 hover:bg-mars-600/50 text-mars-200 border border-mars-500/40 text-xs font-medium transition-colors"
          >
            + Create Waypoint at Base Location
          </button>
        </div>
      )}

      {/* Route Stats Summary */}
      {waypoints.length > 0 && (
        <div className="p-3 rounded-xl bg-space-950/80 border border-white/10 flex items-center justify-between text-xs">
          <div>
            <div className="text-[10px] text-white/40 uppercase font-mono">Traverse Length</div>
            <div className="text-lg font-bold text-white font-display mt-0.5">
              {totalDist.toFixed(2)} <span className="text-xs font-normal text-white/60">km</span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-white/40 uppercase font-mono">Total Waypoints</div>
            <div className="text-lg font-bold text-mars-400 font-mono mt-0.5">
              {waypoints.length}
            </div>
          </div>
          <button
            onClick={handleClear}
            className="px-2.5 py-1 rounded-md text-[10px] text-rose-400 hover:bg-rose-950/50 border border-rose-500/30 transition-colors"
          >
            Clear All
          </button>
        </div>
      )}

      {/* Waypoints Manifest List */}
      <div className="space-y-2">
        {waypoints.map((wp, index) => (
          <div
            key={wp.id}
            className="p-3 rounded-xl bg-space-800/40 border border-white/10 flex items-center justify-between gap-3 text-xs"
          >
            <div className="flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-full bg-mars-600/30 text-mars-400 border border-mars-500/40 flex items-center justify-center font-mono text-[11px] font-bold">
                W{index + 1}
              </span>
              <div>
                <div className="font-semibold text-white">{wp.label}</div>
                <div className="text-[10px] font-mono text-white/40">
                  {wp.lat >= 0 ? `${wp.lat.toFixed(3)}°N` : `${Math.abs(wp.lat).toFixed(3)}°S`},{' '}
                  {wp.lon.toFixed(3)}°E
                </div>
              </div>
            </div>

            <button
              onClick={() => removeWaypoint(wp.id)}
              className="text-white/40 hover:text-rose-400 p-1 transition-colors"
              title="Remove waypoint"
            >
              ✕
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
