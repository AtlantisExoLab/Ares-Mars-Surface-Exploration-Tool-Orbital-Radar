import React from 'react';

interface Props {
  source: string;
  url: string;
  license?: string;
}

export const AttributionTag: React.FC<Props> = ({ source, url, license }) => (
  <span style={{ color: 'var(--color-text-dim)', fontSize: 11 }}>
    Source:{' '}
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      style={{ color: 'var(--color-text-muted)', textDecoration: 'underline' }}
    >
      {source}
    </a>
    {license && ` (${license})`}
  </span>
);

export default AttributionTag;
