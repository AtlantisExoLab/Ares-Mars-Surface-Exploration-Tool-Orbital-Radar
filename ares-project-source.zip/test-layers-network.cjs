const { chromium } = require('playwright');

async function testNetwork() {
  const browser = await chromium.launch({
    headless: true,
    executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  });

  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  const tileRequests = [];
  page.on('request', (req) => {
    const url = req.url();
    if (url.includes('tiles/Mars') || url.includes('wmts') || url.includes('MOLA') || url.includes('trek')) {
      tileRequests.push({ url, method: req.method() });
    }
  });

  page.on('response', (res) => {
    const url = res.url();
    if (url.includes('tiles/Mars') || url.includes('wmts') || url.includes('MOLA') || url.includes('trek')) {
      console.log('TILE RESPONSE:', res.status(), res.headers()['content-type'], url);
    }
  });

  await page.goto('http://127.0.0.1:4173/');
  const skip = await page.waitForSelector('button:has-text("Skip Intro")', { timeout: 8000 }).catch(() => null);
  if (skip) await skip.click();

  await page.waitForSelector('canvas', { timeout: 15000 });
  await page.waitForTimeout(2000);

  // Open Layers Panel
  const layersBtn = await page.waitForSelector('button[aria-label="Data Layers"]', { timeout: 8000 });
  await layersBtn.click();
  await page.waitForTimeout(1000);

  // Click MOLA Shaded Relief
  console.log('Clicking MOLA Shaded Relief...');
  const molaToggle = await page.waitForSelector('button:has-text("MOLA Shaded Relief")', { timeout: 5000 });
  await molaToggle.click();
  await page.waitForTimeout(4000);

  console.log(`Total tile requests captured: ${tileRequests.length}`);
  for (const r of tileRequests.slice(0, 5)) {
    console.log('REQ:', r.url);
  }

  await browser.close();
}

testNetwork().catch(console.error);
