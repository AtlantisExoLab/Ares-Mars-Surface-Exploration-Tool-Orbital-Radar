/**
 * StatusBar.tsx
 * Bottom HUD status bar displaying real-time cursor coordinates on Mars,
 * elevation, camera altitude, dynamic scale bar, and data attribution.
 */

import React, { useState, useEffect } from 'react';
import { useGlobeStore } from '../../store/globeStore';
import { formatMarsCoords, formatElevation, formatAltitude } from '../../globe/CoordinateUtils';
import { ScaleBar } from '../common/ScaleBar';
import { AttributionModal } from '../settings/AttributionModal';

export const StatusBar: React.FC = () => {
  const cursorLat = useGlobeStore((s) => s.cursorLat);
  const cursorLon = useGlobeStore((s) => s.cursorLon);
  const cursorElevation = useGlobeStore((s) => s.cursorElevation);
  const cameraAltKm = useGlobeStore((s) => s.cameraAltKm);

  const [viewportWidth, setViewportWidth] = useState(window.innerWidth);
  const [showAttribution, setShowAttribution] = useState(false);

  useEffect(() => {
    const handleResize = () => setViewportWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
      <footer className="fixed bottom-0 left-0 right-0 h-8 bg-space-950/90 border-t border-white/10 backdrop-blur-xl px-4 flex items-center justify-between text-[11px] font-mono text-white/60 z-40 select-none pointer-events-auto">
        {/* Left: Cursor Martian Coordinates & Elevation */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="text-mars-400">●</span>
            {cursorLat !== null && cursorLon !== null ? (
              <span className="text-white/90 font-medium">
                {formatMarsCoords(cursorLat, cursorLon)}
              </span>
            ) : (
              <span className="text-white/40">Hover over globe</span>
            )}
          </div>

          <div className="hidden sm:flex items-center gap-1.5">
            <span className="text-white/40">Elev:</span>
            <span className="text-white/80">
              {cursorElevation !== null ? formatElevation(cursorElevation) : '—'}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-white/40">Alt:</span>
            <span className="text-white/80">{formatAltitude(cameraAltKm * 1000)}</span>
          </div>
        </div>

        {/* Center / Right: Dynamic Scale Bar */}
        <div className="hidden md:flex items-center gap-3">
          <ScaleBar cameraAltKm={cameraAltKm} viewportWidthPx={viewportWidth} />
        </div>

        {/* Right: Data Credit Link */}
        <div className="flex items-center gap-3">
          <span className="hidden lg:inline text-white/40">
            Mars 2000 Planetocentric Datum
          </span>
          <button
            onClick={() => setShowAttribution(true)}
            className="text-mars-400 hover:text-mars-300 font-sans transition-colors"
          >
            Data: NASA · USGS · ESA ↗
          </button>
        </div>
      </footer>

      {showAttribution && (
        <AttributionModal onClose={() => setShowAttribution(false)} />
      )}
    </>
  );
};
