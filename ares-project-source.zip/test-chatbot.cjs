/**
 * test-chatbot.cjs
 *
 * Automated Playwright test verifying:
 *  1. Exactly ONE button exists in the application to open the chatbot
 *  2. Opening the chatbot reveals the ARES MARS AI (Gemini) interface
 *  3. Recommendation questions related to Mars missions are present
 *  4. API key configuration interface is available
 *  5. Chat message submission and close behavior works smoothly
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const ARTIFACT_DIR = 'C:/Users/ASUS/.gemini/antigravity/brain/241b2067-f433-487e-8a7d-f9567a8dfe1a';

function getEdgePath() {
  const edgePaths = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  ];
  for (const p of edgePaths) {
    if (fs.existsSync(p)) return p;
  }
  return undefined;
}

async function runChatbotTests() {
  console.log('====================================================');
  console.log('🚀 ARES MARS AI (GEMINI) CHATBOT — AUTOMATED TEST');
  console.log('====================================================');

  const browser = await chromium.launch({
    headless: true,
    executablePath: getEdgePath(),
    args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-webgl', '--no-sandbox'],
  });

  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 },
  });

  const page = await context.newPage();

  try {
    console.log('Navigating to http://127.0.0.1:4173/ ...');
    await page.goto('http://127.0.0.1:4173/', { waitUntil: 'networkidle', timeout: 30000 });

    // Skip intro
    const skipBtn = await page.waitForSelector('button:has-text("Skip Intro")', { timeout: 8000 }).catch(() => null);
    if (skipBtn) {
      await skipBtn.click();
      console.log('✓ Transitioned past intro screen.');
    }
    
    // Wait for AppShell and Cesium viewer to be ready
    console.log('Waiting for AppShell and Mars AI launch button to mount...');
    await page.waitForSelector('button[aria-label="Open Mars AI Chatbot"]', { timeout: 20000 });
    await page.waitForTimeout(1000);

    // 1. Verify ONLY ONE button exists to open the chatbot
    console.log('Verifying single chatbot opening button constraint...');
    const chatLaunchButtons = await page.$$('button:has-text("Mars AI"), button[title*="Chatbot"], button[aria-label="Open Mars AI Chatbot"]');
    console.log(`Found ${chatLaunchButtons.length} chatbot launch button(s) in the application.`);
    if (chatLaunchButtons.length !== 1) {
      throw new Error(`Expected exactly 1 button to open the chatbot, but found ${chatLaunchButtons.length}!`);
    }
    console.log('✓ Verified: Exactly ONE button exists in the entire application to open the chatbot.');

    // 2. Open Chatbot
    console.log('Clicking the single chatbot launch button...');
    await chatLaunchButtons[0].click();
    await page.waitForTimeout(1000);

    // 3. Verify Chatbot Drawer & Gemini branding
    const headerTitle = await page.waitForSelector('text=ARES MARS AI', { timeout: 5000 });
    const geminiBadge = await page.waitForSelector('text=GEMINI', { timeout: 5000 });
    console.log('✓ Verified: ARES MARS AI chatbot drawer active with Gemini branding:', !!headerTitle && !!geminiBadge);

    // 4. Verify Recommendation Questions on Mars Missions
    console.log('Checking recommended Mars mission questions...');
    const recommendations = [
      'Perseverance at Jezero Crater',
      'Curiosity',
      'Viking 1 & 2',
      'Ingenuity',
      'Zhurong',
    ];

    for (const rec of recommendations) {
      const match = await page.$(`text=${rec}`);
      console.log(`✓ Verified recommendation present: "${rec}":`, !!match);
    }

    // 5. Test API Key Configuration button & tray
    console.log('Testing Gemini API key configuration tray...');
    const keyConfigBtn = await page.$('button[title*="Gemini API Key"]');
    if (keyConfigBtn) {
      await keyConfigBtn.click();
      await page.waitForTimeout(500);
      const keyInput = await page.$('input[placeholder*="AIzaSy"], input[placeholder*="••••"]');
      console.log('✓ Verified: Gemini API key input tray opened:', !!keyInput);
      // Close tray
      await keyConfigBtn.click();
      await page.waitForTimeout(300);
    }

    // 6. Test sending a recommended question and verify it does NOT ask for an API key
    console.log('Clicking a recommended Mars mission question...');
    const recButton = await page.$('button:has-text("Perseverance at Jezero Crater")');
    if (recButton) {
      await recButton.click();
      await page.waitForTimeout(2000);

      // Verify user message appeared in stream
      const userMsg = await page.$('text=Perseverance at Jezero Crater');
      console.log('✓ Verified: Recommended question transmitted into chat stream:', !!userMsg);

      // Verify AI response arrived
      const aiResponse = await page.waitForSelector('text=Jezero Crater', { timeout: 6000 });
      console.log('✓ Verified: AI assistant answered question with scientific data:', !!aiResponse);

      // Verify NO error demanding API key
      const keyDemand = await page.$('text=Google Gemini API Key Required');
      if (keyDemand) {
        throw new Error('FAILED: Chatbot is asking for an API key!');
      }
      console.log('✓ Verified: Chatbot answered directly WITHOUT asking for an API key!');
    }

    // 6b. Test typing a custom question
    console.log('Typing a custom question: "How does MOXIE produce oxygen?" ...');
    const textarea = await page.$('textarea[placeholder*="Ask"]');
    if (textarea) {
      await textarea.fill('How does MOXIE produce oxygen?');
      await page.keyboard.press('Enter');
      await page.waitForTimeout(2000);

      // Verify MOXIE answer arrived
      const moxieAnswer = await page.waitForSelector('text=Solid Oxide Electrolysis', { timeout: 6000 });
      console.log('✓ Verified: Custom question answered directly with technical details:', !!moxieAnswer);

      // Verify NO error demanding API key
      const keyDemandCustom = await page.$('text=Google Gemini API Key Required');
      if (keyDemandCustom) {
        throw new Error('FAILED: Chatbot asked for an API key on custom question!');
      }
      console.log('✓ Verified: Custom question answered without asking for an API key!');
    }

    // 7. Capture Screenshot
    const shotPath = path.join(__dirname, '..', 'ares-chatbot-gemini-screenshot.png');
    await page.screenshot({ path: shotPath });
    console.log(`✓ Saved chatbot screenshot to ${shotPath}`);
    if (fs.existsSync(ARTIFACT_DIR)) {
      fs.copyFileSync(shotPath, path.join(ARTIFACT_DIR, 'ares-chatbot-gemini-screenshot.png'));
    }

    // 8. Test closing the chatbot drawer
    console.log('Testing close button (✕)...');
    const closeBtn = await page.$('button[title="Close Chatbot"]');
    if (closeBtn) {
      await closeBtn.click();
      await page.waitForTimeout(600);
      const isClosed = (await page.$('text=ARES MARS AI')) === null;
      console.log('✓ Verified: Chatbot drawer closed cleanly:', isClosed);
      // Verify single launcher button is visible again
      const reopenedBtn = await page.$('button:has-text("Mars AI")');
      console.log('✓ Verified: Single chatbot launch button reappeared at bottom-right:', !!reopenedBtn);
    }

    console.log('====================================================');
    console.log('🎉 ALL CHATBOT TESTS PASSED WITH 0 ERRORS!');
    console.log('====================================================');
  } catch (err) {
    console.error('❌ Chatbot test failed:', err);
    process.exit(1);
  } finally {
    await browser.close();
  }
}

runChatbotTests();
