/**
 * SitesSidebar.tsx
 * Comprehensive missions browser supporting both Surface Landers/Rovers and
 * Orbital Spacecraft with filtering by agency and operational status.
 */

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useGlobeStore } from '../../store/globeStore';
import { LANDING_SITES } from '../../data/landingSites';
import { ORBITERS } from '../../data/orbiters';
import { flyTo } from '../../globe/CameraController';
import type { LandingSite, OrbiterMission, MissionStatus } from '../../types/MarsTypes';

export const SitesSidebar: React.FC = () => {
  const viewer = useGlobeStore((s) => s.viewer);
  const selectedSiteId = useGlobeStore((s) => s.selectedSiteId);
  const setSelectedSite = useGlobeStore((s) => s.setSelectedSite);
  const setActivePanel = useGlobeStore((s) => s.setActivePanel);

  const [tab, setTab] = useState<'surface' | 'orbiters'>('surface');
  const [statusFilter, setStatusFilter] = useState<'all' | MissionStatus>('all');
  const [agencyFilter, setAgencyFilter] = useState<string>('all');

  const handleSelectSite = (site: LandingSite) => {
    setSelectedSite(site.id);
    if (viewer) {
      flyTo(viewer, site.lat, site.lon, 200, 2.2);
    }
  };

  const filteredSites = LANDING_SITES.filter((s) => {
    if (statusFilter !== 'all' && s.status !== statusFilter) return false;
    if (agencyFilter !== 'all' && !s.agency.toLowerCase().includes(agencyFilter.toLowerCase())) return false;
    return true;
  });

  const filteredOrbiters = ORBITERS.filter((o) => {
    if (statusFilter !== 'all' && o.status !== statusFilter) return false;
    if (agencyFilter !== 'all' && !o.agency.toLowerCase().includes(agencyFilter.toLowerCase())) return false;
    return true;
  });

  const getStatusBadge = (status: MissionStatus) => {
    if (status === 'active') {
      return (
        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-medium">
          ● Active
        </span>
      );
    }
    if (status === 'ended') {
      return (
        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-500/15 text-slate-300 border border-slate-500/30">
          Ended
        </span>
      );
    }
    return (
      <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30">
        Lost / Crashed
      </span>
    );
  };

  return (
    <motion.div
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: -20, opacity: 0 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="fixed top-16 left-20 w-80 md:w-96 bottom-16 bg-[#0a0d14] border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col z-30 overflow-hidden pointer-events-auto"
    >
      {/* Header */}
      <div className="px-5 py-4 border-b border-slate-700/80 bg-[#0f1420] flex items-center justify-between">
        <div>
          <h2 className="text-white font-display font-semibold text-base">Mars Missions</h2>
          <div className="text-white/50 text-xs">
            {tab === 'surface'
              ? `${LANDING_SITES.length} Surface Landings & Rovers`
              : `${ORBITERS.length} Orbital Explorers`}
          </div>
        </div>
        <button
          onClick={() => setActivePanel(null)}
          className="text-white/40 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          title="Close"
        >
          ✕
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10 bg-space-950/40">
        <button
          onClick={() => setTab('surface')}
          className={`flex-1 py-2.5 text-xs font-medium border-b-2 transition-colors ${
            tab === 'surface'
              ? 'border-mars-500 text-white bg-white/5'
              : 'border-transparent text-white/50 hover:text-white/80'
          }`}
        >
          📍 Surface ({LANDING_SITES.length})
        </button>
        <button
          onClick={() => setTab('orbiters')}
          className={`flex-1 py-2.5 text-xs font-medium border-b-2 transition-colors ${
            tab === 'orbiters'
              ? 'border-mars-500 text-white bg-white/5'
              : 'border-transparent text-white/50 hover:text-white/80'
          }`}
        >
          🛰️ Orbiters ({ORBITERS.length})
        </button>
      </div>

      {/* Filters */}
      <div className="p-3 border-b border-white/10 bg-space-900/50 space-y-2">
        {/* Status filter chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {(['all', 'active', 'ended', 'lost'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-2.5 py-1 rounded-lg capitalize transition-colors ${
                statusFilter === s
                  ? 'bg-mars-500 text-white font-medium'
                  : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white'
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Agency filter chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
          {(['all', 'NASA', 'ESA', 'CNSA', 'USSR', 'ISRO', 'UAESA'] as const).map((a) => (
            <button
              key={a}
              onClick={() => setAgencyFilter(a)}
              className={`px-2 py-0.5 rounded-md transition-colors ${
                agencyFilter === a
                  ? 'bg-white/20 text-white font-medium'
                  : 'bg-white/5 text-white/40 hover:bg-white/10 hover:text-white/70'
              }`}
            >
              {a}
            </button>
          ))}
        </div>
      </div>

      {/* Mission List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
        {tab === 'surface' ? (
          filteredSites.map((site) => {
            const isSelected = selectedSiteId === site.id;
            return (
              <button
                key={site.id}
                onClick={() => handleSelectSite(site)}
                className={`w-full text-left p-3 rounded-xl border transition-all ${
                  isSelected
                    ? 'bg-mars-950/60 border-mars-500/60 shadow-lg ring-1 ring-mars-500/40'
                    : 'bg-space-800/40 border-white/10 hover:bg-space-800/80 hover:border-white/20'
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm text-white">{site.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-white/70 font-mono">
                      {site.agency}
                    </span>
                  </div>
                  {getStatusBadge(site.status)}
                </div>

                <div className="text-xs text-white/60 mb-2 truncate">
                  {site.locationName}
                  {site.coordsApproximate && ' (approx.)'}
                </div>

                <div className="flex items-center justify-between text-[11px] text-white/40 font-mono">
                  <span>Landed: {site.landingDate}</span>
                  <span className="text-mars-400 font-sans font-medium">Fly to site →</span>
                </div>
              </button>
            );
          })
        ) : (
          filteredOrbiters.map((orb) => (
            <div
              key={orb.id}
              className="p-3 rounded-xl border border-white/10 bg-space-800/40 space-y-2"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-semibold text-sm text-white">{orb.name}</div>
                  <div className="text-[11px] text-white/50">{orb.country} ({orb.agency})</div>
                </div>
                {getStatusBadge(orb.status)}
              </div>

              <p className="text-xs text-white/70 leading-relaxed">
                {orb.keyFacts[0]}
              </p>

              <div className="flex items-center justify-between text-[11px] pt-1 border-t border-white/5 text-white/40 font-mono">
                <span>Arrival: {orb.orbitInsertionDate || 'N/A'}</span>
                <a
                  href={orb.officialUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-mars-400 hover:text-mars-300 font-sans"
                >
                  Official Page ↗
                </a>
              </div>
            </div>
          ))
        )}

        {((tab === 'surface' && filteredSites.length === 0) ||
          (tab === 'orbiters' && filteredOrbiters.length === 0)) && (
          <div className="py-8 text-center text-white/40 text-xs">
            No missions found matching filters.
          </div>
        )}
      </div>
    </motion.div>
  );
};
