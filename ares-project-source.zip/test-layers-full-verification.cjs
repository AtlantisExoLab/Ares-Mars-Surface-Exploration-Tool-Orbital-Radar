const { chromium } = require('playwright');
const path = require('path');

async function testFullLayers() {
  console.log('--- Starting Full Data Layers Verification ---');
  const browser = await chromium.launch({
    headless: true,
    executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-webgl', '--no-sandbox'],
  });

  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  const errors = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      console.log('CONSOLE ERROR:', msg.text());
      errors.push(msg.text());
    }
  });

  page.on('pageerror', (err) => {
    console.log('PAGE ERROR:', err.message);
    errors.push(err.message);
  });

  const tileResponses = [];
  page.on('response', (res) => {
    const url = res.url();
    if (url.includes('trek.nasa.gov/tiles/Mars/EQ')) {
      tileResponses.push({
        url,
        status: res.status(),
        contentType: res.headers()['content-type'],
      });
    }
  });

  await page.goto('http://127.0.0.1:4173/');
  const skip = await page.waitForSelector('button:has-text("Skip Intro")', { timeout: 8000 }).catch(() => null);
  if (skip) await skip.click();

  await page.waitForSelector('canvas', { timeout: 15000 });
  await page.waitForTimeout(2000);

  // 1. Open Data Layers Panel
  console.log('Step 1: Opening Data Layers Panel...');
  const layersBtn = await page.waitForSelector('button[aria-label="Data Layers"]', { timeout: 8000 });
  await layersBtn.click();
  await page.waitForTimeout(1000);

  // Verify panel title
  const panelTitle = await page.waitForSelector('text=Planetary Data Layers', { timeout: 5000 });
  console.log('Verified panel title visible:', !!panelTitle);

  // 2. Toggle MOLA Shaded Relief ON (1 click)
  console.log('Step 2: Toggling MOLA Shaded Relief ON...');
  const molaToggle = await page.waitForSelector('button:has-text("MOLA Shaded Relief")', { timeout: 5000 });
  await molaToggle.click();
  await page.waitForTimeout(2000);

  // Verify opacity slider for MOLA Shaded Relief appears
  const opacityText = await page.waitForSelector('text=Layer Opacity', { timeout: 5000 });
  console.log('Opacity slider appeared:', !!opacityText);

  // 3. Toggle MOLA Color DEM ON
  console.log('Step 3: Toggling MOLA Colourised Elevation (DEM) ON...');
  const demToggle = await page.waitForSelector('button:has-text("MOLA Colourised Elevation")', { timeout: 5000 });
  await demToggle.click();
  await page.waitForTimeout(2500);

  // Take screenshot with layers panel and active layers
  const screenshotPath1 = 'C:\\Users\\ASUS\\.gemini\\antigravity\\brain\\241b2067-f433-487e-8a7d-f9567a8dfe1a\\ares-data-layers-active.png';
  await page.screenshot({ path: screenshotPath1 });
  console.log('Captured screenshot with active layers and panel open:', screenshotPath1);

  // 4. Close the panel by clicking the Close button
  console.log('Step 4: Closing Data Layers Panel...');
  const closeBtn = await page.waitForSelector('button[aria-label="Close"]', { timeout: 5000 });
  await closeBtn.click();
  await page.waitForTimeout(1500);

  // Take screenshot of globe to verify layers remain rendered on Mars
  const screenshotPath2 = 'C:\\Users\\ASUS\\.gemini\\antigravity\\brain\\241b2067-f433-487e-8a7d-f9567a8dfe1a\\ares-globe-layers-rendered.png';
  await page.screenshot({ path: screenshotPath2 });
  console.log('Captured screenshot of globe with layers persistent:', screenshotPath2);

  console.log(`\n--- Verification Summary ---`);
  console.log(`Total NASA Trek tiles successfully loaded: ${tileResponses.length}`);
  const status200Count = tileResponses.filter((r) => r.status === 200).length;
  console.log(`Tiles with HTTP 200 OK: ${status200Count} / ${tileResponses.length}`);
  console.log(`Console/page errors: ${errors.length}`);

  if (tileResponses.length > 0 && status200Count === tileResponses.length && errors.length === 0) {
    console.log('✅ ALL DATA LAYER TESTS PASSED!');
  } else {
    console.error('❌ SOME ISSUES DETECTED');
  }

  await browser.close();
}

testFullLayers().catch(console.error);
