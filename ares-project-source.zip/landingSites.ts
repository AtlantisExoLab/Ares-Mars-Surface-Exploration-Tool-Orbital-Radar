/**
 * landingSites.ts
 * Type-safe interface to the verified Mars landing and impact sites database.
 */

import type { LandingSite } from '../types/MarsTypes';
import rawLandingSites from '../../public/data/landing-sites.json';

export const LANDING_SITES: LandingSite[] = rawLandingSites as LandingSite[];

export function getAllSites(): LandingSite[] {
  return LANDING_SITES;
}

export function getSiteById(id: string): LandingSite | undefined {
  return LANDING_SITES.find((s) => s.id === id);
}

export function getSitesByStatus(status: 'active' | 'ended' | 'lost'): LandingSite[] {
  return LANDING_SITES.filter((s) => s.status === status);
}

export function getSitesByAgency(agency: string): LandingSite[] {
  const norm = agency.toLowerCase();
  return LANDING_SITES.filter((s) => s.agency.toLowerCase().includes(norm));
}

export function getActiveSites(): LandingSite[] {
  return getSitesByStatus('active');
}
