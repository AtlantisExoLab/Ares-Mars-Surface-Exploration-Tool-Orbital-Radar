// Mars coordinate helper utilities
// Based on the Mars 2000 (IAU) reference ellipsoid

/** Mars 2000 semi-major axis radius in metres */
export const MARS_SEMI_MAJOR = 3_396_190; // metres
/** Mars 2000 semi-minor axis radius in metres */
export const MARS_SEMI_MINOR = 3_376_200; // metres

/**
 * Convert east-positive 0–360° longitude to Cesium's −180° to +180° range.
 */
export function marsLonToCesium(lon360: number): number {
  const normalised = ((lon360 % 360) + 360) % 360; // ensure 0–360
  return normalised > 180 ? normalised - 360 : normalised;
}

/**
 * Convert Cesium −180° to +180° longitude to 0–360° east-positive.
 */
export function cesiumLonToMars(lon180: number): number {
  return ((lon180 % 360) + 360) % 360;
}

/**
 * Format a lat/lon pair for human display.
 * @param lat  Planetocentric latitude in degrees (positive = north)
 * @param lon360  East-positive longitude, 0–360°
 * @returns e.g. "4.5°S, 137.4°E"
 */
export function formatMarsCoords(lat: number, lon360: number): string {
  const absLat = Math.abs(lat).toFixed(3);
  const latDir = lat >= 0 ? 'N' : 'S';

  // Normalise longitude to 0–360 then convert to 0–180 E/W notation
  const lon = ((lon360 % 360) + 360) % 360;
  let lonDisplay: string;
  if (lon <= 180) {
    lonDisplay = `${lon.toFixed(3)}°E`;
  } else {
    lonDisplay = `${(360 - lon).toFixed(3)}°W`;
  }

  return `${absLat}°${latDir}, ${lonDisplay}`;
}

/**
 * Format an elevation value for display.
 * Uses metres for values < 10 km, kilometres otherwise.
 * @param metres  Elevation in metres (can be negative for basins)
 */
export function formatElevation(metres: number): string {
  if (Math.abs(metres) < 10_000) {
    return `${metres.toFixed(0)} m`;
  }
  return `${(metres / 1000).toFixed(2)} km`;
}

/**
 * Format a camera altitude (height above reference ellipsoid) for display.
 * Always in kilometres.
 * @param metres  Altitude in metres
 */
export function formatAltitude(metres: number): string {
  const km = metres / 1000;
  if (km < 1) {
    return `${metres.toFixed(0)} m`;
  }
  if (km < 10) {
    return `${km.toFixed(2)} km`;
  }
  if (km < 1000) {
    return `${km.toFixed(1)} km`;
  }
  return `${(km / 1000).toFixed(3)} ×10³ km`;
}

/**
 * Compute the geodesic distance between two points on the Mars ellipsoid
 * using the Vincenty formula.
 *
 * @param lat1  Latitude of point A (degrees)
 * @param lon1  Longitude of point A (degrees, any range)
 * @param lat2  Latitude of point B (degrees)
 * @param lon2  Longitude of point B (degrees, any range)
 * @returns Distance in kilometres
 */
export function marsGeodesicDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
): number {
  const a = MARS_SEMI_MAJOR;
  const b = MARS_SEMI_MINOR;
  const f = (a - b) / a; // flattening

  const toRad = (d: number) => (d * Math.PI) / 180;

  const φ1 = toRad(lat1);
  const φ2 = toRad(lat2);
  const L = toRad(lon2 - lon1);

  const U1 = Math.atan((1 - f) * Math.tan(φ1));
  const U2 = Math.atan((1 - f) * Math.tan(φ2));
  const sinU1 = Math.sin(U1);
  const cosU1 = Math.cos(U1);
  const sinU2 = Math.sin(U2);
  const cosU2 = Math.cos(U2);

  let λ = L;
  let λPrev: number;
  let sinSigma: number;
  let cosSigma: number;
  let sigma: number;
  let sinAlpha: number;
  let cos2Alpha: number;
  let cos2SigmaM: number;
  let C: number;
  let iterLimit = 100;

  do {
    const sinλ = Math.sin(λ);
    const cosλ = Math.cos(λ);
    sinSigma = Math.sqrt(
      (cosU2 * sinλ) ** 2 + (cosU1 * sinU2 - sinU1 * cosU2 * cosλ) ** 2,
    );

    if (sinSigma === 0) return 0; // coincident points

    cosSigma = sinU1 * sinU2 + cosU1 * cosU2 * cosλ;
    sigma = Math.atan2(sinSigma, cosSigma);
    sinAlpha = (cosU1 * cosU2 * sinλ) / sinSigma;
    cos2Alpha = 1 - sinAlpha ** 2;
    cos2SigmaM = cos2Alpha !== 0 ? cosSigma - (2 * sinU1 * sinU2) / cos2Alpha : 0;
    C = (f / 16) * cos2Alpha * (4 + f * (4 - 3 * cos2Alpha));
    λPrev = λ;
    λ =
      L +
      (1 - C) *
        f *
        sinAlpha *
        (sigma + C * sinSigma * (cos2SigmaM + C * cosSigma * (-1 + 2 * cos2SigmaM ** 2)));
  } while (Math.abs(λ - λPrev) > 1e-12 && --iterLimit > 0);

  // If Vincenty fails to converge (nearly antipodal), fall back to haversine on sphere
  if (iterLimit === 0) {
    const R = (a + b) / 2;
    const dφ = toRad(lat2 - lat1);
    const dλ = toRad(lon2 - lon1);
    const ha =
      Math.sin(dφ / 2) ** 2 +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dλ / 2) ** 2;
    return (R * 2 * Math.asin(Math.sqrt(ha))) / 1000;
  }

  const u2 = (cos2Alpha * (a ** 2 - b ** 2)) / b ** 2;
  const A_coef =
    1 + (u2 / 16384) * (4096 + u2 * (-768 + u2 * (320 - 175 * u2)));
  const B_coef = (u2 / 1024) * (256 + u2 * (-128 + u2 * (74 - 47 * u2)));
  const deltaSigma =
    B_coef *
    sinSigma! *
    (cos2SigmaM! +
      (B_coef / 4) *
        (cosSigma! * (-1 + 2 * cos2SigmaM! ** 2) -
          (B_coef / 6) *
            cos2SigmaM! *
            (-3 + 4 * sinSigma! ** 2) *
            (-3 + 4 * cos2SigmaM! ** 2)));

  const s = b * A_coef * (sigma! - deltaSigma);
  return s / 1000; // kilometres
}

/**
 * Compute the initial bearing from point A to point B on Mars.
 * @returns Bearing in degrees, 0 = north, clockwise positive
 */
export function marsBearing(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const toDeg = (r: number) => (r * 180) / Math.PI;

  const φ1 = toRad(lat1);
  const φ2 = toRad(lat2);
  const Δλ = toRad(lon2 - lon1);

  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);

  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}
