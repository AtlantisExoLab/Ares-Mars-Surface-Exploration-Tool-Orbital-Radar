/**
 * BeforeAfterSlider.tsx
 * Draggable split-screen swipe comparison between original NASA imagery and AI-enhanced imagery.
 * Uses 1:1 coordinate-locked image layers to ensure zero displacement between the views.
 */

import React, { useState, useRef, useCallback, useEffect } from 'react';
import { motion } from 'framer-motion';

interface BeforeAfterSliderProps {
  originalDataUrl: string;
  enhancedDataUrl: string;
  tierLabel: string;
  onClose: () => void;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({
  originalDataUrl,
  enhancedDataUrl,
  tierLabel,
  onClose,
}) => {
  const [sliderPos, setSliderPos] = useState(50); // 0 to 100%
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMove = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const pct = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPos(pct);
  }, []);

  const onMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (isDragging) handleMove(e.clientX);
    },
    [isDragging, handleMove]
  );

  const onTouchMove = useCallback(
    (e: React.TouchEvent) => {
      if (isDragging && e.touches[0]) handleMove(e.touches[0].clientX);
    },
    [isDragging, handleMove]
  );

  useEffect(() => {
    const handleUp = () => setIsDragging(false);
    window.addEventListener('mouseup', handleUp);
    window.addEventListener('touchend', handleUp);
    return () => {
      window.removeEventListener('mouseup', handleUp);
      window.removeEventListener('touchend', handleUp);
    };
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      className="fixed inset-3 md:inset-8 lg:inset-12 z-50 rounded-2xl overflow-hidden shadow-2xl border border-white/20 bg-space-950/95 backdrop-blur-2xl flex flex-col pointer-events-auto select-none"
    >
      {/* Top Banner / Controls */}
      <div className="flex items-center justify-between px-6 py-3.5 bg-space-900/90 border-b border-white/10 z-20 flex-shrink-0">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
          <h2 className="text-white font-display font-semibold text-base md:text-lg tracking-wide">
            Before / After AI Imagery Enhancement
          </h2>
          <span className="text-xs px-2.5 py-0.5 rounded-full bg-white/10 text-white/70 border border-white/10">
            {tierLabel}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-medium text-white/80 hover:text-white bg-white/10 hover:bg-white/20 transition-colors"
          >
            Back to Original NASA Data
          </button>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 hover:bg-white/15 text-white/80 hover:text-white transition-colors"
            title="Close"
          >
            ✕
          </button>
        </div>
      </div>

      {/* Interactive Swipe Canvas Container */}
      <div
        ref={containerRef}
        onMouseDown={() => setIsDragging(true)}
        onMouseMove={onMouseMove}
        onTouchStart={() => setIsDragging(true)}
        onTouchMove={onTouchMove}
        className="relative flex-1 w-full h-full cursor-ew-resize select-none overflow-hidden bg-black"
      >
        {/* Right side: AI Enhanced */}
        <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
          <img
            src={enhancedDataUrl}
            alt="AI Enhanced Mars"
            className="w-full h-full object-contain pointer-events-none select-none"
          />
        </div>

        {/* Left side: Original NASA Data (clipped by sliderPos) */}
        <div
          className="absolute inset-0 flex items-center justify-center overflow-hidden z-10"
          style={{
            clipPath: `inset(0 ${100 - sliderPos}% 0 0)`,
          }}
        >
          <img
            src={originalDataUrl}
            alt="Original NASA Data"
            className="w-full h-full object-contain pointer-events-none select-none"
          />
        </div>

        {/* Labels Overlay */}
        <div className="absolute top-4 left-6 pointer-events-none z-20 px-3 py-1 rounded-lg bg-black/75 backdrop-blur-md text-xs font-mono tracking-wider text-white/90 border border-white/15 shadow-lg">
          ORIGINAL NASA DATA
        </div>
        <div className="absolute top-4 right-6 pointer-events-none z-20 px-3 py-1 rounded-lg bg-amber-950/80 backdrop-blur-md text-xs font-mono tracking-wider text-amber-300 border border-amber-600/40 shadow-lg">
          AI ENHANCED (4×)
        </div>

        {/* Draggable Divider Bar */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_12px_rgba(255,255,255,0.9)] z-30 pointer-events-none"
          style={{ left: `${sliderPos}%` }}
        >
          <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-9 h-9 rounded-full bg-white text-space-950 shadow-2xl flex items-center justify-center text-xs font-bold pointer-events-auto hover:scale-110 active:scale-95 transition-transform">
            ↔
          </div>
        </div>
      </div>

      {/* Bottom Mandatory Scientific Integrity Badge */}
      <div className="px-6 py-2.5 bg-space-950/95 border-t border-white/10 flex flex-wrap items-center justify-between text-xs text-white/60 flex-shrink-0">
        <div className="flex items-center gap-2 text-amber-300/90">
          <span>⚠️</span>
          <span>
            <strong>Scientific Integrity Notice:</strong> AI-enhanced for visualization only — not scientific data. All elevation, slopes, and EVA safety metrics strictly use unaltered NASA MOLA/CTX data.
          </span>
        </div>
        <div className="text-white/40">
          Drag slider to compare · Source: NASA Mars Trek / ASU / USGS
        </div>
      </div>
    </motion.div>
  );
};
