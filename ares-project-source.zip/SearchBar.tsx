/**
 * SearchBar.tsx
 * Top-left search bar with live autocomplete over IAU Gazetteer & missions,
 * category filters, and a "Surprise me" random fly-to action.
 */

import React, { useState, useEffect, useRef } from 'react';
import { AnimatePresence } from 'framer-motion';
import { useGlobeStore } from '../../store/globeStore';
import { searchFeatures, getRandomFeature, type SearchResultItem } from '../../data/gazeteerIndex';
import { flyTo } from '../../globe/CameraController';
import { SearchAutocomplete } from './SearchAutocomplete';

export const SearchBar: React.FC = () => {
  const viewer = useGlobeStore((s) => s.viewer);
  const setSelectedSite = useGlobeStore((s) => s.setSelectedSite);

  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResultItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);

  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      setIsOpen(false);
      return;
    }

    const timer = setTimeout(() => {
      const hits = searchFeatures(query, 8);
      setResults(hits);
      setIsOpen(hits.length > 0);
      setSelectedIndex(0);
    }, 120);

    return () => clearTimeout(timer);
  }, [query]);

  // Click outside listener
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (item: SearchResultItem) => {
    if (!viewer) return;

    // Appropriate altitude based on feature scale
    let altKm = 300;
    if (item.diameterKm && item.diameterKm > 1000) altKm = 2500;
    else if (item.diameterKm && item.diameterKm > 300) altKm = 1000;
    else if (item.category === 'Landing Site') altKm = 150;

    flyTo(viewer, item.lat, item.lon, altKm, 2.2);

    if (item.category === 'Landing Site') {
      const siteId = item.id.replace('site-', '');
      setSelectedSite(siteId);
    }

    setQuery(item.name);
    setIsOpen(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen || results.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % results.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + results.length) % results.length);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (results[selectedIndex]) {
        handleSelect(results[selectedIndex]);
      }
    } else if (e.key === 'Escape') {
      setIsOpen(false);
    }
  };

  const handleSurpriseMe = () => {
    if (!viewer) return;
    const randomFeat = getRandomFeature();
    setQuery(randomFeat.name);
    const altKm = randomFeat.diameterKm && randomFeat.diameterKm > 500 ? 1500 : 450;
    flyTo(viewer, randomFeat.lat, randomFeat.lon, altKm, 2.5);
  };

  return (
    <div ref={containerRef} className="relative w-64 sm:w-80 md:w-88 lg:w-96">
      <div className="relative flex items-center">
        {/* Search Input Field */}
        <div className="relative flex-1 flex items-center">
          <span className="absolute left-3.5 text-white/50 text-sm pointer-events-none select-none">
            🔍
          </span>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => {
              if (results.length > 0) setIsOpen(true);
            }}
            onKeyDown={handleKeyDown}
            placeholder="Search Mars (Olympus Mons, Jezero, Curiosity...)"
            className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-space-900/80 border border-white/15 text-white placeholder-white/40 text-sm focus:outline-none focus:border-mars-500/80 focus:ring-1 focus:ring-mars-500/50 backdrop-blur-xl shadow-lg transition-all"
          />
          {query && (
            <button
              onClick={() => {
                setQuery('');
                setResults([]);
                setIsOpen(false);
                inputRef.current?.focus();
              }}
              className="absolute right-3 text-white/40 hover:text-white/80 text-xs p-1"
            >
              ✕
            </button>
          )}
        </div>

        {/* Surprise Me Button */}
        <button
          onClick={handleSurpriseMe}
          title="Surprise me! (Fly to random landmark)"
          className="ml-2 px-3 py-2.5 rounded-xl bg-space-800/80 hover:bg-space-700/80 text-white/80 hover:text-white border border-white/10 backdrop-blur-xl shadow-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
        >
          <span>🎲</span>
          <span className="hidden sm:inline">Surprise</span>
        </button>
      </div>

      {/* Autocomplete Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <SearchAutocomplete
            results={results}
            selectedIndex={selectedIndex}
            onSelect={handleSelect}
          />
        )}
      </AnimatePresence>
    </div>
  );
};
