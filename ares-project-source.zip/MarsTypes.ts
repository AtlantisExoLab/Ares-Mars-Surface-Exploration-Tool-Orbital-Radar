/**
 * MarsTypes.ts
 * Core types for Mars geographic features, coordinates, and missions.
 */

export interface MarsCoordinates {
  lat: number;   // Planetocentric latitude, -90 to 90
  lon: number;   // Planetocentric East-positive longitude, 0 to 360
  elevation?: number; // Metres above Mars 2000 datum
}

export type MissionAgency = 'NASA' | 'USSR' | 'CNSA' | 'ESA' | 'ESA/UK' | 'ISRO' | 'JAXA' | 'UAESA';
export type MissionStatus = 'active' | 'ended' | 'lost';
export type MissionType =
  | 'Lander'
  | 'Rover'
  | 'Lander (crashed)'
  | 'Lander (failed)'
  | 'Rover+Helicopter'
  | 'Penetrator'
  | 'Orbiter';

export interface MissionImage {
  url: string;
  caption: string;
  credit: string;
}

export interface LandingSite {
  id: string;
  name: string;
  agency: string;
  country: string;
  agencyBadge: string;
  type: string;
  launchDate: string;
  landingDate: string;
  lat: number;
  lon: number;
  locationName: string;
  status: MissionStatus;
  coordsApproximate: boolean;
  objectives: string[];
  keyDiscoveries: string[];
  instruments: string[];
  images: MissionImage[];
  officialUrl: string;
  sourceNote: string;
}

export interface OrbiterMission {
  id: string;
  name: string;
  agency: string;
  country: string;
  agencyBadge: string;
  type: string;
  launchDate: string;
  orbitInsertionDate?: string;
  status: MissionStatus;
  objectives: string[];
  keyFacts: string[];
  instruments?: string[];
  officialUrl: string;
  imageUrl?: string;
  sourceNote: string;
}

export interface GazetteerFeature {
  id: string;
  name: string;
  type: 'Mons' | 'Crater' | 'Valles' | 'Planitia' | 'Planum' | 'Terra' | 'Chasma' | 'Vastitas' | 'Region' | 'Fossa' | 'Labyrinthus';
  lat: number;
  lon: number;
  description: string;
  diameterKm?: number;
}
