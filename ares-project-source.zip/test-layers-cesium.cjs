const { chromium } = require('playwright');
const path = require('path');

async function testLayers() {
  console.log('Testing Cesium Layer loading in browser...');
  const browser = await chromium.launch({
    headless: true,
    executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-webgl', '--no-sandbox'],
  });

  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  const errors = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      console.log('CONSOLE ERROR:', msg.text());
      errors.push(msg.text());
    }
  });

  page.on('pageerror', (err) => {
    console.log('PAGE ERROR:', err.message);
    errors.push(err.message);
  });

  await page.goto('http://127.0.0.1:4173/');
  const skip = await page.waitForSelector('button:has-text("Skip Intro")', { timeout: 8000 }).catch(() => null);
  if (skip) await skip.click();

  await page.waitForSelector('canvas', { timeout: 15000 });
  await page.waitForTimeout(2000);

  // Open Layers Panel
  console.log('Opening Layers Panel...');
  const layersBtn = await page.waitForSelector('button[aria-label="Data Layers"]', { timeout: 8000 });
  await layersBtn.click();
  await page.waitForTimeout(1000);

  // Check initial state of MOLA Shaded Relief switch
  const molaToggle = await page.waitForSelector('button:has-text("MOLA Shaded Relief")', { timeout: 5000 });
  console.log('Found MOLA Shaded Relief button');

  // Click once to toggle ON
  console.log('Clicking MOLA Shaded Relief to toggle ON...');
  await molaToggle.click();
  await page.waitForTimeout(1500);

  // Check if opacity slider appeared
  const opacityText = await page.$('text=Layer Opacity');
  console.log('Opacity slider appeared:', !!opacityText);

  // Click MOLA Color DEM
  console.log('Clicking MOLA Color DEM to toggle ON...');
  const demToggle = await page.waitForSelector('button:has-text("MOLA Colourised Elevation")', { timeout: 5000 });
  await demToggle.click();
  await page.waitForTimeout(1500);

  await browser.close();
  console.log('Done testing layers. Errors count:', errors.length);
}

testLayers().catch(console.error);
