import React from 'react';

type Variant = 'active' | 'ended' | 'lost' | 'nasa' | 'esa' | 'cnsa' | 'roscosmos' | 'isro';

interface Props {
  variant: Variant;
  children: React.ReactNode;
}

export const Badge: React.FC<Props> = ({ variant, children }) => (
  <span className={`badge badge-${variant}`}>{children}</span>
);

export default Badge;
