/**
 * RoverTraverseLayer.tsx
 *
 * Renders known rover traverse paths directly on the Cesium Mars globe.
 * Sources:
 * - Curiosity traverse: Gale Crater / Mount Sharp (from MSL mission data)
 * - Perseverance traverse: Jezero Crater / Ancient River Delta (from Mars 2020 mission data)
 *
 * Data referenced from:
 * - NASA JPL Mars Science Laboratory Route Map
 * - NASA Mars 2020 mission traverse data
 * - Curiosity route visualization: https://mars.nasa.gov/msl/mission/whereistheroversNow/
 */

import React, { useEffect, useRef, useState } from 'react';
import * as Cesium from 'cesium';
import { useGlobeStore } from '../store/globeStore';

interface RoverTraverseLayerProps {
  viewer: Cesium.Viewer;
}

interface TraverseWaypoint {
  lon: number;
  lat: number;
  sol: number;
  label?: string;
}

// Key waypoints from Curiosity's traverse across Gale Crater and Mount Sharp
// Coordinates from published NASA/JPL traverse maps and mission data
const CURIOSITY_TRAVERSE: TraverseWaypoint[] = [
  { lon: 137.4416, lat: -4.5895, sol: 0, label: 'Bradbury Landing' },
  { lon: 137.4486, lat: -4.5889, sol: 29, label: 'Glenelg Intrigue' },
  { lon: 137.4432, lat: -4.5870, sol: 56, label: 'John Klein Drill' },
  { lon: 137.4370, lat: -4.5891, sol: 100, label: 'Kimberley Formation' },
  { lon: 137.4160, lat: -4.6103, sol: 200, label: 'Pahrump Hills' },
  { lon: 137.4102, lat: -4.6210, sol: 400, label: 'Marias Pass' },
  { lon: 137.3993, lat: -4.6358, sol: 600, label: 'Murray Buttes' },
  { lon: 137.3814, lat: -4.6515, sol: 900, label: 'Vera Rubin Ridge' },
  { lon: 137.3637, lat: -4.6672, sol: 1200, label: 'Glen Torridon Clay' },
  { lon: 137.3492, lat: -4.6881, sol: 1500, label: 'Rafael Navarro Mtn' },
  { lon: 137.3331, lat: -4.7074, sol: 1800, label: 'Gediz Vallis Ridge' },
  { lon: 137.3193, lat: -4.7256, sol: 2000, label: 'Marker Band Valley' },
  { lon: 137.3025, lat: -4.7418, sol: 2200, label: 'Amapari Region' },
  { lon: 137.2922, lat: -4.7563, sol: 2400, label: 'Texoli Butte' },
  { lon: 137.2814, lat: -4.7682, sol: 2500, label: 'Sulfate-bearing Terrain' },
];

// Key waypoints from Perseverance's traverse in Jezero Crater
// Source: NASA JPL Mars 2020 mission traverse data
const PERSEVERANCE_TRAVERSE: TraverseWaypoint[] = [
  { lon: 77.4509, lat: 18.4447, sol: 0, label: 'Octavia E. Butler Landing' },
  { lon: 77.4518, lat: 18.4458, sol: 13, label: 'Ingenuity Airfield' },
  { lon: 77.4538, lat: 18.4499, sol: 60, label: 'Séítah Region' },
  { lon: 77.4591, lat: 18.4546, sol: 100, label: 'South Séítah Ridgeline' },
  { lon: 77.4647, lat: 18.4601, sol: 180, label: 'Fan Front Transition' },
  { lon: 77.4712, lat: 18.4682, sol: 240, label: 'Delta Scarp' },
  { lon: 77.4780, lat: 18.4756, sol: 340, label: 'Three Forks Depot' },
  { lon: 77.4851, lat: 18.4823, sol: 400, label: 'Rocky Top Ridge' },
  { lon: 77.4913, lat: 18.4894, sol: 480, label: 'Yori Pass' },
  { lon: 77.4967, lat: 18.4951, sol: 540, label: 'Billingshurst Mound' },
  { lon: 77.5021, lat: 18.4998, sol: 600, label: 'Fall River Hills' },
  { lon: 77.5078, lat: 18.5045, sol: 680, label: 'Bright Angel Area' },
  { lon: 77.5126, lat: 18.5091, sol: 740, label: 'Neretva Vallis' },
  { lon: 77.5169, lat: 18.5138, sol: 800, label: 'Cape Farewell' },
  { lon: 77.5208, lat: 18.5178, sol: 850, label: 'Margin Unit Target' },
];

export const RoverTraverseLayer: React.FC<RoverTraverseLayerProps> = ({ viewer }) => {
  const entitiesRef = useRef<Cesium.Entity[]>([]);
  const [showCuriosity, setShowCuriosity] = useState(false);
  const [showPerseverance, setShowPerseverance] = useState(false);

  const addTraverseEntities = (
    traverse: TraverseWaypoint[],
    color: Cesium.Color,
    roverName: string
  ) => {
    if (!viewer?.entities || viewer.isDestroyed()) return;

    // Build coordinate array for polyline
    const positions: Cesium.Cartesian3[] = traverse.map((wp) =>
      Cesium.Cartesian3.fromDegrees(wp.lon, wp.lat, 0)
    );

    // Main traverse polyline
    const line = viewer.entities.add({
      polyline: {
        positions,
        width: 2.5,
        material: new Cesium.PolylineGlowMaterialProperty({
          glowPower: 0.2,
          color: color,
        }),
        clampToGround: true,
      },
    });
    entitiesRef.current.push(line);

    // Start/end markers and key waypoints
    traverse.forEach((wp, i) => {
      const isStart = i === 0;
      const isEnd = i === traverse.length - 1;
      const isKeyPoint = wp.label && (isStart || isEnd || i % 3 === 0);

      if (isKeyPoint) {
        const pt = viewer.entities.add({
          position: Cesium.Cartesian3.fromDegrees(wp.lon, wp.lat, 100),
          point: {
            pixelSize: isStart || isEnd ? 10 : 5,
            color: isStart ? Cesium.Color.LIMEGREEN : isEnd ? Cesium.Color.YELLOW : color,
            outlineColor: Cesium.Color.BLACK,
            outlineWidth: 1,
            heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
            disableDepthTestDistance: Number.POSITIVE_INFINITY,
          },
          label: {
            text: `Sol ${wp.sol}: ${wp.label}`,
            font: '10px monospace',
            fillColor: Cesium.Color.WHITE,
            outlineColor: Cesium.Color.BLACK,
            outlineWidth: 2,
            style: Cesium.LabelStyle.FILL_AND_OUTLINE,
            pixelOffset: new Cesium.Cartesian2(0, -18),
            show: isStart || isEnd,
            scale: 0.85,
            disableDepthTestDistance: Number.POSITIVE_INFINITY,
          },
          description: `<b>${roverName}</b><br>Sol: ${wp.sol}<br>Location: ${wp.label || 'Traverse point'}<br>Lat: ${wp.lat.toFixed(4)}°, Lon: ${wp.lon.toFixed(4)}°`,
        });
        entitiesRef.current.push(pt);
      }
    });

    viewer.scene.requestRender();
  };

  const removeAllEntities = () => {
    if (!viewer?.entities || viewer.isDestroyed()) return;
    entitiesRef.current.forEach((e) => {
      try { viewer.entities.remove(e); } catch {}
    });
    entitiesRef.current = [];
    viewer.scene.requestRender();
  };

  useEffect(() => {
    removeAllEntities();
    if (showCuriosity) {
      addTraverseEntities(CURIOSITY_TRAVERSE, Cesium.Color.fromCssColorString('#f97316'), 'Curiosity');
    }
    if (showPerseverance) {
      addTraverseEntities(PERSEVERANCE_TRAVERSE, Cesium.Color.fromCssColorString('#38bdf8'), 'Perseverance');
    }
    return removeAllEntities;
  }, [showCuriosity, showPerseverance, viewer]);

  return (
    <div className="fixed bottom-16 right-4 md:right-16 z-20 pointer-events-auto">
      <div className="bg-[#0a0d14]/90 border border-slate-700/60 rounded-xl p-3 shadow-xl backdrop-blur-sm space-y-2">
        <div className="text-[10px] font-mono text-white/40 uppercase tracking-widest px-1 flex items-center gap-1.5">
          <span>🤖</span> Rover Traverses
        </div>
        <button
          onClick={() => {
            if (!showPerseverance && viewer) {
              viewer.camera.flyTo({
                destination: Cesium.Cartesian3.fromDegrees(77.47, 18.47, 60000),
                duration: 2.5,
              });
            }
            setShowPerseverance((v) => !v);
          }}
          className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
            showPerseverance
              ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
              : 'bg-white/5 text-white/60 border border-white/10 hover:bg-white/10'
          }`}
        >
          <div className={`w-2 h-2 rounded-full ${showPerseverance ? 'bg-sky-400' : 'bg-white/20'}`} />
          Perseverance (Jezero)
        </button>
        <button
          onClick={() => {
            if (!showCuriosity && viewer) {
              viewer.camera.flyTo({
                destination: Cesium.Cartesian3.fromDegrees(137.39, -4.65, 60000),
                duration: 2.5,
              });
            }
            setShowCuriosity((v) => !v);
          }}
          className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
            showCuriosity
              ? 'bg-orange-500/20 text-orange-300 border border-orange-500/40'
              : 'bg-white/5 text-white/60 border border-white/10 hover:bg-white/10'
          }`}
        >
          <div className={`w-2 h-2 rounded-full ${showCuriosity ? 'bg-orange-400' : 'bg-white/20'}`} />
          Curiosity (Gale Crater)
        </button>
        <div className="text-[9px] text-white/20 px-1 leading-tight">
          Source: NASA JPL Mission Data
        </div>
      </div>
    </div>
  );
};
