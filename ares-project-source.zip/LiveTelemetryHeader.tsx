/**
 * LiveTelemetryHeader.tsx
 *
 * Real-time Martian planetary telemetry bar inspired by Orbital Radar (orbitalradar.com/mars):
 *  - Live NASA Mars Sol Date (MSD) & Coordinated Mars Time (MTC)
 *  - Solar Longitude (Ls) and current Martian astronomical season
 *  - Local Mean Solar Time (LMST) and active mission Sol for Perseverance and Curiosity
 *  - Direct toggle for 3D orbital trajectories
 *  - Fluid layout preventing collision with SearchBar on any laptop or desktop screen
 */

import React, { useState, useEffect } from 'react';
import {
  getMarsSolDate,
  getSolarLongitude,
  getMarsSeason,
  getLMST,
  formatMarsTime,
  getMissionSol,
  PERSEVERANCE_LANDING_MSD,
  CURIOSITY_LANDING_MSD,
  JEZERO_LON_E,
  GALE_LON_E,
} from '../../data/marsTime';
import { useGlobeStore } from '../../store/globeStore';

export const LiveTelemetryHeader: React.FC = () => {
  const showOrbits = useGlobeStore((s) => s.showOrbits);
  const toggleOrbits = useGlobeStore((s) => s.toggleOrbits);
  const setActivePanel = useGlobeStore((s) => s.setActivePanel);
  const activePanel = useGlobeStore((s) => s.activePanel);

  const [now, setNow] = useState(new Date());

  // Real-time ticking clock
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const msd = getMarsSolDate(now);
  const ls = getSolarLongitude(now);
  const season = getMarsSeason(ls);

  // Perseverance / Jezero
  const percySol = getMissionSol(PERSEVERANCE_LANDING_MSD, msd);
  const percyTime = formatMarsTime(getLMST(JEZERO_LON_E, now));

  // Curiosity / Gale
  const curioSol = getMissionSol(CURIOSITY_LANDING_MSD, msd);
  const curioTime = formatMarsTime(getLMST(GALE_LON_E, now));

  return (
    <header className="hidden md:flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-space-950/85 border border-white/15 backdrop-blur-xl shadow-2xl text-[11px] font-mono select-none flex-shrink-0">
      {/* Live Radar Status Pill */}
      <div className="flex items-center gap-2 pr-2 border-r border-white/10">
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_#34d399]" />
        <span className="text-emerald-400 font-semibold tracking-wider text-[10px] uppercase">
          Orbital Radar
        </span>
      </div>

      {/* Mars Sol Date & Season */}
      <div className="flex items-center gap-1.5">
        <span className="text-white/40">MSD:</span>
        <span className="text-white/95 font-medium">{msd.toFixed(1)}</span>
        <span className="text-white/20">|</span>
        <span className="text-white/40">L<sub>s</sub>:</span>
        <span className="text-amber-400/90 font-medium">{ls}°</span>
        <span className="text-white/40 text-[10px] hidden 2xl:inline">({season.split(' / ')[0]})</span>
      </div>

      <span className="text-white/20 hidden lg:inline">|</span>

      {/* Perseverance (Jezero) Live Telemetry */}
      <div className="hidden lg:flex items-center gap-1.5">
        <span className="text-mars-400 font-semibold">Percy:</span>
        <span className="text-white/90">Sol {percySol}</span>
        <span className="text-emerald-400/90">{percyTime}</span>
      </div>

      <span className="text-white/20 hidden xl:inline">|</span>

      {/* Curiosity (Gale) Live Telemetry */}
      <div className="hidden xl:flex items-center gap-1.5">
        <span className="text-mars-400 font-semibold">Curio:</span>
        <span className="text-white/90">Sol {curioSol}</span>
        <span className="text-emerald-400/90">{curioTime}</span>
      </div>

      {/* Quick 3D Orbits & Radar Panel Toggle Buttons */}
      <div className="flex items-center gap-1.5 pl-2 border-l border-white/10">
        <button
          onClick={toggleOrbits}
          className={`px-2 py-0.5 rounded-full text-[10px] font-medium transition-all ${
            showOrbits
              ? 'bg-sky-500/20 text-sky-300 border border-sky-400/30'
              : 'bg-white/5 text-white/50 border border-white/10 hover:text-white'
          }`}
          title="Toggle 3D orbital trajectories for orbiters and moons"
        >
          🛰️ Orbits {showOrbits ? 'ON' : 'OFF'}
        </button>

        <button
          onClick={() => setActivePanel(activePanel === 'radar' ? null : 'radar')}
          className={`px-2 py-0.5 rounded-full text-[10px] font-medium transition-all ${
            activePanel === 'radar'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
              : 'bg-white/5 text-white/70 border border-white/10 hover:bg-white/15'
          }`}
          title="Open complete Orbital Radar spacecraft and moon directory"
        >
          Track ↗
        </button>
      </div>
    </header>
  );
};
