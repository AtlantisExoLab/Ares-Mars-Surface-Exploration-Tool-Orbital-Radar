/**
 * NavigationRail.tsx
 * Alias export for LeftRail component.
 */

export { LeftRail as NavigationRail } from './LeftRail';
export { LeftRail } from './LeftRail';
