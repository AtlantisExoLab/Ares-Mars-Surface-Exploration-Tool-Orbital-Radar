/**
 * LiveRoverImageryPanel.tsx
 *
 * Dedicated in-app Mars Rover Imagery Explorer.
 * Connects directly to the live NASA Image & Video Library API to stream authentic
 * surface photographs and hardware portraits of all rovers sent to Mars:
 *
 * Features:
 * 1. "Surface Scenery": Raw terrain, rock, and panoramic photos taken BY the rovers
 * 2. "The Rovers (Hardware)": Authentic photos and selfies OF the rovers sent to Mars
 *    (Perseverance, Curiosity, Opportunity, Spirit, Sojourner, Zhurong, Prop-M)
 * 3. In-app zoomable inspector modal (NO external redirects)
 * 4. 1-click direct in-app downloads of full-resolution NASA files
 * 5. Fly to Rover landing site on the 3D Mars globe
 */

import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import * as Cesium from 'cesium';
import { useGlobeStore } from '../../store/globeStore';

interface NASAItem {
  id: string;
  nasaId: string;
  title: string;
  description: string;
  date: string;
  rover: string;
  camera: string;
  thumbUrl: string;
  mediumUrl: string;
  largeUrl: string;
  origUrl: string;
  specs?: {
    mass: string;
    power: string;
    landed: string;
    location: string;
    status: string;
    distance?: string;
  };
}

interface RoverOption {
  id: string;
  name: string;
  status: 'active' | 'ended';
  locationName: string;
  lat: number;
  lon: number;
  surfaceQuery: string;
  roverSelfieQuery: string;
  icon: string;
  cameras: string[];
}

const ROVERS: RoverOption[] = [
  {
    id: 'perseverance',
    name: 'Perseverance (Mars 2020)',
    status: 'active',
    locationName: 'Jezero Crater',
    lat: 18.4447,
    lon: 77.4509,
    surfaceQuery: 'perseverance rover jezero mars surface sol',
    roverSelfieQuery: 'perseverance rover selfie OR portrait',
    icon: '🚜',
    cameras: ['All Cameras', 'Mastcam-Z', 'Navcam', 'Hazcam', 'SuperCam', 'WATSON'],
  },
  {
    id: 'curiosity',
    name: 'Curiosity (MSL)',
    status: 'active',
    locationName: 'Gale Crater / Mt Sharp',
    lat: -4.5895,
    lon: 137.4416,
    surfaceQuery: 'curiosity rover gale crater mars surface',
    roverSelfieQuery: 'curiosity rover selfie OR portrait',
    icon: '🤖',
    cameras: ['All Cameras', 'Mastcam', 'Navcam', 'Hazcam', 'MAHLI', 'ChemCam'],
  },
  {
    id: 'opportunity',
    name: 'Opportunity (MER-B)',
    status: 'ended',
    locationName: 'Meridiani Planum',
    lat: -1.9462,
    lon: 354.4734,
    surfaceQuery: 'opportunity rover meridiani mars surface panorama',
    roverSelfieQuery: 'opportunity rover self portrait OR deck OR solar',
    icon: '⚡',
    cameras: ['All Cameras', 'Pancam', 'Navcam', 'Hazcam', 'Microscopic Imager'],
  },
  {
    id: 'spirit',
    name: 'Spirit (MER-A)',
    status: 'ended',
    locationName: 'Gusev Crater',
    lat: -14.5684,
    lon: 175.4726,
    surfaceQuery: 'spirit rover gusev crater columbia hills mars',
    roverSelfieQuery: 'spirit rover self portrait OR deck',
    icon: '🌟',
    cameras: ['All Cameras', 'Pancam', 'Navcam', 'Hazcam'],
  },
  {
    id: 'sojourner',
    name: 'Sojourner (Pathfinder)',
    status: 'ended',
    locationName: 'Ares Vallis',
    lat: 19.13,
    lon: 326.78,
    surfaceQuery: 'pathfinder sojourner mars surface rocks',
    roverSelfieQuery: 'sojourner rover pathfinder',
    icon: '🚀',
    cameras: ['All Cameras', 'IMP Camera', 'APXS Sensor'],
  },
  {
    id: 'insight',
    name: 'InSight Lander',
    status: 'ended',
    locationName: 'Elysium Planitia',
    lat: 4.5024,
    lon: 135.6234,
    surfaceQuery: 'insight lander elysium mars surface seismometer',
    roverSelfieQuery: 'insight lander mars selfie',
    icon: '📡',
    cameras: ['All Cameras', 'IDC Camera', 'ICC Camera'],
  },
];

// Curated high-fidelity hardware portraits of the rovers sent to Mars
const CURATED_ROVER_SHOWCASE: NASAItem[] = [
  {
    id: 'PIA24542',
    nasaId: 'PIA24542',
    title: "Perseverance's Historic Selfie with Ingenuity Helicopter",
    description: "NASA's Mars 2020 Perseverance rover took this portrait with the Ingenuity Mars Helicopter on April 6, 2021 (the 46th Martian day, or sol, of the mission). The selfie was compiled from 62 individual images taken by the WATSON camera on the rover's robotic arm.",
    date: '2021-04-06',
    rover: 'Perseverance (Mars 2020)',
    camera: 'WATSON (Robotic Arm)',
    thumbUrl: 'https://images-assets.nasa.gov/image/PIA24542/PIA24542~thumb.jpg',
    mediumUrl: 'https://images-assets.nasa.gov/image/PIA24542/PIA24542~medium.jpg',
    largeUrl: 'https://images-assets.nasa.gov/image/PIA24542/PIA24542~large.jpg',
    origUrl: 'https://images-assets.nasa.gov/image/PIA24542/PIA24542~orig.jpg',
    specs: {
      mass: '1,025 kg (2,260 lb)',
      power: 'MMRTG Nuclear (110W)',
      landed: 'Feb 18, 2021',
      location: 'Jezero Crater (18.44°N, 77.45°E)',
      status: 'Active · Traversed >28 km',
    },
  },
  {
    id: 'PIA19808',
    nasaId: 'PIA19808',
    title: 'Curiosity Rover Low-Angle Selfie at "Buckskin" Drill Site',
    description: "NASA's Curiosity Mars rover took this low-angle self-portrait at the 'Buckskin' drill site on lower Mount Sharp. The mosaic combines dozens of exposures taken by the Mars Hand Lens Imager (MAHLI) at the end of the rover's robotic arm.",
    date: '2015-08-05',
    rover: 'Curiosity (MSL)',
    camera: 'MAHLI Hand Lens',
    thumbUrl: 'https://images-assets.nasa.gov/image/PIA19808/PIA19808~thumb.jpg',
    mediumUrl: 'https://images-assets.nasa.gov/image/PIA19808/PIA19808~medium.jpg',
    largeUrl: 'https://images-assets.nasa.gov/image/PIA19808/PIA19808~large.jpg',
    origUrl: 'https://images-assets.nasa.gov/image/PIA19808/PIA19808~orig.jpg',
    specs: {
      mass: '899 kg (1,982 lb)',
      power: 'MMRTG Nuclear (125W)',
      landed: 'Aug 6, 2012',
      location: 'Gale Crater (4.59°S, 137.44°E)',
      status: 'Active · Traversed >32 km',
    },
  },
  {
    id: 'PIA23240',
    nasaId: 'PIA23240',
    title: 'Curiosity Rover at "Aberlady" and "Kilmarie" Clay Unit',
    description: "Curiosity Mars rover captured this selfie after drilling two holes into clay-bearing bedrock at the 'Aberlady' and 'Kilmarie' targets on the lower slopes of Mount Sharp (Aeolis Mons).",
    date: '2019-05-12',
    rover: 'Curiosity (MSL)',
    camera: 'MAHLI Hand Lens',
    thumbUrl: 'https://images-assets.nasa.gov/image/PIA23240/PIA23240~thumb.jpg',
    mediumUrl: 'https://images-assets.nasa.gov/image/PIA23240/PIA23240~medium.jpg',
    largeUrl: 'https://images-assets.nasa.gov/image/PIA23240/PIA23240~large.jpg',
    origUrl: 'https://images-assets.nasa.gov/image/PIA23240/PIA23240~orig.jpg',
    specs: {
      mass: '899 kg',
      power: 'MMRTG Nuclear',
      landed: 'Aug 6, 2012',
      location: 'Gale Crater (Mt Sharp)',
      status: 'Active · Operating Sol 4000+',
    },
  },
  {
    id: 'PIA05541',
    nasaId: 'PIA05541',
    title: 'Opportunity Rover Self-Portrait on the Red Plains of Meridiani',
    description: "Self-portrait of NASA's Mars Exploration Rover Opportunity on the surface of Mars. The mosaic shows the solar array panels, panoramic camera mast, and equipment deck stretching across the bright hematite-rich plains of Meridiani Planum.",
    date: '2004-03-24',
    rover: 'Opportunity (MER-B)',
    camera: 'Panoramic Camera (Pancam)',
    thumbUrl: 'https://images-assets.nasa.gov/image/PIA05541/PIA05541~thumb.jpg',
    mediumUrl: 'https://images-assets.nasa.gov/image/PIA05541/PIA05541~medium.jpg',
    largeUrl: 'https://images-assets.nasa.gov/image/PIA05541/PIA05541~large.jpg',
    origUrl: 'https://images-assets.nasa.gov/image/PIA05541/PIA05541~orig.jpg',
    specs: {
      mass: '185 kg (408 lb)',
      power: 'Solar Array (140W)',
      landed: 'Jan 25, 2004',
      location: 'Meridiani Planum (1.95°S, 354.47°E)',
      status: 'Mission Complete · 15 Years (45.16 km)',
    },
  },
  {
    id: 'PIA07463',
    nasaId: 'PIA07463',
    title: 'Spirit Rover on the Summit of Husband Hill',
    description: "NASA's Mars Exploration Rover Spirit looks back across its tracks and deck after climbing to the summit of 'Husband Hill' inside Gusev Crater, Mars. Spirit traversed over 7.7 kilometers before its mission concluded in 2010.",
    date: '2005-09-08',
    rover: 'Spirit (MER-A)',
    camera: 'Pancam Mosaic',
    thumbUrl: 'https://images-assets.nasa.gov/image/PIA07463/PIA07463~thumb.jpg',
    mediumUrl: 'https://images-assets.nasa.gov/image/PIA07463/PIA07463~medium.jpg',
    largeUrl: 'https://images-assets.nasa.gov/image/PIA07463/PIA07463~large.jpg',
    origUrl: 'https://images-assets.nasa.gov/image/PIA07463/PIA07463~orig.jpg',
    specs: {
      mass: '185 kg (408 lb)',
      power: 'Solar Array (140W)',
      landed: 'Jan 4, 2004',
      location: 'Gusev Crater (14.57°S, 175.47°E)',
      status: 'Mission Complete · 6 Years (7.7 km)',
    },
  },
  {
    id: 'PIA00621',
    nasaId: 'PIA00621',
    title: 'Sojourner Microrover at "Yogi" Rock — First Mars Rover in History',
    description: "The first wheeled vehicle to explore another world: NASA's Sojourner microrover (Mars Pathfinder) conducting Alpha Proton X-ray Spectrometer measurements on the famous rock nicknamed 'Yogi' in Ares Vallis, Mars, July 1997.",
    date: '1997-07-06',
    rover: 'Sojourner (Pathfinder)',
    camera: 'IMP (Pathfinder Lander Camera)',
    thumbUrl: 'https://images-assets.nasa.gov/image/PIA00621/PIA00621~thumb.jpg',
    mediumUrl: 'https://images-assets.nasa.gov/image/PIA00621/PIA00621~medium.jpg',
    largeUrl: 'https://images-assets.nasa.gov/image/PIA00621/PIA00621~large.jpg',
    origUrl: 'https://images-assets.nasa.gov/image/PIA00621/PIA00621~orig.jpg',
    specs: {
      mass: '11.5 kg (25 lb)',
      power: 'Solar + Primary Battery (16W)',
      landed: 'Jul 4, 1997',
      location: 'Ares Vallis (19.13°N, 326.78°E)',
      status: 'Historic · 1st Wheeled Rover on Mars',
    },
  },
  {
    id: 'PIA11431',
    nasaId: 'PIA11431',
    title: 'Three Generations of NASA Mars Rovers (Size Comparison)',
    description: "Flight spares and engineering models showing three generations of NASA Mars rovers: Sojourner (1997, foreground), Spirit/Opportunity (2004, left), and Curiosity (2012, right), demonstrating 15 years of planetary robotics evolution.",
    date: '2008-11-20',
    rover: 'Three Generations Comparison',
    camera: 'NASA JPL Cleanroom Engineering',
    thumbUrl: 'https://images-assets.nasa.gov/image/PIA11431/PIA11431~thumb.jpg',
    mediumUrl: 'https://images-assets.nasa.gov/image/PIA11431/PIA11431~medium.jpg',
    largeUrl: 'https://images-assets.nasa.gov/image/PIA11431/PIA11431~large.jpg',
    origUrl: 'https://images-assets.nasa.gov/image/PIA11431/PIA11431~orig.jpg',
    specs: {
      mass: '11.5 kg → 185 kg → 899 kg',
      power: 'Solar to Nuclear (MMRTG)',
      landed: '1997 – 2012 – 2021',
      location: 'Planetary Engineering Comparison',
      status: 'Official NASA Robotics Evolution',
    },
  },
  {
    id: 'PIA04318',
    nasaId: 'PIA04318',
    title: 'Sojourner Rover Explores the "Rock Garden" on Martian Soil',
    description: "High-resolution color view from the Mars Pathfinder Imager showing the Sojourner rover parked near the 'Rock Garden' in Ares Vallis, testing soil mechanics and basaltic elemental composition.",
    date: '1997-07-22',
    rover: 'Sojourner (Pathfinder)',
    camera: 'IMP (Imager for Mars Pathfinder)',
    thumbUrl: 'https://images-assets.nasa.gov/image/PIA04318/PIA04318~thumb.jpg',
    mediumUrl: 'https://images-assets.nasa.gov/image/PIA04318/PIA04318~medium.jpg',
    largeUrl: 'https://images-assets.nasa.gov/image/PIA04318/PIA04318~large.jpg',
    origUrl: 'https://images-assets.nasa.gov/image/PIA04318/PIA04318~orig.jpg',
    specs: {
      mass: '11.5 kg',
      power: 'GaAs Solar Cell Array',
      landed: 'Jul 4, 1997',
      location: 'Ares Vallis (Chryse Planitia)',
      status: 'Mission Complete · 83 Sols',
    },
  },
];

export const LiveRoverImageryPanel: React.FC = () => {
  const viewer = useGlobeStore((s) => s.viewer);
  const setActivePanel = useGlobeStore((s) => s.setActivePanel);

  // Top Section Switcher: 'surface' (POV scenery) vs 'rovers' (photos OF the rovers)
  const [activeSection, setActiveSection] = useState<'surface' | 'rovers'>('surface');

  // Surface view state
  const [selectedRoverId, setSelectedRoverId] = useState<string>('perseverance');
  const [selectedCamera, setSelectedCamera] = useState<string>('All Cameras');
  const [searchFilter, setSearchFilter] = useState<string>('');
  const [images, setImages] = useState<NASAItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Rovers hardware view state
  const [roverFilter, setRoverFilter] = useState<string>('All Rovers');
  const [roverHardwareImages, setRoverHardwareImages] = useState<NASAItem[]>(CURATED_ROVER_SHOWCASE);
  const [roverLoading, setRoverLoading] = useState(false);

  // In-app inspector state
  const [inspectImage, setInspectImage] = useState<NASAItem | null>(null);
  const [modalImgSrc, setModalImgSrc] = useState<string>('');
  const [modalOrigUrl, setModalOrigUrl] = useState<string>('');
  const [modalImgLoading, setModalImgLoading] = useState<boolean>(false);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const currentRover = useMemo(
    () => ROVERS.find((r) => r.id === selectedRoverId) || ROVERS[0],
    [selectedRoverId]
  );

  // Asset manifest resolver: guarantees valid image resolution and prevents broken 403/404s
  useEffect(() => {
    if (!inspectImage) {
      setModalImgSrc('');
      setModalOrigUrl('');
      setModalImgLoading(false);
      return;
    }

    // Step A: Immediately show verified thumbnail (instant 0ms render, guaranteed 200 OK)
    const cleanThumb = (inspectImage.thumbUrl || '').replace(/^http:\/\//i, 'https://');
    setModalImgSrc(cleanThumb);
    setModalOrigUrl(inspectImage.origUrl || cleanThumb);
    setModalImgLoading(true);

    // Step B: Query NASA asset manifest to get verified real files for this photo
    const manifestUrl = `https://images-api.nasa.gov/asset/${encodeURIComponent(inspectImage.nasaId)}`;
    fetch(manifestUrl, { headers: { Accept: 'application/json' } })
      .then((r) => r.json())
      .then((data) => {
        const items = data.collection?.items || [];
        const validUrls: string[] = items
          .map((i: any) => (i.href || '').replace(/^http:\/\//i, 'https://'))
          .filter((u: string) => /\.(jpg|jpeg|png)$/i.test(u));

        // Prioritize highest available valid resolution: large -> medium -> orig -> small -> thumb
        const large = validUrls.find((u) => u.includes('~large.jpg'));
        const medium = validUrls.find((u) => u.includes('~medium.jpg'));
        const orig = validUrls.find((u) => u.includes('~orig.jpg'));
        const small = validUrls.find((u) => u.includes('~small.jpg'));
        const thumb = validUrls.find((u) => u.includes('~thumb.jpg'));

        const bestDisplay = large || medium || orig || small || thumb || cleanThumb;
        setModalImgSrc(bestDisplay);

        if (orig) {
          setModalOrigUrl(orig);
        } else if (bestDisplay) {
          setModalOrigUrl(bestDisplay);
        }
      })
      .catch((err) => {
        console.warn('[LiveRoverImageryPanel] Asset manifest lookup fallback:', err);
      });
  }, [inspectImage]);

  // Fetch surface images for selected rover
  const fetchRoverImages = (rover: RoverOption) => {
    setLoading(true);
    setError(null);
    setImages([]);

    const query = encodeURIComponent(rover.surfaceQuery);
    const url = `https://images-api.nasa.gov/search?q=${query}&media_type=image&page_size=36`;

    fetch(url, { headers: { Accept: 'application/json' } })
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.json();
      })
      .then((data) => {
        const rawItems = data.collection?.items || [];
        const parsed: NASAItem[] = rawItems.map((item: any) => {
          const d = item.data?.[0] || {};
          const links = item.links || [];
          const rawThumb = links.find((l: any) => l.rel === 'preview')?.href || links[0]?.href || '';
          const thumb = rawThumb.replace(/^http:\/\//i, 'https://');
          const nasaId = d.nasa_id || 'mars_img';

          const medium = thumb.replace('~thumb.jpg', '~medium.jpg').replace('~small.jpg', '~medium.jpg');
          const large = thumb.replace('~thumb.jpg', '~large.jpg').replace('~small.jpg', '~large.jpg');
          const orig = thumb.replace('~thumb.jpg', '~orig.jpg').replace('~small.jpg', '~orig.jpg');

          // Detect camera
          const text = `${d.title} ${d.description}`.toLowerCase();
          let detectedCam = 'Surface Camera';
          if (text.includes('mastcam')) detectedCam = 'Mastcam';
          else if (text.includes('navcam') || text.includes('navigation camera')) detectedCam = 'Navcam';
          else if (text.includes('hazcam') || text.includes('hazard')) detectedCam = 'Hazcam';
          else if (text.includes('supercam')) detectedCam = 'SuperCam';
          else if (text.includes('watson')) detectedCam = 'WATSON';
          else if (text.includes('mahli')) detectedCam = 'MAHLI';
          else if (text.includes('pancam')) detectedCam = 'Pancam';
          else if (text.includes('chemcam')) detectedCam = 'ChemCam';

          return {
            id: nasaId,
            nasaId,
            title: d.title || 'Mars Surface Image',
            description: d.description || '',
            date: d.date_created?.slice(0, 10) || '',
            rover: rover.name,
            camera: detectedCam,
            thumbUrl: thumb,
            mediumUrl: medium,
            largeUrl: large,
            origUrl: orig,
          };
        }).filter((item: NASAItem) => item.thumbUrl);

        setImages(parsed);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to load NASA images:', err);
        setError('Unable to stream images from NASA right now. Please check network connectivity.');
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchRoverImages(currentRover);
  }, [selectedRoverId]);

  // Dynamic fetch for "The Rovers" view when user selects a specific rover
  const fetchRoverSelfies = (roverQuery: string, roverName: string) => {
    setRoverLoading(true);
    const query = encodeURIComponent(roverQuery);
    const url = `https://images-api.nasa.gov/search?q=${query}&media_type=image&page_size=24`;

    fetch(url, { headers: { Accept: 'application/json' } })
      .then((res) => res.json())
      .then((data) => {
        const rawItems = data.collection?.items || [];
        const parsed: NASAItem[] = rawItems.map((item: any) => {
          const d = item.data?.[0] || {};
          const links = item.links || [];
          const rawThumb = links.find((l: any) => l.rel === 'preview')?.href || links[0]?.href || '';
          const thumb = rawThumb.replace(/^http:\/\//i, 'https://');
          const nasaId = d.nasa_id || 'mars_img';

          return {
            id: nasaId,
            nasaId,
            title: d.title || `${roverName} Hardware View`,
            description: d.description || '',
            date: d.date_created?.slice(0, 10) || '',
            rover: roverName,
            camera: 'Rover Self-Portrait / Hardware',
            thumbUrl: thumb,
            mediumUrl: thumb.replace('~thumb.jpg', '~medium.jpg').replace('~small.jpg', '~medium.jpg'),
            largeUrl: thumb.replace('~thumb.jpg', '~large.jpg').replace('~small.jpg', '~large.jpg'),
            origUrl: thumb.replace('~thumb.jpg', '~orig.jpg').replace('~small.jpg', '~orig.jpg'),
          };
        }).filter((item: NASAItem) => item.thumbUrl);

        // Prepend curated items for this rover if available
        const curated = CURATED_ROVER_SHOWCASE.filter(
          (c) => c.rover.toLowerCase().includes(roverName.split(' ')[0].toLowerCase())
        );

        const combined = [...curated, ...parsed.filter((p) => !curated.some((c) => c.nasaId === p.nasaId))];
        setRoverHardwareImages(combined.length > 0 ? combined : CURATED_ROVER_SHOWCASE);
        setRoverLoading(false);
      })
      .catch(() => {
        setRoverLoading(false);
      });
  };

  // Filter images by camera and text search
  const filteredSurfaceImages = useMemo(() => {
    return images.filter((img) => {
      const matchesCamera =
        selectedCamera === 'All Cameras' ||
        img.camera.toLowerCase().includes(selectedCamera.toLowerCase()) ||
        img.title.toLowerCase().includes(selectedCamera.toLowerCase());

      const matchesSearch =
        !searchFilter ||
        img.title.toLowerCase().includes(searchFilter.toLowerCase()) ||
        img.description.toLowerCase().includes(searchFilter.toLowerCase()) ||
        img.nasaId.toLowerCase().includes(searchFilter.toLowerCase());

      return matchesCamera && matchesSearch;
    });
  }, [images, selectedCamera, searchFilter]);

  // Filter for rover hardware images
  const filteredRoverHardware = useMemo(() => {
    if (roverFilter === 'All Rovers') {
      return roverHardwareImages;
    }
    return roverHardwareImages.filter(
      (img) =>
        img.rover.toLowerCase().includes(roverFilter.toLowerCase()) ||
        img.title.toLowerCase().includes(roverFilter.toLowerCase())
    );
  }, [roverHardwareImages, roverFilter]);

  // Direct In-App Image Download Handler
  const handleDownload = async (img: NASAItem, preferredUrl?: string) => {
    const downloadUrl = (preferredUrl || img.origUrl || img.largeUrl || img.mediumUrl || img.thumbUrl).replace(/^http:\/\//i, 'https://');
    const cleanRoverName = img.rover.replace(/[^a-zA-Z0-9]/g, '_');
    const cleanDate = img.date || 'mars';
    const cleanId = img.nasaId || 'photo';
    const filename = `${cleanRoverName}_${cleanDate}_${cleanId}.jpg`;

    setDownloadingId(img.id);

    try {
      // First attempt: use backend proxy for guaranteed CORS-free attachment download
      const proxyUrl = `/api/download-image?url=${encodeURIComponent(downloadUrl)}&filename=${encodeURIComponent(filename)}`;
      
      const res = await fetch(proxyUrl);
      if (res.ok) {
        const blob = await res.blob();
        const blobUrl = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = blobUrl;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(blobUrl);
        document.body.removeChild(a);

        setDownloadSuccess(img.id);
        setTimeout(() => setDownloadSuccess(null), 3000);
        setDownloadingId(null);
        return;
      }
    } catch (e) {
      console.warn('Backend proxy download failed, falling back to direct anchor:', e);
    }

    // Direct client fallback
    try {
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = downloadUrl;
      a.download = filename;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      setDownloadSuccess(img.id);
      setTimeout(() => setDownloadSuccess(null), 3000);
    } catch (e) {
      console.error('Download failed:', e);
    } finally {
      setDownloadingId(null);
    }
  };

  // Fly to Rover Location on Mars Globe
  const handleFlyToRover = (roverObj?: RoverOption) => {
    const target = roverObj || currentRover;
    if (!viewer) return;
    viewer.camera.flyTo({
      destination: Cesium.Cartesian3.fromDegrees(
        target.lon,
        target.lat,
        80000 // 80 km altitude surface view
      ),
      orientation: {
        heading: Cesium.Math.toRadians(0),
        pitch: Cesium.Math.toRadians(-55),
        roll: 0,
      },
      duration: 2.5,
    });
  };

  return (
    <>
      <motion.div
        initial={{ x: -30, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: -30, opacity: 0 }}
        transition={{ duration: 0.25, ease: 'easeOut' }}
        className="fixed top-16 left-20 w-96 md:w-[520px] bottom-16 bg-[#0a0d14] border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col z-30 overflow-hidden pointer-events-auto"
      >
        {/* Panel Header */}
        <div className="p-4 border-b border-slate-700/80 bg-[#0f1420] flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <span className="text-xl">📷</span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-white font-display font-bold text-sm">Live Rover Imagery</h2>
                <span className="flex items-center gap-1 text-[9px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold uppercase tracking-wider">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  NASA Live Archive
                </span>
              </div>
              <p className="text-white/40 text-[11px] mt-0.5">Stream and download authentic Mars surface &amp; rover photos</p>
            </div>
          </div>
          <button
            onClick={() => setActivePanel(null)}
            className="text-white/40 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
            title="Close"
          >
            ✕
          </button>
        </div>

        {/* Top-Level Section Switcher: "Surface Scenery" vs "The Rovers" */}
        <div className="p-2.5 bg-[#0b0f19] border-b border-slate-700/80 flex items-center gap-2 flex-shrink-0">
          <button
            onClick={() => setActiveSection('surface')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSection === 'surface'
                ? 'bg-mars-600 text-white shadow-[0_0_12px_rgba(232,82,26,0.5)] border border-mars-400/40'
                : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10 border border-white/5'
            }`}
          >
            <span>📸</span>
            <span>Surface Scenery (By Rovers)</span>
          </button>
          <button
            onClick={() => setActiveSection('rovers')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSection === 'rovers'
                ? 'bg-mars-600 text-white shadow-[0_0_12px_rgba(232,82,26,0.5)] border border-mars-400/40'
                : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10 border border-white/5'
            }`}
          >
            <span>🤖</span>
            <span>The Rovers (Sent to Mars)</span>
          </button>
        </div>

        {/* SECTION 1: SURFACE SCENERY (Taken BY Rovers) */}
        {activeSection === 'surface' && (
          <>
            {/* Rover Selector Pills */}
            <div className="px-3 py-2.5 bg-black/40 border-b border-slate-700/60 flex items-center gap-1.5 overflow-x-auto flex-shrink-0">
              {ROVERS.map((r) => {
                const isSelected = r.id === selectedRoverId;
                return (
                  <button
                    key={r.id}
                    onClick={() => {
                      setSelectedRoverId(r.id);
                      setSelectedCamera('All Cameras');
                    }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-mars-600 text-white shadow-[0_0_12px_rgba(232,82,26,0.5)] border border-mars-400/40'
                        : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10 border border-white/5'
                    }`}
                  >
                    <span>{r.icon}</span>
                    <span>{r.name.split(' ')[0]}</span>
                    {r.status === 'active' && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Rover Context Banner + Fly to Rover Button */}
            <div className="px-4 py-2.5 bg-[#121826] border-b border-slate-700/60 flex items-center justify-between flex-shrink-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-white">{currentRover.name}</span>
                <span className="text-[11px] text-white/50">· {currentRover.locationName}</span>
              </div>
              <button
                onClick={() => handleFlyToRover(currentRover)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-mars-500/20 hover:bg-mars-500/30 text-mars-300 border border-mars-500/40 text-[11px] font-semibold transition-colors cursor-pointer"
                title="Rotate globe to this landing site"
              >
                <span>🎯</span>
                <span>View on Globe</span>
              </button>
            </div>

            {/* Filters: Cameras & Search */}
            <div className="p-3 bg-black/20 border-b border-slate-700/60 space-y-2 flex-shrink-0">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
                {currentRover.cameras.map((cam) => {
                  const active = selectedCamera === cam;
                  return (
                    <button
                      key={cam}
                      onClick={() => setSelectedCamera(cam)}
                      className={`px-2.5 py-1 rounded-lg font-mono whitespace-nowrap transition-all cursor-pointer ${
                        active
                          ? 'bg-sky-500/20 text-sky-300 border border-sky-400/50'
                          : 'bg-white/5 text-white/50 hover:text-white/80 border border-white/5'
                      }`}
                    >
                      {cam}
                    </button>
                  );
                })}
              </div>

              <div className="relative">
                <input
                  type="text"
                  value={searchFilter}
                  onChange={(e) => setSearchFilter(e.target.value)}
                  placeholder="Search surface photos (e.g. delta, rock, panorama, sol)..."
                  className="w-full px-3 py-1.5 text-xs rounded-xl bg-space-900 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-mars-500"
                />
                {searchFilter && (
                  <button
                    onClick={() => setSearchFilter('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white text-xs"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>

            {/* Surface Image Grid */}
            <div className="flex-1 overflow-y-auto p-4">
              {loading && (
                <div className="flex flex-col items-center justify-center py-16 gap-3 text-white/40">
                  <div className="w-6 h-6 border-2 border-mars-500 border-t-transparent rounded-full animate-spin" />
                  <p className="text-xs">Fetching latest authentic images from NASA…</p>
                </div>
              )}

              {error && (
                <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-500/30 text-xs text-rose-300 space-y-2">
                  <p>{error}</p>
                  <button
                    onClick={() => fetchRoverImages(currentRover)}
                    className="px-3 py-1 rounded-lg bg-rose-800/40 hover:bg-rose-800 text-white font-medium text-xs transition-colors cursor-pointer"
                  >
                    Retry Request
                  </button>
                </div>
              )}

              {!loading && filteredSurfaceImages.length === 0 && !error && (
                <div className="text-center py-16 text-white/40 text-xs">
                  No matching images found. Try selecting "All Cameras" or clearing the search.
                </div>
              )}

              {!loading && filteredSurfaceImages.length > 0 && (
                <div className="grid grid-cols-2 gap-3">
                  {filteredSurfaceImages.map((img) => (
                    <div
                      key={img.id}
                      className="group relative rounded-xl overflow-hidden border border-white/10 bg-black/40 hover:border-mars-500/50 transition-all flex flex-col"
                    >
                      <div
                        onClick={() => {
                          setInspectImage(img);
                          setZoomLevel(1);
                        }}
                        className="relative cursor-pointer aspect-video bg-black/60 overflow-hidden"
                      >
                        <img
                          src={img.thumbUrl}
                          alt={img.title}
                          loading="lazy"
                          onError={(e) => {
                            const target = e.currentTarget;
                            if (target.src.includes('~thumb.jpg')) {
                              target.src = target.src.replace('~thumb.jpg', '~small.jpg');
                            }
                          }}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-between p-2 pointer-events-none">
                          <span className="text-[10px] text-white font-medium line-clamp-1">
                            🔍 Inspect in ARES
                          </span>
                        </div>
                      </div>

                      <div className="p-2.5 flex-1 flex flex-col justify-between space-y-2">
                        <div>
                          <div className="flex items-center justify-between text-[10px] font-mono mb-1">
                            <span className="text-sky-400 font-semibold">{img.camera}</span>
                            {img.date && <span className="text-white/40">{img.date}</span>}
                          </div>
                          <h4
                            onClick={() => {
                              setInspectImage(img);
                              setZoomLevel(1);
                            }}
                            className="text-xs text-white/90 font-medium line-clamp-2 leading-tight cursor-pointer hover:text-mars-400 transition-colors"
                            title={img.title}
                          >
                            {img.title}
                          </h4>
                        </div>

                        <div className="flex items-center gap-1.5 pt-1 border-t border-white/5">
                          <button
                            onClick={() => {
                              setInspectImage(img);
                              setZoomLevel(1);
                            }}
                            className="flex-1 py-1 px-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[10px] font-medium transition-colors text-center cursor-pointer"
                          >
                            Inspect
                          </button>
                          <button
                            onClick={() => handleDownload(img, img.origUrl || img.largeUrl)}
                            disabled={downloadingId === img.id}
                            className={`flex items-center justify-center gap-1 py-1 px-2.5 rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${
                              downloadSuccess === img.id
                                ? 'bg-emerald-600 text-white'
                                : 'bg-mars-600 hover:bg-mars-500 text-white'
                            }`}
                            title="Download image to your device"
                          >
                            {downloadingId === img.id ? (
                              <span className="animate-spin text-[10px]">⏳</span>
                            ) : downloadSuccess === img.id ? (
                              <span>✓ Saved</span>
                            ) : (
                              <>
                                <span>📥</span>
                                <span>Download</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {/* SECTION 2: THE ROVERS (Photos OF the Rovers Sent to Mars) */}
        {activeSection === 'rovers' && (
          <>
            {/* Rover Filter Bar */}
            <div className="px-3 py-2.5 bg-black/40 border-b border-slate-700/60 flex items-center gap-1.5 overflow-x-auto flex-shrink-0">
              {['All Rovers', 'Perseverance', 'Curiosity', 'Opportunity', 'Spirit', 'Sojourner'].map((name) => {
                const active = roverFilter === name;
                return (
                  <button
                    key={name}
                    onClick={() => {
                      setRoverFilter(name);
                      if (name !== 'All Rovers') {
                        const target = ROVERS.find((r) => r.name.toLowerCase().includes(name.toLowerCase()));
                        if (target) {
                          fetchRoverSelfies(target.roverSelfieQuery, target.name);
                        }
                      } else {
                        setRoverHardwareImages(CURATED_ROVER_SHOWCASE);
                      }
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                      active
                        ? 'bg-mars-600 text-white shadow-[0_0_12px_rgba(232,82,26,0.5)] border border-mars-400/40'
                        : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10 border border-white/5'
                    }`}
                  >
                    {name}
                  </button>
                );
              })}
            </div>

            {/* Hardware Information Banner */}
            <div className="px-4 py-2.5 bg-[#121826] border-b border-slate-700/60 flex items-center justify-between flex-shrink-0">
              <div className="text-xs text-white/80">
                <span className="font-semibold text-white">Robotic Explorers of Mars</span>
                <span className="text-white/40 ml-1.5">· Selfies, hardware portraits &amp; deployment views</span>
              </div>
              <span className="text-[10px] font-mono text-mars-400 bg-mars-500/10 px-2 py-0.5 rounded border border-mars-500/20">
                {filteredRoverHardware.length} Portraits
              </span>
            </div>

            {/* Rover Hardware Grid */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {roverLoading && (
                <div className="flex flex-col items-center justify-center py-16 gap-3 text-white/40">
                  <div className="w-6 h-6 border-2 border-mars-500 border-t-transparent rounded-full animate-spin" />
                  <p className="text-xs">Streaming rover hardware portraits from NASA…</p>
                </div>
              )}

              {!roverLoading && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {filteredRoverHardware.map((item) => {
                    const matchedRover = ROVERS.find((r) =>
                      item.rover.toLowerCase().includes(r.id.toLowerCase())
                    );

                    return (
                      <div
                        key={item.id}
                        className="group rounded-xl overflow-hidden border border-white/10 bg-[#0f1422] hover:border-mars-500/50 transition-all flex flex-col justify-between"
                      >
                        {/* Rover Image with Zoom on Hover */}
                        <div
                          onClick={() => {
                            setInspectImage(item);
                            setZoomLevel(1);
                          }}
                          className="relative aspect-video bg-black/80 overflow-hidden cursor-pointer"
                        >
                          <img
                            src={item.thumbUrl}
                            alt={item.title}
                            loading="lazy"
                            onError={(e) => {
                              const target = e.currentTarget;
                              if (target.src.includes('~thumb.jpg')) {
                                target.src = target.src.replace('~thumb.jpg', '~small.jpg');
                              }
                            }}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-black/70 border border-white/20 text-[9px] font-mono text-emerald-400 font-bold backdrop-blur-sm">
                            {item.rover.split(' ')[0]}
                          </div>
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2 pointer-events-none">
                            <span className="text-[10px] text-white font-medium">
                              🔍 Click to Inspect Full-Res
                            </span>
                          </div>
                        </div>

                        {/* Rover Card Info */}
                        <div className="p-3 space-y-2 flex-1 flex flex-col justify-between">
                          <div>
                            <h4
                              onClick={() => {
                                setInspectImage(item);
                                setZoomLevel(1);
                              }}
                              className="text-xs font-semibold text-white hover:text-mars-400 cursor-pointer transition-colors leading-snug line-clamp-2"
                            >
                              {item.title}
                            </h4>

                            {/* Specifications Chip if available */}
                            {item.specs && (
                              <div className="mt-2 grid grid-cols-2 gap-1.5 p-2 rounded-lg bg-black/40 border border-white/5 text-[10px] font-mono">
                                <div>
                                  <span className="text-white/40">Mass: </span>
                                  <span className="text-white/80">{item.specs.mass}</span>
                                </div>
                                <div>
                                  <span className="text-white/40">Power: </span>
                                  <span className="text-amber-400">{item.specs.power}</span>
                                </div>
                                <div>
                                  <span className="text-white/40">Landed: </span>
                                  <span className="text-white/80">{item.specs.landed}</span>
                                </div>
                                <div>
                                  <span className="text-white/40">Status: </span>
                                  <span className="text-emerald-400">{item.specs.status.split('·')[0]}</span>
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Action Bar */}
                          <div className="flex items-center gap-1.5 pt-2 border-t border-white/5">
                            <button
                              onClick={() => {
                                setInspectImage(item);
                                setZoomLevel(1);
                              }}
                              className="flex-1 py-1 px-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[10px] font-medium transition-colors text-center cursor-pointer"
                            >
                              Inspect
                            </button>
                            <button
                              onClick={() => handleDownload(item, item.origUrl || item.largeUrl)}
                              disabled={downloadingId === item.id}
                              className={`flex items-center justify-center gap-1 py-1 px-2.5 rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${
                                downloadSuccess === item.id
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-mars-600 hover:bg-mars-500 text-white'
                              }`}
                              title="Download rover portrait"
                            >
                              {downloadingId === item.id ? (
                                <span className="animate-spin text-[10px]">⏳</span>
                              ) : downloadSuccess === item.id ? (
                                <span>✓ Saved</span>
                              ) : (
                                <>
                                  <span>📥</span>
                                  <span>Download</span>
                                </>
                              )}
                            </button>
                            {matchedRover && (
                              <button
                                onClick={() => handleFlyToRover(matchedRover)}
                                className="p-1 px-2 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 text-[10px] font-semibold transition-colors cursor-pointer"
                                title="Fly to rover on 3D globe"
                              >
                                🎯 Fly
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </>
        )}

        {/* Footer Status */}
        <div className="px-4 py-2.5 border-t border-slate-700/80 bg-[#0f1420] flex items-center justify-between text-[11px] text-white/40 flex-shrink-0">
          <span>
            {activeSection === 'surface'
              ? `${filteredSurfaceImages.length} surface photos streamable`
              : `${filteredRoverHardware.length} rover hardware portraits`}
          </span>
          <span className="font-mono text-[10px] text-emerald-400">Direct In-App Retrieval</span>
        </div>
      </motion.div>

      {/* Full-Screen In-App Image Inspector & Downloader Modal (Completely within ARES) */}
      <AnimatePresence>
        {inspectImage && (
          <div
            className="fixed inset-0 z-[250] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 md:p-8 pointer-events-auto select-none"
            onClick={() => setInspectImage(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.2 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-5xl h-[88vh] bg-[#0c101a] border border-slate-700 rounded-2xl shadow-2xl flex flex-col md:flex-row overflow-hidden"
            >
              {/* Close Button */}
              <button
                onClick={() => setInspectImage(null)}
                className="absolute top-3 right-3 z-20 w-8 h-8 rounded-full bg-black/70 hover:bg-black text-white flex items-center justify-center text-sm transition-colors border border-white/20 cursor-pointer"
                title="Close viewer"
              >
                ✕
              </button>

              {/* Main Image Canvas Viewport */}
              <div className="relative flex-1 bg-black/90 flex items-center justify-center overflow-hidden p-4">
                {modalImgLoading && (
                  <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/70 border border-white/20 text-xs text-white/80 backdrop-blur-sm">
                      <div className="w-3.5 h-3.5 border-2 border-mars-500 border-t-transparent rounded-full animate-spin" />
                      <span>Loading High-Res…</span>
                    </div>
                  </div>
                )}
                <div
                  className="transition-transform duration-200 ease-out max-w-full max-h-full flex items-center justify-center"
                  style={{ transform: `scale(${zoomLevel})` }}
                >
                  <img
                    src={modalImgSrc || inspectImage.thumbUrl}
                    alt={inspectImage.title}
                    onLoad={() => setModalImgLoading(false)}
                    onError={() => {
                      // Automatic resilient fallback if high-res fails: drop to guaranteed thumbUrl
                      if (modalImgSrc !== inspectImage.thumbUrl) {
                        setModalImgSrc(inspectImage.thumbUrl);
                      }
                      setModalImgLoading(false);
                    }}
                    className="max-w-full max-h-[75vh] object-contain rounded-lg shadow-2xl transition-opacity duration-200"
                  />
                </div>

                {/* In-App Zoom Controls */}
                <div className="absolute bottom-4 left-4 flex items-center gap-1.5 bg-black/70 border border-white/15 rounded-xl p-1 backdrop-blur-sm">
                  <button
                    onClick={() => setZoomLevel((z) => Math.min(3, z + 0.25))}
                    className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-colors cursor-pointer"
                    title="Zoom in"
                  >
                    +
                  </button>
                  <span className="text-[10px] font-mono text-white/80 px-2">
                    {Math.round(zoomLevel * 100)}%
                  </span>
                  <button
                    onClick={() => setZoomLevel((z) => Math.max(0.75, z - 0.25))}
                    className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-colors cursor-pointer"
                    title="Zoom out"
                  >
                    −
                  </button>
                  <button
                    onClick={() => setZoomLevel(1)}
                    className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[10px] font-mono transition-colors ml-1 cursor-pointer"
                    title="Reset zoom"
                  >
                    Reset
                  </button>
                </div>
              </div>

              {/* In-App Scientific Information & Direct Download Sidebar */}
              <div className="w-full md:w-88 border-t md:border-t-0 md:border-l border-slate-700/80 bg-[#0d121f] flex flex-col justify-between p-5 overflow-y-auto">
                <div className="space-y-4">
                  {/* Header */}
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-500/20 text-sky-400 border border-sky-500/30 font-bold uppercase">
                        {inspectImage.camera}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/10 text-white/60">
                        {inspectImage.nasaId}
                      </span>
                    </div>
                    <h3 className="text-white font-display font-bold text-base leading-snug">
                      {inspectImage.title}
                    </h3>
                  </div>

                  {/* Metadata Specs */}
                  <div className="p-3 rounded-xl bg-black/30 border border-white/5 space-y-2 text-xs font-mono">
                    <div className="flex justify-between items-center py-1 border-b border-white/5">
                      <span className="text-white/40 font-sans">Mission / Rover:</span>
                      <span className="text-white font-medium">{inspectImage.rover}</span>
                    </div>
                    {inspectImage.specs?.mass && (
                      <div className="flex justify-between items-center py-1 border-b border-white/5">
                        <span className="text-white/40 font-sans">Rover Mass:</span>
                        <span className="text-white/80">{inspectImage.specs.mass}</span>
                      </div>
                    )}
                    {inspectImage.specs?.power && (
                      <div className="flex justify-between items-center py-1 border-b border-white/5">
                        <span className="text-white/40 font-sans">Power Source:</span>
                        <span className="text-amber-400">{inspectImage.specs.power}</span>
                      </div>
                    )}
                    <div className="flex justify-between items-center py-1 border-b border-white/5">
                      <span className="text-white/40 font-sans">Capture Date:</span>
                      <span className="text-emerald-400">{inspectImage.date || 'Martian Sol'}</span>
                    </div>
                    <div className="flex justify-between items-center py-1">
                      <span className="text-white/40 font-sans">Data Source:</span>
                      <span className="text-white/80">NASA Image Library</span>
                    </div>
                  </div>

                  {/* Scientific Description */}
                  {inspectImage.description && (
                    <div className="space-y-1.5">
                      <div className="text-[10px] font-mono text-white/40 uppercase tracking-wider">
                        NASA Science Caption
                      </div>
                      <p className="text-xs text-white/70 leading-relaxed max-h-48 overflow-y-auto pr-1">
                        {inspectImage.description}
                      </p>
                    </div>
                  )}
                </div>

                {/* Direct Download Buttons (Completely within ARES) */}
                <div className="pt-4 border-t border-slate-700/80 space-y-2 mt-4">
                  <button
                    onClick={() => handleDownload(inspectImage, modalOrigUrl || modalImgSrc || inspectImage.origUrl)}
                    disabled={downloadingId === inspectImage.id}
                    className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-mars-600 to-mars-500 hover:from-mars-500 hover:to-mars-400 text-white font-semibold text-xs shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <span>📥</span>
                    <span>
                      {downloadingId === inspectImage.id
                        ? 'Downloading High-Res…'
                        : downloadSuccess === inspectImage.id
                        ? 'Download Complete ✓'
                        : 'Download Full-Res HD Image'}
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      const matched = ROVERS.find((r) =>
                        inspectImage.rover.toLowerCase().includes(r.id.toLowerCase())
                      );
                      setInspectImage(null);
                      if (matched) handleFlyToRover(matched);
                      else handleFlyToRover(currentRover);
                    }}
                    className="w-full py-2 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-white/80 hover:text-white border border-white/10 text-xs font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <span>🎯</span>
                    <span>Fly to Landing Site on Mars Globe</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
