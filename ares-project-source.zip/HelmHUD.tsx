/**
 * HelmHUD.tsx
 * Astronaut Visor Helmet Heads-Up Display (HUD) simulation.
 * Replaces the default desktop UI with an authentic spacesuit telemetry overlay.
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { usePlannerStore } from '../../store/plannerStore';

interface HelmHUDProps {
  onExit: () => void;
}

export const HelmHUD: React.FC<HelmHUDProps> = ({ onExit }) => {
  const waypoints = usePlannerStore((s) => s.waypoints);
  const baseLocation = usePlannerStore((s) => s.baseLocation);
  const objective = usePlannerStore((s) => s.objective);
  const getTotalDistanceKm = usePlannerStore((s) => s.getTotalDistanceKm);

  const [seconds, setSeconds] = useState(142 * 60 + 18); // 02:22:18 elapsed
  const [headingDeg, setHeadingDeg] = useState(42);
  const [activeWpIndex, setActiveWpIndex] = useState(1);

  useEffect(() => {
    const timer = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTimer = (totalSec: number) => {
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const nextWaypoint = waypoints[activeWpIndex] || waypoints[0] || {
    label: 'Target Alpha',
    lat: -4.68,
    lon: 137.38,
  };

  const totalKm = getTotalDistanceKm();

  return (
    <div className="fixed inset-0 z-50 pointer-events-none select-none flex flex-col justify-between p-6 md:p-10 font-mono text-emerald-400">
      {/* Visor Vignette and Scanline Overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          boxShadow: 'inset 0 0 140px rgba(0, 0, 0, 0.85)',
          background:
            'radial-gradient(circle, transparent 60%, rgba(0, 10, 5, 0.4) 100%), repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(0, 255, 120, 0.03) 3px, rgba(0, 255, 120, 0.03) 4px)',
        }}
      />

      {/* TOP TELEMETRY BAR */}
      <div className="relative z-10 flex items-center justify-between border-b border-emerald-500/30 pb-3 bg-black/40 backdrop-blur-sm px-6 py-3 rounded-2xl">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs uppercase tracking-widest text-emerald-300 font-bold">
              EVA SUIT // HUD V2.4
            </span>
          </div>
          <div className="text-xs text-emerald-400/70 hidden sm:block">
            LOC: {baseLocation?.name || 'Gale Crater'}
          </div>
        </div>

        {/* Life Support Status */}
        <div className="flex items-center gap-8 text-xs">
          <div>
            <span className="text-emerald-500/60">EVA TIME: </span>
            <span className="font-bold text-white tracking-wider">{formatTimer(seconds)}</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-emerald-500/60">O₂ PRESSURE: </span>
            <span className="text-emerald-300 font-bold">4.3 psi (82%)</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-emerald-500/60">SUIT TEMP: </span>
            <span className="text-white font-bold">+18.4°C</span>
          </div>

          {/* Exit HUD Button */}
          <button
            onClick={onExit}
            className="pointer-events-auto px-3.5 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/50 text-xs font-sans tracking-wide transition-all shadow-[0_0_12px_rgba(16,185,129,0.3)]"
          >
            ✕ Exit HUD
          </button>
        </div>
      </div>

      {/* CENTER VISOR RETICLE */}
      <div className="relative z-10 flex items-center justify-between px-8">
        {/* Left: Compass / Attitude */}
        <div className="w-48 p-4 rounded-2xl bg-black/40 border border-emerald-500/30 backdrop-blur-sm space-y-2">
          <div className="text-[10px] text-emerald-500/60 uppercase">Heading & Azimuth</div>
          <div className="text-2xl font-bold text-emerald-300">
            {headingDeg}° <span className="text-sm font-normal text-emerald-400/70">NNE</span>
          </div>
          <div className="w-full bg-emerald-950/60 h-1.5 rounded-full overflow-hidden border border-emerald-500/30">
            <div className="bg-emerald-400 h-full" style={{ width: `${(headingDeg / 360) * 100}%` }} />
          </div>
          <div className="text-[10px] text-emerald-400/50 pt-1">
            HABITAT BEARING: 224° SW (1.2 km)
          </div>
        </div>

        {/* Center: Waypoint Navigation Vector */}
        <div className="flex flex-col items-center text-center space-y-2">
          <div className="w-16 h-16 rounded-full border border-emerald-500/40 flex items-center justify-center relative">
            <span className="text-2xl animate-bounce">▲</span>
            <div className="absolute inset-0 rounded-full border border-dashed border-emerald-400/30 animate-spin" style={{ animationDuration: '20s' }} />
          </div>

          <div className="bg-black/60 px-5 py-2 rounded-xl border border-emerald-500/30 backdrop-blur-sm">
            <div className="text-xs text-emerald-300 font-bold uppercase tracking-wider">
              NEXT WAYPOINT: {nextWaypoint.label}
            </div>
            <div className="text-xl font-bold text-white mt-0.5">
              840 <span className="text-xs text-emerald-400 font-normal">metres</span>
            </div>
            <div className="text-[10px] text-emerald-400/60 mt-0.5">
              SLOPE GRADIENT: 11.4° (SAFE PASSAGE)
            </div>
          </div>
        </div>

        {/* Right: Radiation & Environment Warning */}
        <div className="w-48 p-4 rounded-2xl bg-black/40 border border-emerald-500/30 backdrop-blur-sm space-y-3">
          <div>
            <div className="text-[10px] text-emerald-500/60 uppercase">Radiation Flux (MSL RAD)</div>
            <div className="text-base font-bold text-emerald-300 flex items-center gap-2 mt-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <span>0.62 mGy/d (NOMINAL)</span>
            </div>
          </div>

          <div className="pt-2 border-t border-emerald-500/20">
            <div className="text-[10px] text-emerald-500/60 uppercase">Mobility Status</div>
            <div className="text-xs text-white mt-0.5">SUIT ARTICULATION 100%</div>
            <div className="text-[10px] text-emerald-400/70">MAX SLOPE LIMIT: 30°</div>
          </div>
        </div>
      </div>

      {/* BOTTOM STATUS ARC */}
      <div className="relative z-10 flex items-center justify-between border-t border-emerald-500/30 pt-3 bg-black/40 backdrop-blur-sm px-6 py-3 rounded-2xl text-xs">
        <div className="flex items-center gap-4">
          <span className="text-emerald-500/60">TRAVERSE PROGRESS:</span>
          <span className="text-white font-bold">1.4 km / {totalKm.toFixed(1)} km</span>
          <div className="w-32 bg-emerald-950/80 h-2 rounded-full overflow-hidden border border-emerald-500/40">
            <div className="bg-emerald-400 h-full w-[40%]" />
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div>
            <span className="text-emerald-500/60">SCI GOAL: </span>
            <span className="text-emerald-200 uppercase">{objective || 'Surface Exploration'}</span>
          </div>
          <div>
            <span className="text-emerald-500/60">COMMS: </span>
            <span className="text-emerald-300">TGO ORBITER RELAY 100%</span>
          </div>
        </div>
      </div>
    </div>
  );
};
