/**
 * AttributionModal.tsx
 * Comprehensive Data, Telemetry, and Scientific Attribution Directory.
 */

import React from 'react';
import { motion } from 'framer-motion';

interface AttributionModalProps {
  onClose: () => void;
}

export const AttributionModal: React.FC<AttributionModalProps> = ({ onClose }) => {
  const sources = [
    {
      source: 'NASA Mars Trek (JPL)',
      product: 'Viking MDIM 2.1, MOLA Shaded Relief & Color DEM, THEMIS Day/Night IR, CTX Mosaic, CRISM',
      url: 'https://trek.nasa.gov/mars',
      license: 'Public Domain (US Government Work)',
    },
    {
      source: 'USGS Astrogeology',
      product: 'Geologic Map of Mars (Tanaka et al. 2014) & IAU Gazetteer of Planetary Nomenclature',
      url: 'https://astrogeology.usgs.gov',
      license: 'Public Domain',
    },
    {
      source: 'NASA Planetary Data System (PDS)',
      product: 'Curiosity MSL RAD radiation archive, REMS meteorology & Perseverance MEDA telemetry',
      url: 'https://pds.nasa.gov',
      license: 'Public Domain',
    },
    {
      source: 'ESA (European Space Agency)',
      product: 'Mars Express HRSC orthomosaics & ExoMars Trace Gas Orbiter CaSSIS surface imagery',
      url: 'https://archives.esac.esa.int/psa/',
      license: 'CC BY-SA 3.0 IGO',
    },
    {
      source: 'CNSA (China National Space Administration)',
      product: 'Tianwen-1 & Zhurong rover surface releases (Utopia Planitia)',
      url: 'http://www.cnsa.gov.cn',
      license: 'Official CNSA/CLEP Public Release',
    },
    {
      source: 'ISRO (Indian Space Research Organisation)',
      product: 'Mars Orbiter Mission (Mangalyaan) Mars Color Camera (MCC) imagery',
      url: 'https://www.isro.gov.in',
      license: 'Official ISRO Release',
    },
    {
      source: 'CesiumJS',
      product: '3D Virtual Globe Engine with Mars 2000 reference ellipsoid',
      url: 'https://cesium.com/cesiumjs/',
      license: 'Apache 2.0 License',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md pointer-events-auto"
    >
      <motion.div
        initial={{ scale: 0.95, y: 10 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 10 }}
        className="w-full max-w-2xl bg-space-900 border border-white/20 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
      >
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between bg-space-800/80">
          <div>
            <h2 className="text-xl font-display font-bold text-white tracking-wide">
              Scientific Data & Attribution
            </h2>
            <p className="text-xs text-white/50 mt-0.5">
              Ares relies exclusively on verified, open data products from world space agencies.
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Content Table */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
          {sources.map((item, idx) => (
            <div
              key={idx}
              className="p-3.5 rounded-xl bg-space-800/40 border border-white/10 space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white text-sm">{item.source}</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/10 text-white/60">
                  {item.license}
                </span>
              </div>
              <p className="text-white/70 leading-relaxed text-[11px]">{item.product}</p>
              <div className="pt-1">
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-mars-400 hover:text-mars-300 font-medium text-[11px]"
                >
                  {item.url} ↗
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-space-950/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-mars-600 hover:bg-mars-500 text-white text-xs font-medium transition-colors"
          >
            Close Directory
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};
