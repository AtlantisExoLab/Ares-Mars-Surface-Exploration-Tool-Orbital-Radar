/**
 * WebGLSharpen.ts
 * Real-time adaptive unsharp-mask and contrast enhancement using WebGL.
 * Guaranteed zero-dependency fallback for imagery super-resolution.
 * Correctly handles texture orientation so output matches source coordinates 1:1.
 */

const VERTEX_SHADER = `
  attribute vec2 a_position;
  varying vec2 v_texCoord;
  void main() {
    // Preserve natural upright orientation matching HTML canvas coordinates
    v_texCoord = vec2((a_position.x + 1.0) * 0.5, (1.0 - a_position.y) * 0.5);
    gl_Position = vec4(a_position, 0.0, 1.0);
  }
`;

const SHARPEN_FRAGMENT_SHADER = `
  precision mediump float;
  uniform sampler2D u_image;
  uniform vec2 u_resolution;
  uniform float u_strength;
  varying vec2 v_texCoord;

  void main() {
    vec2 onePixel = vec2(1.0, 1.0) / u_resolution;

    // 3x3 Laplacian edge enhancement
    vec4 center = texture2D(u_image, v_texCoord);
    vec4 top    = texture2D(u_image, v_texCoord + vec2(0.0,  onePixel.y));
    vec4 bottom = texture2D(u_image, v_texCoord + vec2(0.0, -onePixel.y));
    vec4 left   = texture2D(u_image, v_texCoord + vec2(-onePixel.x, 0.0));
    vec4 right  = texture2D(u_image, v_texCoord + vec2( onePixel.x, 0.0));

    // High-pass difference
    vec4 laplacian = 4.0 * center - (top + bottom + left + right);
    vec4 sharpened = center + u_strength * laplacian;

    // Subtle micro-contrast boost for Martian basalt/dust features
    vec3 col = sharpened.rgb;
    col = (col - 0.5) * 1.08 + 0.5;

    gl_FragColor = vec4(clamp(col, 0.0, 1.0), center.a);
  }
`;

function createShader(gl: WebGLRenderingContext, type: number, source: string): WebGLShader | null {
  const shader = gl.createShader(type);
  if (!shader) return null;
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error('[WebGLSharpen] Shader compile error:', gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}

export function applyWebGLSharpen(
  sourceCanvas: HTMLCanvasElement,
  strength = 0.75
): HTMLCanvasElement {
  const outputCanvas = document.createElement('canvas');
  outputCanvas.width = sourceCanvas.width;
  outputCanvas.height = sourceCanvas.height;

  const gl = outputCanvas.getContext('webgl', { preserveDrawingBuffer: true });
  if (!gl) {
    // Canvas 2D fallback if WebGL is unavailable
    const ctx = outputCanvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(sourceCanvas, 0, 0);
      ctx.filter = 'contrast(1.18) saturate(1.08) brightness(1.02)';
      ctx.drawImage(sourceCanvas, 0, 0);
    }
    return outputCanvas;
  }

  const vShader = createShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
  const fShader = createShader(gl, gl.FRAGMENT_SHADER, SHARPEN_FRAGMENT_SHADER);
  if (!vShader || !fShader) return sourceCanvas;

  const program = gl.createProgram();
  if (!program) return sourceCanvas;

  gl.attachShader(program, vShader);
  gl.attachShader(program, fShader);
  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.error('[WebGLSharpen] Program link error:', gl.getProgramInfoLog(program));
    return sourceCanvas;
  }

  gl.useProgram(program);

  // Screen quad geometry
  const posBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, posBuffer);
  gl.bufferData(
    gl.ARRAY_BUFFER,
    new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]),
    gl.STATIC_DRAW
  );

  const posAttr = gl.getAttribLocation(program, 'a_position');
  gl.enableVertexAttribArray(posAttr);
  gl.vertexAttribPointer(posAttr, 2, gl.FLOAT, false, 0, 0);

  // Upload image to texture
  const texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, sourceCanvas);

  // Set uniforms
  gl.uniform2f(
    gl.getUniformLocation(program, 'u_resolution'),
    sourceCanvas.width,
    sourceCanvas.height
  );
  gl.uniform1f(gl.getUniformLocation(program, 'u_strength'), strength);

  gl.viewport(0, 0, sourceCanvas.width, sourceCanvas.height);
  gl.drawArrays(gl.TRIANGLES, 0, 6);

  return outputCanvas;
}
