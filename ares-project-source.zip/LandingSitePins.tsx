/**
 * LandingSitePins.tsx
 *
 * High-performance React component rendering Mars landing-site markers on a Cesium globe.
 *
 * Performance Features:
 *  - Pre-cached billboard canvas data-URLs (0 canvas allocations during runtime)
 *  - GPU-evaluated label distance visibility (DistanceDisplayCondition) - 0 CPU churn on camera move
 *  - Progressive disclosure via NearFarScalar
 *  - Fully memoized entity lifecycle keyed only by sites and selectedSiteId
 *  - Native Cesium ScreenSpaceEventHandler click detection
 */

import React, { useEffect, useRef } from 'react';
import * as Cesium from 'cesium';
import { marsLonToCesium } from './CoordinateUtils';
import type { LandingSite } from '../types/MarsTypes';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

interface Props {
  viewer: Cesium.Viewer;
  sites: LandingSite[];
  selectedSiteId: string | null;
  onSiteClick: (site: LandingSite) => void;
  disabled?: boolean;
}

const MARS_ELLIPSOID = new Cesium.Ellipsoid(3_396_190, 3_396_190, 3_376_200);

// ---------------------------------------------------------------------------
// Colour mapping
// ---------------------------------------------------------------------------

function agencyHex(agency: string): string {
  const a = agency.toUpperCase();
  if (a.includes('NASA')) return '#2563eb'; // blue
  if (a.includes('ESA')) return '#8b5cf6'; // purple
  if (a.includes('CNSA')) return '#ef4444'; // red
  if (a.includes('ROSCOSMOS') || a.includes('USSR') || a.includes('SOVIET'))
    return '#f97316'; // orange
  return '#94a3b8'; // gray
}

function statusHex(status: LandingSite['status']): string {
  switch (status) {
    case 'active':
      return '#22c55e'; // green
    case 'lost':
      return '#ef4444'; // red
    case 'ended':
    default:
      return '#cbd5e1'; // silver
  }
}

// ---------------------------------------------------------------------------
// Pre-cached Pin Billboard Generator
// ---------------------------------------------------------------------------

const pinCache = new Map<string, string>();

function getPinImage(agency: string, status: LandingSite['status'], isSelected: boolean): string {
  const cacheKey = `${agency}_${status}_${isSelected}`;
  const existing = pinCache.get(cacheKey);
  if (existing) return existing;

  const canvas = document.createElement('canvas');
  const size = isSelected ? 48 : 36;
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const cx = size / 2;
  const cy = size / 2;
  const r = (size / 2) - 4;

  const aColor = agencyHex(agency);
  const sColor = statusHex(status);

  // Outer glow if selected
  if (isSelected) {
    ctx.shadowColor = '#ffffff';
    ctx.shadowBlur = 12;
  }

  // Status outer ring
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fillStyle = sColor;
  ctx.fill();

  // White separator ring
  ctx.beginPath();
  ctx.arc(cx, cy, r - (isSelected ? 3 : 2), 0, Math.PI * 2);
  ctx.fillStyle = '#ffffff';
  ctx.fill();

  // Agency core circle
  ctx.beginPath();
  ctx.arc(cx, cy, r - (isSelected ? 5 : 4), 0, Math.PI * 2);
  ctx.fillStyle = aColor;
  ctx.fill();

  // Center white dot
  ctx.beginPath();
  ctx.arc(cx, cy, isSelected ? 3.5 : 2.5, 0, Math.PI * 2);
  ctx.fillStyle = '#ffffff';
  ctx.fill();

  const dataUrl = canvas.toDataURL('image/png');
  pinCache.set(cacheKey, dataUrl);
  return dataUrl;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export const LandingSitePins: React.FC<Props> = ({
  viewer,
  sites,
  selectedSiteId,
  onSiteClick,
  disabled = false,
}) => {
  const entitySiteMapRef = useRef<Map<string, LandingSite>>(new Map());
  const entityIdsRef = useRef<string[]>([]);
  const clickHandlerRef = useRef<Cesium.ScreenSpaceEventHandler | null>(null);

  // Build entities only when sites or selectedSiteId changes
  useEffect(() => {
    // Clean up previous entities
    entityIdsRef.current.forEach((id) => {
      const e = viewer.entities.getById(id);
      if (e) viewer.entities.remove(e);
    });
    entityIdsRef.current = [];
    entitySiteMapRef.current.clear();

    sites.forEach((site) => {
      const lon180 = marsLonToCesium(site.lon);
      const isSelected = site.id === selectedSiteId;
      const pinImage = getPinImage(site.agency, site.status, isSelected);

      const position = Cesium.Cartesian3.fromDegrees(
        lon180,
        site.lat,
        0,
        MARS_ELLIPSOID,
      );

      // Main Billboard + GPU-conditioned Label
      const entity = viewer.entities.add({
        id: `landing-site-${site.id}`,
        name: site.name,
        position,
        billboard: {
          image: pinImage,
          width: isSelected ? 40 : 28,
          height: isSelected ? 40 : 28,
          verticalOrigin: Cesium.VerticalOrigin.CENTER,
          horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
          heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
          disableDepthTestDistance: Number.POSITIVE_INFINITY,
          scaleByDistance: new Cesium.NearFarScalar(5e4, 1.25, 2e7, 0.45),
        },
        label: {
          text: site.name,
          font: isSelected ? 'bold 13px "Inter", sans-serif' : '500 11px "Inter", sans-serif',
          fillColor: isSelected ? Cesium.Color.fromCssColorString('#38bdf8') : Cesium.Color.WHITE,
          outlineColor: Cesium.Color.BLACK,
          outlineWidth: 3,
          style: Cesium.LabelStyle.FILL_AND_OUTLINE,
          verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
          pixelOffset: new Cesium.Cartesian2(0, isSelected ? -24 : -16),
          heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
          disableDepthTestDistance: Number.POSITIVE_INFINITY,
          // GPU evaluated progressive disclosure: only visible below 5,500 km
          distanceDisplayCondition: new Cesium.DistanceDisplayCondition(0, 5.5e6),
          translucencyByDistance: new Cesium.NearFarScalar(3e6, 1.0, 5.5e6, 0.0),
        },
      });

      entityIdsRef.current.push(`landing-site-${site.id}`);
      entitySiteMapRef.current.set(entity.id, site);

      // Uncertainty ellipse for approximate coordinates
      if (site.coordsApproximate) {
        const circleId = `landing-site-${site.id}-circle`;
        viewer.entities.add({
          id: circleId,
          position,
          ellipse: {
            semiMajorAxis: 50_000,
            semiMinorAxis: 50_000,
            material: Cesium.Color.YELLOW.withAlpha(0.12),
            outline: true,
            outlineColor: Cesium.Color.YELLOW.withAlpha(0.6),
            outlineWidth: 1.5,
            heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
          },
        });
        entityIdsRef.current.push(circleId);
      }

      // Selected site beacon leader line
      if (isSelected) {
        const lineId = `landing-site-${site.id}-leader`;
        const elevated = Cesium.Cartesian3.fromDegrees(
          lon180,
          site.lat,
          150_000,
          MARS_ELLIPSOID,
        );
        viewer.entities.add({
          id: lineId,
          polyline: {
            positions: [position, elevated],
            width: 2,
            material: new Cesium.PolylineGlowMaterialProperty({
              glowPower: 0.25,
              color: Cesium.Color.fromCssColorString('#38bdf8'),
            }),
            arcType: Cesium.ArcType.NONE,
          },
        });
        entityIdsRef.current.push(lineId);
      }
    });

    viewer.scene.requestRender();
  }, [viewer, sites, selectedSiteId]);

  // Click handler
  useEffect(() => {
    clickHandlerRef.current?.destroy();
    clickHandlerRef.current = null;

    if (disabled) return;

    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
    clickHandlerRef.current = handler;

    handler.setInputAction(
      (click: Cesium.ScreenSpaceEventHandler.PositionedEvent) => {
        const picked = viewer.scene.pick(click.position);
        if (picked?.id instanceof Cesium.Entity) {
          const site = entitySiteMapRef.current.get(picked.id.id);
          if (site) {
            onSiteClick(site);
          }
        }
      },
      Cesium.ScreenSpaceEventType.LEFT_CLICK,
    );

    return () => {
      handler.destroy();
      clickHandlerRef.current = null;
    };
  }, [viewer, onSiteClick, disabled]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      entityIdsRef.current.forEach((id) => {
        const e = viewer.entities.getById(id);
        if (e) viewer.entities.remove(e);
      });
      clickHandlerRef.current?.destroy();
    };
  }, [viewer]);

  return null;
};
