/**
 * MarsTerrain.ts
 *
 * Provides a Cesium terrain provider for the Mars MOLA elevation model.
 *
 * Strategy:
 *  1. If VITE_CESIUM_ION_TOKEN is set, attempt to load a Cesium Ion terrain
 *     asset that hosts MOLA data (asset ID configurable via VITE_ION_MARS_TERRAIN_ID,
 *     defaults to 2458954 — the Ion "Mars Terrain" sample asset).
 *  2. Fall back to EllipsoidTerrainProvider using the Mars reference ellipsoid
 *     when Ion is unavailable or the token is not configured.
 *
 * Note: True tiled MOLA terrain at full resolution requires a hosted
 * Cesium Terrain Service (quantized-mesh) endpoint. The Ion path is the
 * easiest production option; the ellipsoid fallback gives a smooth sphere
 * for development without an Ion subscription.
 */

import {
  CesiumTerrainProvider,
  EllipsoidTerrainProvider,
  Ellipsoid,
  IonResource,
  TerrainProvider,
} from 'cesium';

/** Mars 2000 reference ellipsoid (semi-major = 3 396 190 m, semi-minor = 3 376 200 m). */
const MARS_ELLIPSOID = new Ellipsoid(3_396_190, 3_396_190, 3_376_200);

/** Cesium Ion asset ID for Mars MOLA terrain (override with VITE_ION_MARS_TERRAIN_ID). */
const DEFAULT_ION_MARS_ASSET_ID = 2458954;

/**
 * Return a Cesium TerrainProvider suitable for a Mars globe.
 *
 * Always resolves — never rejects — so callers can unconditionally await it
 * and still get a usable (possibly flat) terrain provider.
 */
export async function createMarsTerrainProvider(): Promise<TerrainProvider> {
  const ionToken = (import.meta as any).env?.VITE_CESIUM_ION_TOKEN as string | undefined;

  if (ionToken) {
    const assetId = Number(
      ((import.meta as any).env?.VITE_ION_MARS_TERRAIN_ID as string | undefined) ??
        DEFAULT_ION_MARS_ASSET_ID,
    );

    try {
      const resource = await IonResource.fromAssetId(assetId, {
        accessToken: ionToken,
      });

      const terrain = await CesiumTerrainProvider.fromUrl(resource, {
        requestVertexNormals: true,
        requestWaterMask: false,
      });

      console.info(`[MarsTerrain] Loaded Ion MOLA terrain (asset ${assetId})`);
      return terrain;
    } catch (err) {
      console.warn(
        '[MarsTerrain] Ion terrain load failed — falling back to ellipsoid:',
        err,
      );
    }
  } else {
    console.info(
      '[MarsTerrain] No VITE_CESIUM_ION_TOKEN — using flat Mars ellipsoid terrain.',
    );
  }

  // Ellipsoid fallback -------------------------------------------------------
  return new EllipsoidTerrainProvider({ ellipsoid: MARS_ELLIPSOID });
}
