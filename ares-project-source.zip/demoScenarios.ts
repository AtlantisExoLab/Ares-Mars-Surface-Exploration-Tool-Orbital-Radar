/**
 * demoScenarios.ts
 * Preloaded Mission Planner demo scenarios for Mount Sharp and Jezero Delta.
 */

import type { DemoScenario } from '../types/MissionTypes';
import mountSharp from '../../public/data/demo-scenarios/mount-sharp-traverse.json';
import jezeroDelta from '../../public/data/demo-scenarios/jezero-delta-traverse.json';

export const DEMO_SCENARIOS: DemoScenario[] = [
  mountSharp as DemoScenario,
  jezeroDelta as DemoScenario,
];

export function getDemoScenarioById(id: string): DemoScenario | undefined {
  return DEMO_SCENARIOS.find((s) => s.id === id);
}
