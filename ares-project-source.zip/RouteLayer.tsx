/**
 * RouteLayer.tsx
 *
 * React component that renders Mission Planner routes on the Cesium globe.
 *
 * Features:
 *  - Orange/Mars-coloured polyline (3 px, ground-clamped)
 *  - Waypoint billboards (numbered W1, W2, …) with labels
 *  - Globe-click handler for adding waypoints when isAddingWaypoints=true
 *  - Full entity + handler cleanup on unmount
 */

import React, { useEffect, useRef } from 'react';
import * as Cesium from 'cesium';
import { marsLonToCesium } from './CoordinateUtils';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface Waypoint {
  lat: number;
  lon: number; // 0–360 east-positive
  label: string;
}

interface Props {
  viewer: Cesium.Viewer;
  waypoints: Waypoint[];
  onWaypointClick: (index: number) => void;
  onGlobeClick: (lat: number, lon: number) => void;
  isAddingWaypoints: boolean;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const MARS_ELLIPSOID = new Cesium.Ellipsoid(3_396_190, 3_396_190, 3_376_200);

/** Route line colour */
const ROUTE_COLOR = new Cesium.Color(1.0, 0.45, 0.1, 0.9); // Mars orange

/** Waypoint billboard colour */
const WP_FILL_COLOR = new Cesium.Color(1.0, 0.45, 0.1, 1.0);

/** Label text colour */
const LABEL_COLOR = Cesium.Color.WHITE;

// ---------------------------------------------------------------------------
// Billboard canvas helper
// ---------------------------------------------------------------------------

function makeWaypointCanvas(label: string): HTMLCanvasElement {
  const SIZE = 28;
  const canvas = document.createElement('canvas');
  canvas.width = SIZE;
  canvas.height = SIZE;
  const ctx = canvas.getContext('2d')!;

  const cx = SIZE / 2;
  const cy = SIZE / 2;

  // Background circle
  ctx.beginPath();
  ctx.arc(cx, cy, SIZE / 2 - 1, 0, Math.PI * 2);
  ctx.fillStyle = `rgba(${Math.round(WP_FILL_COLOR.red * 255)},${Math.round(WP_FILL_COLOR.green * 255)},${Math.round(WP_FILL_COLOR.blue * 255)},${WP_FILL_COLOR.alpha})`;
  ctx.fill();

  // White border
  ctx.strokeStyle = 'rgba(255,255,255,0.9)';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Label text
  ctx.fillStyle = '#fff';
  ctx.font = `bold ${label.length > 2 ? 8 : 10}px sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, cx, cy + 0.5);

  return canvas;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export const RouteLayer: React.FC<Props> = ({
  viewer,
  waypoints,
  onWaypointClick,
  onGlobeClick,
  isAddingWaypoints,
}) => {
  const entityIdsRef = useRef<string[]>([]);
  /** entity id → waypoint index for click detection */
  const entityIndexMapRef = useRef<Map<string, number>>(new Map());
  const clickHandlerRef = useRef<Cesium.ScreenSpaceEventHandler | null>(null);

  // -------------------------------------------------------------------------
  // Rebuild entities whenever waypoints change
  // -------------------------------------------------------------------------
  useEffect(() => {
    // Remove old entities
    entityIdsRef.current.forEach((id) => {
      const e = viewer.entities.getById(id);
      if (e) viewer.entities.remove(e);
    });
    entityIdsRef.current = [];
    entityIndexMapRef.current.clear();

    if (waypoints.length === 0) {
      viewer.scene.requestRender();
      return;
    }

    // Build Cartesian positions from waypoints
    const positions = waypoints.map((wp) =>
      Cesium.Cartesian3.fromDegrees(
        marsLonToCesium(wp.lon),
        wp.lat,
        0,
        MARS_ELLIPSOID,
      ),
    );

    // ----- Polyline route -----
    if (positions.length >= 2) {
      const routeId = 'route-polyline';
      viewer.entities.add({
        id: routeId,
        polyline: {
          positions,
          width: 3,
          material: new Cesium.PolylineGlowMaterialProperty({
            glowPower: 0.15,
            color: ROUTE_COLOR,
          }),
          clampToGround: true,
          arcType: Cesium.ArcType.GEODESIC,
        },
      });
      entityIdsRef.current.push(routeId);
    }

    // ----- Waypoint markers -----
    waypoints.forEach((wp, index) => {
      const markerLabel = `W${index + 1}`;
      const entityId = `route-wp-${index}`;
      const canvas = makeWaypointCanvas(markerLabel);
      const position = positions[index];

      viewer.entities.add({
        id: entityId,
        name: wp.label || markerLabel,
        position,
        billboard: {
          image: canvas.toDataURL(),
          width: 28,
          height: 28,
          verticalOrigin: Cesium.VerticalOrigin.CENTER,
          horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
          heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
          disableDepthTestDistance: Number.POSITIVE_INFINITY,
          scaleByDistance: new Cesium.NearFarScalar(1e4, 1.3, 2e6, 0.7),
        },
        label: {
          text: wp.label || markerLabel,
          font: '11px "Inter", sans-serif',
          fillColor: LABEL_COLOR,
          outlineColor: Cesium.Color.BLACK,
          outlineWidth: 2,
          style: Cesium.LabelStyle.FILL_AND_OUTLINE,
          verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
          pixelOffset: new Cesium.Cartesian2(0, -16),
          heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
          disableDepthTestDistance: Number.POSITIVE_INFINITY,
          scaleByDistance: new Cesium.NearFarScalar(1e4, 1.0, 1e6, 0.6),
        },
      });

      entityIdsRef.current.push(entityId);
      entityIndexMapRef.current.set(entityId, index);
    });

    viewer.scene.requestRender();
  }, [viewer, waypoints]);

  // -------------------------------------------------------------------------
  // Click handler — waypoint select + globe click for new waypoints
  // -------------------------------------------------------------------------
  useEffect(() => {
    clickHandlerRef.current?.destroy();

    const handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);
    clickHandlerRef.current = handler;

    handler.setInputAction(
      (event: Cesium.ScreenSpaceEventHandler.PositionedEvent) => {
        // 1. Check if we hit a waypoint entity
        const picked = viewer.scene.pick(event.position);
        if (picked?.id instanceof Cesium.Entity) {
          const idx = entityIndexMapRef.current.get(picked.id.id);
          if (idx !== undefined) {
            onWaypointClick(idx);
            return;
          }
        }

        // 2. If in waypoint-adding mode, convert screen position to lat/lon
        if (isAddingWaypoints) {
          const cartesian = viewer.scene.pickPosition(event.position);
          if (cartesian) {
            const carto = Cesium.Cartographic.fromCartesian(
              cartesian,
              MARS_ELLIPSOID,
            );
            const lat = Cesium.Math.toDegrees(carto.latitude);
            const lon360 =
              ((Cesium.Math.toDegrees(carto.longitude) % 360) + 360) % 360;
            onGlobeClick(lat, lon360);
          }
        }
      },
      Cesium.ScreenSpaceEventType.LEFT_CLICK,
    );

    return () => {
      handler.destroy();
      clickHandlerRef.current = null;
    };
  }, [viewer, isAddingWaypoints, onWaypointClick, onGlobeClick]);

  // -------------------------------------------------------------------------
  // Cleanup on unmount
  // -------------------------------------------------------------------------
  useEffect(() => {
    return () => {
      entityIdsRef.current.forEach((id) => {
        const e = viewer.entities.getById(id);
        if (e) viewer.entities.remove(e);
      });
      clickHandlerRef.current?.destroy();
    };
  }, [viewer]);

  // Renders nothing into the React tree — drives Cesium directly
  return null;
};

export default RouteLayer;
