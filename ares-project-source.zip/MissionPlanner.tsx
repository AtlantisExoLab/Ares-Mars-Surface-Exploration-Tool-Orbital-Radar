/**
 * MissionPlanner.tsx
 * Astronaut Mission Planner main shell: guided 5-step workflow answering the NASA brief.
 */

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGlobeStore } from '../../store/globeStore';
import { usePlannerStore } from '../../store/plannerStore';
import { Step1Location } from './steps/Step1Location';
import { Step2Objective } from './steps/Step2Objective';
import { Step3Layers } from './steps/Step3Layers';
import { Step4Route } from './steps/Step4Route';
import { Step5Safety } from './steps/Step5Safety';
import { HelmHUD } from './HelmHUD';

export const MissionPlanner: React.FC = () => {
  const isOpen = usePlannerStore((s) => s.isOpen);
  const closePlanner = usePlannerStore((s) => s.closePlanner);
  const currentStep = usePlannerStore((s) => s.currentStep);
  const setStep = usePlannerStore((s) => s.setStep);
  const displayMode = usePlannerStore((s) => s.displayMode);
  const setDisplayMode = usePlannerStore((s) => s.setDisplayMode);
  const setActivePanel = useGlobeStore((s) => s.setActivePanel);

  if (!isOpen) return null;

  // If Astronaut Helmet HUD mode is activated
  if (displayMode === 'helmet-hud') {
    return <HelmHUD onExit={() => setDisplayMode('tablet')} />;
  }

  const stepTitles = [
    '1. Location',
    '2. Objective',
    '3. Data Layers',
    '4. Route',
    '5. Safety',
  ];

  const handleClose = () => {
    closePlanner();
    setActivePanel(null);
  };

  return (
    <motion.div
      initial={{ x: 40, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 40, opacity: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="fixed top-16 right-4 md:right-16 w-88 md:w-[480px] bottom-16 bg-[#0a0d14] border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col z-30 overflow-hidden pointer-events-auto"
    >
      {/* Header */}
      <div className="p-5 border-b border-slate-700/80 bg-[#0f1420] flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="w-2.5 h-2.5 rounded-full bg-mars-500 animate-pulse" />
          <div>
            <h2 className="text-white font-display font-semibold text-base tracking-wide">
              Astronaut Mission Planner
            </h2>
            <div className="text-[11px] text-white/50">
              NASA Surface Mobility & Navigation System
            </div>
          </div>
        </div>

        <button
          onClick={handleClose}
          className="text-white/40 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          title="Close Mission Planner"
        >
          ✕
        </button>
      </div>

      {/* 5-Step Progress Indicators */}
      <div className="flex items-center justify-between px-6 py-3 border-b border-white/5 bg-space-950/40">
        {[1, 2, 3, 4, 5].map((s) => {
          const stepNum = s as 1 | 2 | 3 | 4 | 5;
          const isCurrent = currentStep === stepNum;
          const isPast = currentStep > stepNum;

          return (
            <button
              key={s}
              onClick={() => setStep(stepNum)}
              className="flex flex-col items-center gap-1 group focus:outline-none"
            >
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-mono font-bold transition-all ${
                  isCurrent
                    ? 'bg-mars-500 text-white shadow-[0_0_12px_rgba(232,82,26,0.6)]'
                    : isPast
                    ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/40'
                    : 'bg-white/10 text-white/40 group-hover:bg-white/20'
                }`}
              >
                {isPast ? '✓' : s}
              </div>
              <span
                className={`text-[9px] uppercase tracking-wider font-mono hidden sm:inline ${
                  isCurrent ? 'text-mars-400 font-semibold' : 'text-white/40'
                }`}
              >
                {stepTitles[s - 1].split('. ')[1]}
              </span>
            </button>
          );
        })}
      </div>

      {/* Step Body */}
      <div className="flex-1 overflow-y-auto p-5">
        {currentStep === 1 && <Step1Location />}
        {currentStep === 2 && <Step2Objective />}
        {currentStep === 3 && <Step3Layers />}
        {currentStep === 4 && <Step4Route />}
        {currentStep === 5 && <Step5Safety />}
      </div>

      {/* Navigation Footer */}
      <div className="p-4 border-t border-white/10 bg-space-950/80 flex items-center justify-between">
        <button
          onClick={() => {
            if (currentStep > 1) setStep((currentStep - 1) as 1 | 2 | 3 | 4 | 5);
          }}
          disabled={currentStep === 1}
          className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/15 disabled:opacity-20 text-white font-medium text-xs transition-colors"
        >
          ← Back
        </button>

        <div className="text-[11px] font-mono text-white/40">
          Step {currentStep} of 5
        </div>

        <button
          onClick={() => {
            if (currentStep < 5) setStep((currentStep + 1) as 1 | 2 | 3 | 4 | 5);
          }}
          disabled={currentStep === 5}
          className="px-5 py-2 rounded-xl bg-gradient-to-r from-mars-600 to-mars-500 hover:from-mars-500 hover:to-mars-400 disabled:opacity-40 text-white font-medium text-xs shadow-md transition-all"
        >
          {currentStep === 4 ? 'Review Safety →' : 'Next Step →'}
        </button>
      </div>
    </motion.div>
  );
};
