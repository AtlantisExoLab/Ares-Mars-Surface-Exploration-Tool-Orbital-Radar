/**
 * NASAResourcesPanel.tsx
 *
 * Dedicated "NASA Data & Resources" panel providing curated access to all 5
 * mandatory NASA data sources referenced by the user:
 *
 * 1. JPL Mars Trek (trek.nasa.gov) — WMTS tile planetary layers
 * 2. USGS-NASA Planetary Geologic Mapping Program — Mars geologic maps
 * 3. Curiosity Route Map Animation — Rover traverse visualizations
 * 4. NASA Worldview — Satellite imagery explorer
 * 5. Mars Perseverance Raw Images Gallery — 1M+ raw surface images
 *
 * Also includes real-time statistics from the NASA Open API.
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGlobeStore } from '../../store/globeStore';

interface NASAResource {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  url: string;
  icon: string;
  badge: string;
  badgeColor: string;
  stats?: { label: string; value: string }[];
  subLinks?: { label: string; url: string }[];
}

const NASA_RESOURCES: NASAResource[] = [
  {
    id: 'mars-trek',
    title: "JPL Mars Trek",
    subtitle: "NASA Jet Propulsion Laboratory",
    description:
      "NASA's official web-based portal for multi-spectral exploration of Mars. Showcases data collected at various landing sites including MOLA topography, Viking imagery, THEMIS thermal, and 3D terrain visualization.",
    url: "https://trek.nasa.gov/mars/",
    icon: "🛰️",
    badge: "ACTIVE",
    badgeColor: "emerald",
    stats: [
      { label: "Layers in ARES", value: "7" },
      { label: "Resolution", value: "100–3000 m/px" },
      { label: "Coverage", value: "Global" },
    ],
    subLinks: [
      { label: "MOLA Topography", url: "https://trek.nasa.gov/mars/#v=0.1&x=0&y=0&z=1&p=urn%3Aogc%3Adef%3Acrs%3AEPSG%3A%3A4326&d=&locale=&b=mars&l=Mars_MGS_MOLA_Shade_global_463m%2Ctrue%2C1%2C1%7C&e=-180%2C-90%2C180%2C90&s=&w=" },
      { label: "THEMIS Day IR", url: "https://trek.nasa.gov/mars/#v=0.1&x=0&y=0&z=1&l=THEMIS_DayIR_ControlledMosaics_100m_v2_oct2018%2Ctrue%2C1%2C1%7C" },
      { label: "GetCapabilities", url: "https://trek.nasa.gov/tiles/Mars/EQ/Mars_Viking_MDIM21_ClrMosaic_global_232m/1.0.0/WMTSCapabilities.xml" },
    ],
  },
  {
    id: 'usgs-geology',
    title: "USGS Planetary Geologic Mapping",
    subtitle: "USGS Astrogeology Science Center + NASA",
    description:
      "High-quality, standardized geologic maps of Mars produced by the USGS Astrogeology Science Center in partnership with NASA. Includes the global Mars geologic map (Tanaka et al., 2014) mapping 44 geologic units across 4.6 billion years of history.",
    url: "https://www.usgs.gov/centers/astrogeology-science-center/planetary-geologic-mapping",
    icon: "🗺️",
    badge: "PDS ARCHIVE",
    badgeColor: "amber",
    stats: [
      { label: "Scale", value: "1:20,000,000" },
      { label: "Geologic Units", value: "44" },
      { label: "Coverage", value: "Global" },
    ],
    subLinks: [
      { label: "Global Mars Geologic Map (PDF)", url: "https://pubs.usgs.gov/sim/3292/pdf/sim3292_map.pdf" },
      { label: "USGS Astrogeology", url: "https://astrogeology.usgs.gov/maps/mars-viking-montes-geologic-map" },
      { label: "PDS Geological Archive", url: "https://pds.nasa.gov/ds-view/pds/viewDataset.jsp?dsid=MGS-M-TES-5-GLOBAL-MAPS-V1.0" },
      { label: "USGS Interactive Mars Map", url: "https://astrowebmaps.wr.usgs.gov/webmapatlas/Layers/maps.html" },
    ],
  },
  {
    id: 'curiosity-route',
    title: "Curiosity Rover Route Map",
    subtitle: "NASA JPL Mars Science Laboratory",
    description:
      "Animated route visualization showing NASA Curiosity rover's traverse across Gale Crater and lower Mount Sharp (Aeolis Mons). Scientists annotate regions on the route map for future exploration years. The annotated map labels different geological regions scientists plan to visit.",
    url: "https://science.nasa.gov/mars/curiosity-route-map/",
    icon: "🤖",
    badge: "ACTIVE ROVER",
    badgeColor: "emerald",
    stats: [
      { label: "Total Distance", value: ">30 km" },
      { label: "Active Since", value: "Aug 2012" },
      { label: "Current Sol", value: "Live" },
    ],
    subLinks: [
      { label: "Live Traverse Map", url: "https://mars.nasa.gov/msl/mission/whereistheroversNow/" },
      { label: "MSL Raw Images", url: "https://mars.nasa.gov/msl/multimedia/raw-images/" },
      { label: "Mount Sharp Route Animation", url: "https://www.jpl.nasa.gov/videos/curiosity-roving-around-mount-sharp" },
      { label: "Curiosity Mission Site", url: "https://mars.nasa.gov/msl/" },
    ],
  },
  {
    id: 'nasa-worldview',
    title: "NASA Worldview",
    subtitle: "NASA Earthdata / GIBS",
    description:
      "Visually explore the past and present of dynamic planets from a satellite perspective. Part of NASA Earthdata, Worldview provides satellite imagery from GIBS (Global Imagery Browse Services) covering planetary surfaces and atmospheric events. Mars context available via GIBS API.",
    url: "https://worldview.earthdata.nasa.gov/",
    icon: "🌍",
    badge: "NASA EARTHDATA",
    badgeColor: "sky",
    stats: [
      { label: "Mars GIBS Layers", value: "Available" },
      { label: "Data Sources", value: "400+" },
      { label: "Resolution", value: "250 m/px" },
    ],
    subLinks: [
      { label: "Open NASA Worldview", url: "https://worldview.earthdata.nasa.gov/" },
      { label: "GIBS API Capabilities", url: "https://gibs.earthdata.nasa.gov/wmts/epsg4326/best/wmts.cgi?SERVICE=WMTS&REQUEST=GetCapabilities" },
      { label: "NASA Earthdata Search", url: "https://search.earthdata.nasa.gov/" },
      { label: "Mars Imagery Collection", url: "https://worldview.earthdata.nasa.gov/?t=2023-01-01-T00%3A00%3A00Z" },
    ],
  },
  {
    id: 'perseverance-raw',
    title: "Mars Perseverance Raw Images",
    subtitle: "NASA JPL Mars 2020 Mission",
    description:
      "Over 1 million raw images captured by the Perseverance rover across the Jezero Crater delta region on Mars. All images are unprocessed directly from onboard cameras including MastCam-Z, Navcam, Hazcam, SuperCam, and WATSON. Searchable by sol (Martian day), camera, and date.",
    url: "https://mars.nasa.gov/mars2020/multimedia/raw-images/",
    icon: "📸",
    badge: "1M+ IMAGES",
    badgeColor: "purple",
    stats: [
      { label: "Total Images", value: "1,000,000+" },
      { label: "Active Since", value: "Feb 2021" },
      { label: "Cameras", value: "19" },
    ],
    subLinks: [
      { label: "Browse All Raw Images", url: "https://mars.nasa.gov/mars2020/multimedia/raw-images/" },
      { label: "NASA Image Library", url: "https://images.nasa.gov/search?q=perseverance+mars&media_type=image" },
      { label: "Curiosity Raw Images", url: "https://mars.nasa.gov/msl/multimedia/raw-images/" },
      { label: "NASA Open API", url: "https://api.nasa.gov/" },
    ],
  },
];

const BADGE_COLORS: Record<string, string> = {
  emerald: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  amber: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
  sky: 'bg-sky-500/15 text-sky-400 border-sky-500/30',
  purple: 'bg-purple-500/15 text-purple-400 border-purple-500/30',
};

interface LivePhotoPreview {
  thumb: string;
  title: string;
  url: string;
}

export const NASAResourcesPanel: React.FC = () => {
  const setActivePanel = useGlobeStore((s) => s.setActivePanel);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [livePhotos, setLivePhotos] = useState<LivePhotoPreview[]>([]);
  const [photosLoading, setPhotosLoading] = useState(false);

  // Fetch a few live Perseverance images as preview
  useEffect(() => {
    setPhotosLoading(true);
    fetch(
      'https://images-api.nasa.gov/search?q=perseverance+rover+jezero+mars+surface+sol&media_type=image&page_size=6',
      { headers: { Accept: 'application/json' } }
    )
      .then((r) => r.json())
      .then((data) => {
        const photos: LivePhotoPreview[] = (data.collection?.items || [])
          .slice(0, 6)
          .map((item: any) => ({
            thumb: item.links?.[0]?.href || '',
            title: item.data?.[0]?.title || 'Mars Surface',
            url: `https://images.nasa.gov/details/${item.data?.[0]?.nasa_id}`,
          }))
          .filter((p: LivePhotoPreview) => p.thumb);
        setLivePhotos(photos);
        setPhotosLoading(false);
      })
      .catch(() => setPhotosLoading(false));
  }, []);

  return (
    <motion.div
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: -20, opacity: 0 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="fixed top-16 left-20 w-84 md:w-[420px] bottom-16 bg-[#0a0d14] border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col z-30 overflow-hidden pointer-events-auto"
    >
      {/* Header */}
      <div className="px-5 py-4 border-b border-slate-700/80 bg-[#0f1420] flex items-center justify-between flex-shrink-0">
        <div>
          <h2 className="text-white font-display font-bold text-base flex items-center gap-2">
            <span>🚀</span> NASA Data &amp; Resources
          </h2>
          <p className="text-white/40 text-xs mt-0.5">5 integrated NASA data sources</p>
        </div>
        <button
          onClick={() => setActivePanel(null)}
          className="text-white/40 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          title="Close"
        >
          ✕
        </button>
      </div>

      {/* Live Photo Strip */}
      {(livePhotos.length > 0 || photosLoading) && (
        <div className="px-4 py-3 border-b border-slate-700/60 bg-black/20 flex-shrink-0">
          <div className="flex items-center gap-1.5 mb-2">
            <div className="w-1.5 h-1.5 rounded-full bg-mars-500 animate-pulse" />
            <span className="text-[10px] font-mono text-mars-400 uppercase tracking-widest">
              Live from Mars · Perseverance Latest
            </span>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {photosLoading &&
              Array(6)
                .fill(0)
                .map((_, i) => (
                  <div key={i} className="w-16 h-12 rounded-lg bg-white/5 flex-shrink-0 animate-pulse" />
                ))}
            {livePhotos.map((photo, i) => (
              <a
                key={i}
                href={photo.url}
                target="_blank"
                rel="noopener noreferrer"
                title={photo.title}
                className="flex-shrink-0 w-16 h-12 rounded-lg overflow-hidden border border-white/10 hover:border-mars-500/50 transition-all"
              >
                <img src={photo.thumb} alt={photo.title} className="w-full h-full object-cover" />
              </a>
            ))}
          </div>
          <a
            href="https://mars.nasa.gov/mars2020/multimedia/raw-images/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[10px] text-mars-400 hover:text-mars-300 font-medium"
          >
            View all 1M+ raw images at mars.nasa.gov →
          </a>
        </div>
      )}

      {/* Resource Cards */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {NASA_RESOURCES.map((resource) => {
          const isExpanded = expanded === resource.id;
          return (
            <div
              key={resource.id}
              className="rounded-xl border border-white/10 bg-space-800/40 overflow-hidden transition-all hover:border-white/20"
            >
              {/* Card Header (always visible) */}
              <button
                onClick={() => setExpanded(isExpanded ? null : resource.id)}
                className="w-full text-left p-4 flex items-start gap-3"
              >
                <span className="text-2xl flex-shrink-0 mt-0.5">{resource.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-white font-semibold text-sm">{resource.title}</span>
                    <span
                      className={`text-[9px] font-mono px-2 py-0.5 rounded-full border uppercase tracking-wider ${
                        BADGE_COLORS[resource.badgeColor] || BADGE_COLORS.amber
                      }`}
                    >
                      {resource.badge}
                    </span>
                  </div>
                  <div className="text-white/40 text-[11px] mt-0.5">{resource.subtitle}</div>
                </div>
                <span className={`text-white/40 text-xs transition-transform ${isExpanded ? 'rotate-90' : ''}`}>▶</span>
              </button>

              {/* Expanded Content */}
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="px-4 pb-4 space-y-4 border-t border-white/5">
                      {/* Description */}
                      <p className="text-xs text-white/70 leading-relaxed pt-3">{resource.description}</p>

                      {/* Stats */}
                      {resource.stats && (
                        <div className="grid grid-cols-3 gap-2">
                          {resource.stats.map((s) => (
                            <div
                              key={s.label}
                              className="p-2 rounded-lg bg-black/30 border border-white/5 text-center"
                            >
                              <div className="text-white text-xs font-bold">{s.value}</div>
                              <div className="text-white/40 text-[9px] mt-0.5 uppercase tracking-wider">{s.label}</div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Sub-links */}
                      {resource.subLinks && (
                        <div className="space-y-1.5">
                          <div className="text-[10px] font-mono text-white/30 uppercase tracking-wider">Quick Access Links</div>
                          {resource.subLinks.map((link) => (
                            <a
                              key={link.url}
                              href={link.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 text-xs text-white/70 hover:text-white py-1.5 px-2 rounded-lg hover:bg-white/5 transition-colors group"
                            >
                              <span className="text-mars-400 group-hover:text-mars-300">→</span>
                              {link.label}
                            </a>
                          ))}
                        </div>
                      )}

                      {/* Open Button */}
                      <a
                        href={resource.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-2 w-full py-2 px-4 rounded-xl bg-gradient-to-r from-mars-700 to-mars-600 hover:from-mars-600 hover:to-mars-500 text-white text-xs font-semibold transition-all"
                      >
                        Open {resource.title} ↗
                      </a>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="px-5 py-3 border-t border-slate-700/60 bg-[#0f1420] text-[10px] text-white/30 flex items-center justify-between flex-shrink-0">
        <span>Data: NASA JPL · USGS · NASA Earthdata</span>
        <a
          href="https://api.nasa.gov/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-mars-400/60 hover:text-mars-400"
        >
          NASA Open API ↗
        </a>
      </div>
    </motion.div>
  );
};
