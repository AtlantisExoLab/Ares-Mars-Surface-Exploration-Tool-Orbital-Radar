/**
 * orbitalBodies.ts
 *
 * Real-time Martian satellite and moon orbital mechanics.
 * Computes 3D Keplerian orbital paths, instantaneous position coordinates,
 * velocities, and altitudes above the Mars reference ellipsoid.
 *
 * Modeled after Orbital Radar (orbitalradar.com/mars).
 */

import * as Cesium from 'cesium';

// Mars standard gravitational parameter mu = GM (m^3/s^2)
const MARS_GM = 4.282837e13;

// Mars mean equatorial radius in metres
export const MARS_RADIUS_M = 3_396_190;

export interface OrbitalBody {
  id: string;
  name: string;
  type: 'moon' | 'orbiter';
  agency: string;
  country: string;
  agencyBadge: string;
  semiMajorAxisM: number; // a in metres
  eccentricity: number;   // e
  inclinationDeg: number; // i in degrees
  raanDeg: number;        // Right Ascension of Ascending Node (Omega)
  argPeriapsisDeg: number;// Argument of Periapsis (omega)
  meanAnomaly0Deg: number;// Mean Anomaly at epoch (M0)
  periodSeconds: number;  // Orbital period (s)
  color: string;          // Hex accent colour for trajectory line
  dimensionsKm?: string;  // For moons (e.g. "26 × 22 × 18 km")
  launchYear?: string;
  missionType?: string;
  objectives: string;
}

export const ORBITAL_BODIES: OrbitalBody[] = [
  // -------------------------------------------------------------------------
  // Martian Moons
  // -------------------------------------------------------------------------
  {
    id: 'phobos',
    name: 'Phobos',
    type: 'moon',
    agency: 'Natural Satellite',
    country: 'Mars System',
    agencyBadge: '🌕',
    semiMajorAxisM: 9_376_000, // ~9 376 km from Mars center
    eccentricity: 0.0151,
    inclinationDeg: 1.093,
    raanDeg: 45.2,
    argPeriapsisDeg: 120.4,
    meanAnomaly0Deg: 18.0,
    periodSeconds: 27_554, // 7h 39m 14s (faster than Mars rotates!)
    color: '#e2e8f0', // bright silver/white
    dimensionsKm: '26.8 × 22.4 × 18.4 km',
    objectives: 'Innermost and largest moon of Mars. Orbits closer to its primary than any other planetary moon in the solar system, destined to form a ring system in 30–50 million years.',
  },
  {
    id: 'deimos',
    name: 'Deimos',
    type: 'moon',
    agency: 'Natural Satellite',
    country: 'Mars System',
    agencyBadge: '🌖',
    semiMajorAxisM: 23_463_200, // ~23 463 km
    eccentricity: 0.0002,
    inclinationDeg: 0.93,
    raanDeg: 165.8,
    argPeriapsisDeg: 72.1,
    meanAnomaly0Deg: 280.0,
    periodSeconds: 109_075, // 30h 17m 55s
    color: '#fde047', // soft gold
    dimensionsKm: '15.0 × 12.2 × 10.4 km',
    objectives: 'Outermost Martian moon. Smooth mantle of regolith obscuring impact craters, tidally locked with a synchronous period longer than a Martian sol.',
  },

  // -------------------------------------------------------------------------
  // Active Artificial Spacecraft
  // -------------------------------------------------------------------------
  {
    id: 'mro',
    name: 'Mars Reconnaissance Orbiter (MRO)',
    type: 'orbiter',
    agency: 'NASA',
    country: 'United States',
    agencyBadge: '🇺🇸',
    semiMajorAxisM: 3_684_000, // ~288 km altitude
    eccentricity: 0.008,
    inclinationDeg: 92.8, // Sun-synchronous retrograde polar
    raanDeg: 35.0,
    argPeriapsisDeg: 270.0,
    meanAnomaly0Deg: 90.0,
    periodSeconds: 6_720, // 112 minutes
    color: '#38bdf8', // NASA sky blue
    launchYear: '2005',
    missionType: 'High-Resolution Remote Sensing & Primary Telecom Relay',
    objectives: 'Carries the 0.3 m/px HiRISE camera, CTX context imager, and CRISM spectrometer. Primary high-bandwidth telecommunications relay for Perseverance and Curiosity.',
  },
  {
    id: 'tgo',
    name: 'ExoMars Trace Gas Orbiter (TGO)',
    type: 'orbiter',
    agency: 'ESA / Roscosmos',
    country: 'Europe',
    agencyBadge: '🇪🇺',
    semiMajorAxisM: 3_796_000, // ~400 km circular science orbit
    eccentricity: 0.001,
    inclinationDeg: 74.0,
    raanDeg: 120.0,
    argPeriapsisDeg: 45.0,
    meanAnomaly0Deg: 180.0,
    periodSeconds: 7_200, // 2 hours
    color: '#a855f7', // ESA purple
    launchYear: '2016',
    missionType: 'Atmospheric Chemistry & Rover Relay',
    objectives: 'Detects atmospheric methane, water vapour, and trace noble gases with NOMAD and ACS spectrometers. Serves as major UHF relay hub for surface landers.',
  },
  {
    id: 'odyssey',
    name: '2001 Mars Odyssey',
    type: 'orbiter',
    agency: 'NASA',
    country: 'United States',
    agencyBadge: '🇺🇸',
    semiMajorAxisM: 3_796_000, // ~400 km sun-synchronous
    eccentricity: 0.009,
    inclinationDeg: 93.1,
    raanDeg: 215.0,
    argPeriapsisDeg: 90.0,
    meanAnomaly0Deg: 40.0,
    periodSeconds: 7_080, // 118 minutes
    color: '#60a5fa', // blue
    launchYear: '2001',
    missionType: 'Thermal Infrared Mapping & Surface Mineralogy',
    objectives: 'Longest continually surviving active spacecraft orbiting a planet other than Earth. Carries THEMIS 9-band infrared imager and GRS gamma-ray spectrometer.',
  },
  {
    id: 'mex',
    name: 'Mars Express',
    type: 'orbiter',
    agency: 'ESA',
    country: 'Europe',
    agencyBadge: '🇪🇺',
    semiMajorAxisM: 8_600_000, // ~300 x 10,100 km elliptical
    eccentricity: 0.58,
    inclinationDeg: 86.3,
    raanDeg: 290.0,
    argPeriapsisDeg: 330.0,
    meanAnomaly0Deg: 12.0,
    periodSeconds: 27_000, // 7.5 hours
    color: '#c084fc', // purple
    launchYear: '2003',
    missionType: 'High-Resolution Stereo Colour Mapping & Subsurface Radar',
    objectives: 'Carries the HRSC stereo camera responsible for global 3D hillshading, and MARSIS radar which detected subsurface dielectric anomalies beneath the south polar cap.',
  },
  {
    id: 'hope',
    name: 'Hope Probe (Emirates Mars Mission)',
    type: 'orbiter',
    agency: 'UAE Space Agency / MBRSC',
    country: 'United Arab Emirates',
    agencyBadge: '🇦🇪',
    semiMajorAxisM: 34_900_000, // 20,000 x 43,000 km high-altitude elliptic
    eccentricity: 0.32,
    inclinationDeg: 25.0,
    raanDeg: 180.0,
    argPeriapsisDeg: 15.0,
    meanAnomaly0Deg: 220.0,
    periodSeconds: 198_000, // 55 hours
    color: '#2dd4bf', // UAE teal
    launchYear: '2020',
    missionType: 'Global Atmospheric Dynamics & Weather System Tracker',
    objectives: 'Unique high-altitude 55-hour orbit capturing the first complete diurnal cycle portraits of weather, dust storms, and atmospheric escape from Mars.',
  },
  {
    id: 'tianwen1',
    name: 'Tianwen-1 Orbiter',
    type: 'orbiter',
    agency: 'CNSA',
    country: 'China',
    agencyBadge: '🇨🇳',
    semiMajorAxisM: 9_500_000, // 265 x 12,000 km polar
    eccentricity: 0.61,
    inclinationDeg: 86.9,
    raanDeg: 60.0,
    argPeriapsisDeg: 180.0,
    meanAnomaly0Deg: 140.0,
    periodSeconds: 29_520, // 8.2 hours
    color: '#f87171', // red
    launchYear: '2020',
    missionType: 'Global Geomorphology & Zhurong Surface Relay',
    objectives: 'High-resolution stereo mapping, sub-surface radar probing, and primary communications relay for the Zhurong rover in Utopia Planitia.',
  },
  {
    id: 'maven',
    name: 'MAVEN',
    type: 'orbiter',
    agency: 'NASA',
    country: 'United States',
    agencyBadge: '🇺🇸',
    semiMajorAxisM: 6_570_000, // 150 x 6,200 km
    eccentricity: 0.46,
    inclinationDeg: 75.0,
    raanDeg: 10.0,
    argPeriapsisDeg: 210.0,
    meanAnomaly0Deg: 310.0,
    periodSeconds: 16_200, // 4.5 hours
    color: '#fb923c', // orange
    launchYear: '2013',
    missionType: 'Upper Atmosphere & Solar Wind Escape Dynamics',
    objectives: 'Investigates how the solar wind stripped Mars of its ancient dense atmosphere and surface water over billions of years.',
  },
];

// ---------------------------------------------------------------------------
// Keplerian Orbit Physics
// ---------------------------------------------------------------------------

function toRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

/**
 * Solves Kepler's equation M = E - e*sin(E) for eccentric anomaly E.
 */
function solveKepler(meanAnomalyRad: number, eccentricity: number): number {
  let E = meanAnomalyRad;
  for (let iter = 0; iter < 12; iter++) {
    const delta = (E - eccentricity * Math.sin(E) - meanAnomalyRad) / (1 - eccentricity * Math.cos(E));
    E -= delta;
    if (Math.abs(delta) < 1e-7) break;
  }
  return E;
}

/**
 * Computes the 3D Cartesian coordinates of an orbital point given True Anomaly nu.
 */
function getPointInOrbit(body: OrbitalBody, nuRad: number): Cesium.Cartesian3 {
  const a = body.semiMajorAxisM;
  const e = body.eccentricity;
  const r = (a * (1 - e * e)) / (1 + e * Math.cos(nuRad));

  // Position in orbital plane
  const xOrb = r * Math.cos(nuRad);
  const yOrb = r * Math.sin(nuRad);
  const zOrb = 0;

  // Euler rotation angles
  const omega = toRad(body.argPeriapsisDeg);
  const inc = toRad(body.inclinationDeg);
  const Omega = toRad(body.raanDeg);

  // Rotation from orbital plane to Mars inertial equatorial frame
  const cosOmega = Math.cos(Omega);
  const sinOmega = Math.sin(Omega);
  const cosInc = Math.cos(inc);
  const sinInc = Math.sin(inc);
  const cosO = Math.cos(omega);
  const sinO = Math.sin(omega);

  // Combined rotation matrix components
  const Px = cosOmega * cosO - sinOmega * sinO * cosInc;
  const Py = sinOmega * cosO + cosOmega * sinO * cosInc;
  const Pz = sinO * sinInc;

  const Qx = -cosOmega * sinO - sinOmega * cosO * cosInc;
  const Qy = -sinOmega * sinO + cosOmega * cosO * cosInc;
  const Qz = cosO * sinInc;

  const x = xOrb * Px + yOrb * Qx;
  const y = xOrb * Py + yOrb * Qy;
  const z = xOrb * Pz + yOrb * Qz;

  return new Cesium.Cartesian3(x, y, z);
}

/**
 * Generates an array of Cesium Cartesian3 positions outlining the full closed 3D orbit trajectory.
 */
export function getOrbitPolyline(body: OrbitalBody, segments: number = 96): Cesium.Cartesian3[] {
  const points: Cesium.Cartesian3[] = [];
  for (let i = 0; i <= segments; i++) {
    const nu = (i / segments) * Math.PI * 2;
    points.push(getPointInOrbit(body, nu));
  }
  return points;
}

/**
 * Calculates the current real-time state of an orbital body (position, altitude, velocity).
 */
export function getBodyState(
  body: OrbitalBody,
  date: Date = new Date(),
): {
  position: Cesium.Cartesian3;
  altitudeKm: number;
  velocityKmS: number;
  periapsisKm: number;
  apoapsisKm: number;
} {
  const elapsedSeconds = date.getTime() / 1000;
  const meanMotion = (Math.PI * 2) / body.periodSeconds;
  const M = (toRad(body.meanAnomaly0Deg) + meanMotion * elapsedSeconds) % (Math.PI * 2);

  const E = solveKepler(M, body.eccentricity);
  const nu = 2 * Math.atan2(
    Math.sqrt(1 + body.eccentricity) * Math.sin(E / 2),
    Math.sqrt(1 - body.eccentricity) * Math.cos(E / 2),
  );

  const pos = getPointInOrbit(body, nu);
  const r = Cesium.Cartesian3.magnitude(pos);
  const altitudeKm = Math.round((r - MARS_RADIUS_M) / 1000);

  // Vis-viva equation: v = sqrt(GM * (2/r - 1/a))
  const v = Math.sqrt(MARS_GM * (2 / r - 1 / body.semiMajorAxisM));
  const velocityKmS = parseFloat((v / 1000).toFixed(2));

  const periapsisKm = Math.round((body.semiMajorAxisM * (1 - body.eccentricity) - MARS_RADIUS_M) / 1000);
  const apoapsisKm = Math.round((body.semiMajorAxisM * (1 + body.eccentricity) - MARS_RADIUS_M) / 1000);

  return {
    position: pos,
    altitudeKm,
    velocityKmS,
    periapsisKm,
    apoapsisKm,
  };
}
