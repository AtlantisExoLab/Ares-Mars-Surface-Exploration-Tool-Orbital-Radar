/**
 * MissionTypes.ts
 * Types for the Astronaut Mission Planner, EVA simulation, and demo scenarios.
 */

export interface MissionWaypoint {
  id: string;
  lat: number;
  lon: number;
  label: string;
  note: string;
  elevationM?: number;
}

export type EvaMode = 'astronaut-pair' | 'rover-assisted';
export type DisplayMode = 'tablet' | 'helmet-hud' | 'habitat';

export interface RouteHazard {
  id: string;
  lat: number;
  lon: number;
  type: 'steep-slope' | 'boulder-field' | 'dune-field' | 'cliff';
  severity: 'warning' | 'critical';
  description: string;
}

export interface SafetyMetrics {
  totalDistanceKm: number;
  estimatedDurationHours: number;
  maxSlopeDeg: number;
  meanSlopeDeg: number;
  elevationGainM: number;
  elevationLossM: number;
  temperatureRangeC: { min: number; max: number };
  radiationDoseRateMGyDay: number; // MSL RAD baseline (~0.64 mGy/day)
  habitatDistanceKm: number;
  habitatLosMaintained: boolean;
  warnings: Array<{
    id: string;
    level: 'info' | 'warning' | 'critical';
    title: string;
    detail: string;
  }>;
}

export interface DemoScenario {
  id: string;
  name: string;
  description: string;
  location: {
    lat: number;
    lon: number;
    name: string;
  };
  objective: string;
  layers: string[];
  waypoints: Array<{
    lat: number;
    lon: number;
    label: string;
    note: string;
  }>;
  estimatedDistanceKm: number;
  estimatedEvaDurationHours: number;
  scienceRationale: string;
}
