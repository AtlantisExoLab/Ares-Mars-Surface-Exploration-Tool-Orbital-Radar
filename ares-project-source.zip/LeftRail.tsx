/**
 * LeftRail.tsx
 * Slim 64px navigation rail with animated active indicator, icon tooltips,
 * and quick-access triggers for Search, Layers, Missions, Mission Planner, and Settings.
 */

import React from 'react';
import { useGlobeStore } from '../../store/globeStore';
import { usePlannerStore } from '../../store/plannerStore';
import { resetToGlobeView } from '../../globe/CameraController';

export const LeftRail: React.FC = () => {
  const viewer = useGlobeStore((s) => s.viewer);
  const activePanel = useGlobeStore((s) => s.activePanel);
  const setActivePanel = useGlobeStore((s) => s.setActivePanel);
  const openPlanner = usePlannerStore((s) => s.openPlanner);
  const closePlanner = usePlannerStore((s) => s.closePlanner);

  const navItems = [
    {
      id: 'layers' as const,
      label: 'Data Layers',
      icon: (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.75}
            d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
          />
        </svg>
      ),
    },
    {
      id: 'sites' as const,
      label: 'Missions & Sites',
      icon: (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.75}
            d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
          />
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.75}
            d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
          />
        </svg>
      ),
    },
    {
      id: 'live-images' as const,
      label: 'Live Rover Images',
      icon: (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.75}
            d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"
          />
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.75}
            d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"
          />
        </svg>
      ),
    },
    {
      id: 'radar' as const,
      label: 'Orbital Radar',
      icon: (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <circle cx="12" cy="12" r="9" strokeWidth={1.5} strokeDasharray="2 2" />
          <circle cx="12" cy="12" r="5" strokeWidth={1.75} />
          <circle cx="12" cy="12" r="1.5" fill="currentColor" />
          <path strokeLinecap="round" strokeWidth={1.75} d="M12 3v3m0 12v3M3 12h3m12 0h3" />
        </svg>
      ),
    },
    {
      id: 'planner' as const,
      label: 'Astronaut Mission Planner',
      isSpecial: true,
      icon: (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.75}
            d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"
          />
        </svg>
      ),
    },
    {
      id: 'settings' as const,
      label: 'Settings & About',
      icon: (
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.75}
            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
          />
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.75}
            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
          />
        </svg>
      ),
    },
  ];

  const handleNavClick = (id: typeof navItems[0]['id']) => {
    if (id === 'planner') {
      if (activePanel === 'planner') {
        closePlanner();
        setActivePanel(null);
      } else {
        openPlanner();
        setActivePanel('planner');
        useGlobeStore.getState().setSelectedSite(null);
      }
    } else {
      setActivePanel(id);
    }
  };

  return (
    <aside className="fixed top-0 left-0 bottom-8 w-16 bg-space-950/80 border-r border-white/10 backdrop-blur-2xl flex flex-col items-center py-4 z-40 select-none pointer-events-auto">
      {/* Brand Icon: Click resets to Home Mars view */}
      <button
        onClick={() => {
          if (viewer) resetToGlobeView(viewer);
        }}
        title="Reset to full Mars orbit view"
        className="w-10 h-10 rounded-xl bg-gradient-to-br from-mars-500 to-mars-700 flex items-center justify-center text-white font-bold text-lg shadow-[0_0_16px_rgba(232,82,26,0.5)] mb-6 cursor-pointer hover:scale-105 active:scale-95 transition-transform"
      >
        🔴
      </button>

      {/* Nav Buttons */}
      <div className="flex-1 flex flex-col items-center gap-3">
        {navItems.map((item) => {
          const isActive = activePanel === item.id;
          return (
            <div key={item.id} className="relative group">
              <button
                onClick={() => handleNavClick(item.id)}
                className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all ${
                  isActive
                    ? 'bg-mars-600 text-white shadow-[0_0_14px_rgba(232,82,26,0.6)]'
                    : item.isSpecial
                    ? 'bg-mars-950/60 text-mars-400 border border-mars-600/30 hover:bg-mars-900/60 hover:text-white'
                    : 'text-white/60 hover:text-white hover:bg-white/10'
                }`}
                aria-label={item.label}
              >
                {item.icon}
              </button>

              {/* Tooltip */}
              <div className="absolute left-full ml-3 top-1/2 -translate-y-1/2 px-3 py-1.5 rounded-lg bg-space-900/95 border border-white/15 text-white text-xs font-medium whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-opacity shadow-xl z-50">
                {item.label}
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Shortcuts: Astronaut EVA Planner */}
      <div className="flex flex-col items-center gap-2">
        <div className="relative group">
          <button
            onClick={() => handleNavClick('planner')}
            className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm transition-colors ${
              activePanel === 'planner'
                ? 'bg-mars-600 text-white border border-mars-400 shadow-[0_0_12px_rgba(232,82,26,0.6)]'
                : 'bg-mars-600/20 text-mars-400 border border-mars-500/30 hover:bg-mars-600/40'
            }`}
            title="Astronaut EVA Planner"
          >
            🧑‍🚀
          </button>
          <div className="absolute left-full ml-3 top-1/2 -translate-y-1/2 px-3 py-1.5 rounded-lg bg-space-900/95 border border-mars-500/40 text-mars-300 text-xs font-medium whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-opacity shadow-xl z-50">
            Astronaut EVA Planner
          </div>
        </div>
      </div>
    </aside>
  );
};
