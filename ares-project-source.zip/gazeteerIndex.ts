/**
 * gazeteerIndex.ts
 * Search index over the IAU Gazetteer of Planetary Nomenclature, landing sites, and orbiters.
 */

import type { GazetteerFeature } from '../types/MarsTypes';
import rawGazetteer from '../../public/data/gazetteer-features.json';
import { LANDING_SITES } from './landingSites';

export const GAZETTEER_FEATURES: GazetteerFeature[] = rawGazetteer as GazetteerFeature[];

export interface SearchResultItem {
  id: string;
  name: string;
  category: 'Feature' | 'Landing Site' | 'Rover';
  type: string;
  lat: number;
  lon: number;
  description: string;
  diameterKm?: number;
}

export function searchFeatures(query: string, maxResults = 10): SearchResultItem[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];

  const results: SearchResultItem[] = [];

  // 1. Search landing sites first for direct mission matches
  for (const site of LANDING_SITES) {
    if (
      site.name.toLowerCase().includes(q) ||
      site.locationName.toLowerCase().includes(q) ||
      site.agency.toLowerCase().includes(q)
    ) {
      results.push({
        id: `site-${site.id}`,
        name: site.name,
        category: 'Landing Site',
        type: `${site.agency} ${site.type}`,
        lat: site.lat,
        lon: site.lon,
        description: `Landed ${site.landingDate} in ${site.locationName}`,
      });
    }
  }

  // 2. Search IAU planetary nomenclature features
  for (const feat of GAZETTEER_FEATURES) {
    if (
      feat.name.toLowerCase().includes(q) ||
      feat.type.toLowerCase().includes(q) ||
      feat.description.toLowerCase().includes(q)
    ) {
      results.push({
        id: `feat-${feat.id}`,
        name: feat.name,
        category: 'Feature',
        type: feat.type,
        lat: feat.lat,
        lon: feat.lon,
        description: feat.description,
        diameterKm: feat.diameterKm,
      });
    }
  }

  return results.slice(0, maxResults);
}

export function getFeatureByName(name: string): GazetteerFeature | undefined {
  const norm = name.trim().toLowerCase();
  return GAZETTEER_FEATURES.find((f) => f.name.toLowerCase() === norm);
}

export function getRandomFeature(): GazetteerFeature {
  const index = Math.floor(Math.random() * GAZETTEER_FEATURES.length);
  return GAZETTEER_FEATURES[index];
}
