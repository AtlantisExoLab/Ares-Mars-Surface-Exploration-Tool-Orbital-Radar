import React, { useMemo } from 'react';

interface Props {
  cameraAltKm: number;
  viewportWidthPx: number;
}

/** Mars mean radius in km */
const MARS_RADIUS_KM = 3389.5;

/** Preferred nice scale bar distances in km */
const NICE_DISTANCES = [
  0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100, 200, 500,
  1000, 2000, 5000, 10000,
];

/** Max fraction of viewport width the bar should occupy */
const MAX_BAR_FRACTION = 0.25;

function formatDistance(km: number): string {
  if (km >= 1) return `${km.toLocaleString()} km`;
  return `${Math.round(km * 1000)} m`;
}

export const ScaleBar: React.FC<Props> = ({ cameraAltKm, viewportWidthPx }) => {
  const { barPx, label } = useMemo(() => {
    // Ground sampling distance: approximate km per pixel at the horizon
    // Using half-angle approximation: FOV ~60°, so ground width ≈ 2 * alt * tan(30°)
    const groundWidthKm = 2 * cameraAltKm * Math.tan((30 * Math.PI) / 180);
    // Clamp by Mars circumference
    const clampedWidth = Math.min(groundWidthKm, 2 * Math.PI * MARS_RADIUS_KM);
    const kmPerPx = clampedWidth / viewportWidthPx;

    const maxBarKm = MAX_BAR_FRACTION * viewportWidthPx * kmPerPx;

    // Pick the largest nice distance that fits
    let chosen = NICE_DISTANCES[0];
    for (const d of NICE_DISTANCES) {
      if (d <= maxBarKm) chosen = d;
      else break;
    }

    const barPx = chosen / kmPerPx;
    return { barPx: Math.round(barPx), label: formatDistance(chosen) };
  }, [cameraAltKm, viewportWidthPx]);

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-start',
        gap: 2,
        userSelect: 'none',
        pointerEvents: 'none',
      }}
    >
      {/* Bar */}
      <div
        style={{
          width: barPx,
          height: 3,
          background: 'rgba(255,255,255,0.75)',
          borderRadius: 2,
          boxShadow: '0 0 4px rgba(0,0,0,0.6)',
          position: 'relative',
        }}
      >
        {/* End ticks */}
        <div
          style={{
            position: 'absolute',
            left: 0,
            top: -4,
            width: 2,
            height: 10,
            background: 'rgba(255,255,255,0.75)',
          }}
        />
        <div
          style={{
            position: 'absolute',
            right: 0,
            top: -4,
            width: 2,
            height: 10,
            background: 'rgba(255,255,255,0.75)',
          }}
        />
      </div>
      {/* Label */}
      <span
        style={{
          fontSize: 10,
          color: 'rgba(255,255,255,0.75)',
          fontFamily: 'var(--font-mono, monospace)',
          textShadow: '0 1px 3px rgba(0,0,0,0.8)',
        }}
      >
        {label}
      </span>
    </div>
  );
};

export default ScaleBar;
