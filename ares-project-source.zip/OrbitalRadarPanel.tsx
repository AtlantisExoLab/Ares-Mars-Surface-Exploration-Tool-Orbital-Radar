/**
 * OrbitalRadarPanel.tsx
 *
 * Slide-in orbital tracking directory inspired by Orbital Radar (orbitalradar.com/mars):
 *  - Real-time altitude, velocity, and period tracking for Phobos, Deimos, and 7 active orbiters
 *  - One-click camera tracking that flies into 3D orbit around Mars
 *  - Agency attribution, launch years, and scientific sensor summaries
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import * as Cesium from 'cesium';
import { ORBITAL_BODIES, getBodyState, type OrbitalBody } from '../../data/orbitalBodies';
import { useGlobeStore } from '../../store/globeStore';

export const OrbitalRadarPanel: React.FC = () => {
  const viewer = useGlobeStore((s) => s.viewer);
  const setActivePanel = useGlobeStore((s) => s.setActivePanel);
  const selectedOrbitalBodyId = useGlobeStore((s) => s.selectedOrbitalBodyId);
  const setSelectedOrbitalBody = useGlobeStore((s) => s.setSelectedOrbitalBody);

  const [tab, setTab] = useState<'all' | 'moons' | 'orbiters'>('all');
  const [tick, setTick] = useState(0);

  // Update live metrics every 1.5 seconds
  useEffect(() => {
    const timer = setInterval(() => setTick((t) => t + 1), 1500);
    return () => clearInterval(timer);
  }, []);

  const filtered = ORBITAL_BODIES.filter((b) => {
    if (tab === 'moons') return b.type === 'moon';
    if (tab === 'orbiters') return b.type === 'orbiter';
    return true;
  });

  const handleTrackBody = (body: OrbitalBody) => {
    setSelectedOrbitalBody(body.id);
    if (!viewer) return;

    const state = getBodyState(body, new Date());
    const dest = Cesium.Cartesian3.multiplyByScalar(
      Cesium.Cartesian3.normalize(state.position, new Cesium.Cartesian3()),
      Cesium.Cartesian3.magnitude(state.position) * 1.35,
      new Cesium.Cartesian3(),
    );

    viewer.camera.flyTo({
      destination: dest,
      duration: 2.2,
      easingFunction: Cesium.EasingFunction.CUBIC_IN_OUT,
    });
  };

  return (
    <motion.div
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: -20, opacity: 0 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="fixed top-16 left-20 w-80 md:w-96 bottom-16 bg-[#0a0d14] border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col z-30 overflow-hidden pointer-events-auto"
    >
      {/* Header */}
      <div className="px-5 py-4 border-b border-slate-700/80 bg-[#0f1420] flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_#34d399]" />
            <h2 className="text-white font-display font-semibold text-base">Orbital Radar</h2>
          </div>
          <div className="text-white/50 text-xs mt-0.5">
            Real-Time Tracking: 7 Orbiters & 2 Martian Moons
          </div>
        </div>
        <button
          onClick={() => setActivePanel(null)}
          className="text-white/40 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          title="Close Orbital Radar"
        >
          ✕
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10 bg-space-950/40 text-xs">
        <button
          onClick={() => setTab('all')}
          className={`flex-1 py-2.5 font-medium border-b-2 transition-colors ${
            tab === 'all'
              ? 'border-emerald-400 text-emerald-400 bg-white/5'
              : 'border-transparent text-white/50 hover:text-white'
          }`}
        >
          All ({ORBITAL_BODIES.length})
        </button>
        <button
          onClick={() => setTab('orbiters')}
          className={`flex-1 py-2.5 font-medium border-b-2 transition-colors ${
            tab === 'orbiters'
              ? 'border-emerald-400 text-emerald-400 bg-white/5'
              : 'border-transparent text-white/50 hover:text-white'
          }`}
        >
          Spacecraft (7)
        </button>
        <button
          onClick={() => setTab('moons')}
          className={`flex-1 py-2.5 font-medium border-b-2 transition-colors ${
            tab === 'moons'
              ? 'border-emerald-400 text-emerald-400 bg-white/5'
              : 'border-transparent text-white/50 hover:text-white'
          }`}
        >
          Moons (2)
        </button>
      </div>

      {/* Bodies List */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {filtered.map((body) => {
          const state = getBodyState(body, new Date());
          const isSelected = body.id === selectedOrbitalBodyId;
          const isMoon = body.type === 'moon';

          return (
            <div
              key={body.id}
              className={`p-3.5 rounded-xl border transition-all ${
                isSelected
                  ? 'bg-space-800/90 border-emerald-400/60 shadow-[0_0_16px_rgba(52,211,153,0.15)]'
                  : 'bg-space-800/40 border-white/10 hover:border-white/20 hover:bg-space-800/60'
              }`}
            >
              {/* Top Row: Badge, Name, Type */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-base">{body.agencyBadge}</span>
                  <div>
                    <div className="font-semibold text-white text-xs leading-tight">
                      {body.name}
                    </div>
                    <div className="text-[10px] text-white/40 mt-0.5">
                      {body.agency} · {body.country}
                    </div>
                  </div>
                </div>

                <span
                  className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                  style={{ backgroundColor: body.color }}
                  title="Orbital path colour"
                />
              </div>

              {/* Live Telemetry Grid */}
              <div className="grid grid-cols-2 gap-2 mt-3 pt-2.5 border-t border-white/10 text-[11px] font-mono">
                <div>
                  <span className="text-white/40 block text-[9px] uppercase">Current Alt:</span>
                  <span className="text-emerald-400 font-bold">
                    {state.altitudeKm.toLocaleString()} km
                  </span>
                </div>
                <div>
                  <span className="text-white/40 block text-[9px] uppercase">Orbital Speed:</span>
                  <span className="text-sky-300 font-bold">
                    {state.velocityKmS.toFixed(2)} km/s
                  </span>
                </div>
                <div>
                  <span className="text-white/40 block text-[9px] uppercase">Period:</span>
                  <span className="text-white/80">
                    {(body.periodSeconds / 3600).toFixed(1)} hrs
                  </span>
                </div>
                <div>
                  <span className="text-white/40 block text-[9px] uppercase">
                    {isMoon ? 'Dimensions:' : 'Peri / Apo:'}
                  </span>
                  <span className="text-white/80">
                    {isMoon ? body.dimensionsKm : `${state.periapsisKm} / ${state.apoapsisKm}k`}
                  </span>
                </div>
              </div>

              {/* Description */}
              <p className="text-[10px] text-white/60 leading-relaxed mt-2.5 line-clamp-2">
                {body.objectives}
              </p>

              {/* Action Button */}
              <div className="mt-3 flex items-center justify-between pt-2 border-t border-white/5">
                <span className="text-[10px] text-white/40 font-mono">
                  Inc: {body.inclinationDeg}°
                </span>

                <button
                  onClick={() => handleTrackBody(body)}
                  className="px-3 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-[11px] font-medium transition-colors flex items-center gap-1.5"
                >
                  <span>🔭</span>
                  <span>Track in 3D Orbit</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
};
