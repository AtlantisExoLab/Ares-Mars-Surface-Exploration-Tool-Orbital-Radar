/**
 * MarsChatbot.tsx
 *
 * Dedicated Mars Mission Chatbot powered directly by Google Gemini API.
 * Provides live AI intelligence, multi-turn conversation, and Mars mission recommendations.
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  askGemini,
  getStoredGeminiApiKey,
  storeGeminiApiKey,
  type ChatMessageItem,
} from '../../services/gemini/geminiService';

interface MarsChatbotProps {
  isOpen: boolean;
  onClose: () => void;
}

const MISSION_RECOMMENDATIONS = [
  {
    category: '🔴 Active Surface Rovers',
    questions: [
      'What are the key scientific discoveries of Perseverance at Jezero Crater?',
      'How does MOXIE generate breathable oxygen from the Martian atmosphere?',
      'What evidence of ancient lakes did Curiosity discover at Mount Sharp?',
    ],
  },
  {
    category: '🚀 Historic Missions & Landers',
    questions: [
      'What were the results of the 1976 Viking 1 & 2 biology experiments?',
      'What did China’s Zhurong rover discover beneath Utopia Planitia?',
      'How did Opportunity find hematite "blueberries" in Meridiani Planum?',
      'What did the InSight lander reveal about marsquakes and the core?',
    ],
  },
  {
    category: '🚁 Aerial & Future Campaigns',
    questions: [
      'How did the Ingenuity helicopter achieve 72 flights in Mars’ thin air?',
      'How will NASA and ESA bring the Jezero sample tubes back to Earth?',
      'What active orbiters are currently monitoring Mars from space?',
    ],
  },
];

export const MarsChatbot: React.FC<MarsChatbotProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessageItem[]>(() => {
    try {
      const saved = localStorage.getItem('ares_gemini_chat_messages');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [apiKey, setApiKey] = useState<string>(() => getStoredGeminiApiKey());
  const [showKeyConfig, setShowKeyConfig] = useState(false);
  const [keyInput, setKeyInput] = useState('');
  const [keySaveMessage, setKeySaveMessage] = useState('');

  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll on new message
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  // Persist conversation
  useEffect(() => {
    try {
      localStorage.setItem('ares_gemini_chat_messages', JSON.stringify(messages));
    } catch {
      // Ignore storage quota
    }
  }, [messages]);

  const handleSaveApiKey = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanKey = keyInput.trim();
    storeGeminiApiKey(cleanKey);
    setApiKey(cleanKey);
    setKeyInput('');
    setKeySaveMessage(cleanKey ? '✓ Gemini API key saved!' : 'API key cleared.');
    setTimeout(() => {
      setKeySaveMessage('');
      if (cleanKey) setShowKeyConfig(false);
    }, 1500);
  };

  const handleSendMessage = async (customQuery?: string) => {
    const textToSend = (customQuery || inputPrompt).trim();
    if (!textToSend || isLoading) return;

    if (!customQuery) {
      setInputPrompt('');
    }

    const userMessage: ChatMessageItem = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const responseText = await askGemini(textToSend, messages, apiKey);

      const assistantMessage: ChatMessageItem = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      const errMsg = err?.message || 'Unable to complete inquiry.';
      const errorMessage: ChatMessageItem = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content: `### 🪐 Mars Mission Intelligence Notice\n\n${errMsg}\n\n*ARES telemetry systems remain active.*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleClearHistory = () => {
    setMessages([]);
    localStorage.removeItem('ares_gemini_chat_messages');
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, x: 40, scale: 0.98 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      exit={{ opacity: 0, x: 40, scale: 0.98 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="fixed top-16 right-4 md:right-8 bottom-12 w-[420px] max-w-[94vw] bg-[#0A0D14]/98 border border-cyan-500/40 rounded-2xl shadow-[0_12px_45px_rgba(0,0,0,0.85),0_0_25px_rgba(0,240,255,0.15)] backdrop-blur-2xl flex flex-col z-50 overflow-hidden text-white pointer-events-auto select-none"
    >
      {/* 1. Header */}
      <div className="p-4 border-b border-cyan-500/20 bg-gradient-to-r from-cyan-950/40 via-[#0d1322] to-red-950/30 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-[0_0_12px_rgba(0,240,255,0.4)]">
            <span className="text-sm">✨</span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm font-display font-bold text-white tracking-wide">
                ARES MARS AI
              </h2>
              <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
                GEMINI
              </span>
            </div>
            <p className="text-[10.5px] text-white/50">Scientific Mars Exploration Assistant</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Active Status Beacon */}
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-[10px] font-mono text-emerald-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="hidden sm:inline">ONLINE</span>
          </div>

          {/* Optional Gemini Settings Cog */}
          <button
            onClick={() => setShowKeyConfig(!showKeyConfig)}
            className="p-1 rounded-lg text-white/50 hover:text-white hover:bg-white/10 transition-colors text-xs"
            title={apiKey ? "Gemini API Key Configured" : "Optional: Add Custom Gemini API Key"}
            aria-label="Settings and API Key"
          >
            <span>⚙️</span>
          </button>

          {/* Close button */}
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg text-white/50 hover:text-white hover:bg-white/10 flex items-center justify-center transition-colors text-sm"
            title="Close Chatbot"
            aria-label="Close Chatbot"
          >
            ✕
          </button>
        </div>
      </div>

      {/* 2. Optional Gemini API Key Configuration Tray */}
      <AnimatePresence>
        {showKeyConfig && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="p-3.5 border-b border-cyan-500/30 bg-[#070b14] overflow-hidden"
          >
            <div className="text-xs font-medium text-white/90 mb-1 flex items-center justify-between">
              <span>Custom Google Gemini Key (Optional)</span>
              <a
                href="https://aistudio.google.com/apikey"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[10px] text-cyan-400 hover:text-cyan-300 underline"
              >
                Google AI Studio ↗
              </a>
            </div>
            <p className="text-[10px] text-white/40 mb-2">
              ARES works out-of-the-box. Entering a custom key routes queries directly to Google Gemini API.
            </p>
            <form onSubmit={handleSaveApiKey} className="flex gap-2">
              <input
                type="password"
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                placeholder={apiKey ? '••••••••••••••••••••••••' : 'AIzaSy...'}
                className="flex-1 bg-black/60 border border-white/20 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-white/40 focus:outline-none focus:border-cyan-400 font-mono"
              />
              <button
                type="submit"
                className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-semibold shadow-md transition-colors"
              >
                Save
              </button>
            </form>
            {keySaveMessage && (
              <p className="text-[11px] text-emerald-400 mt-1 font-mono">{keySaveMessage}</p>
            )}
            <p className="text-[10px] text-white/40 mt-1">
              Key is stored locally in your browser. All queries are sent directly to the Gemini API.
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. Conversation & Recommendations Scroll View */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3.5 select-text">
        {/* Welcome Banner when no messages */}
        {messages.length === 0 && (
          <div className="space-y-4 py-2">
            <div className="p-4 rounded-xl bg-gradient-to-b from-[#101726] to-[#0A0D14] border border-cyan-500/20 text-center">
              <div className="w-12 h-12 rounded-2xl bg-cyan-950/60 border border-cyan-500/40 flex items-center justify-center mx-auto mb-2.5 text-xl shadow-[0_0_15px_rgba(0,240,255,0.25)]">
                🤖
              </div>
              <h3 className="text-sm font-bold text-white">Ask Anything About Mars Missions</h3>
              <p className="text-xs text-white/60 mt-1 leading-relaxed">
                Integrated directly with Google Gemini to answer questions on Martian exploration, rovers, orbiters, and surface geology.
              </p>
            </div>

            {/* Recommendation Questions */}
            <div className="space-y-3">
              <div className="text-[10.5px] font-mono uppercase tracking-wider text-cyan-400 font-semibold px-1">
                ⭐ Recommended Mission Questions:
              </div>

              {MISSION_RECOMMENDATIONS.map((group, gIdx) => (
                <div key={gIdx} className="space-y-1.5">
                  <div className="text-[10px] font-mono text-white/40 px-1">{group.category}</div>
                  <div className="flex flex-col gap-1.5">
                    {group.questions.map((q, qIdx) => (
                      <button
                        key={qIdx}
                        onClick={() => handleSendMessage(q)}
                        className="text-left p-2.5 rounded-xl bg-white/5 hover:bg-cyan-500/15 border border-white/10 hover:border-cyan-500/40 text-xs text-white/80 hover:text-cyan-200 transition-all shadow-sm leading-snug cursor-pointer"
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Message Stream */}
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className="flex items-center gap-1.5 mb-1 px-1 text-[10px] font-mono text-white/40">
              <span>{msg.role === 'user' ? 'Operator' : 'Gemini AI'}</span>
              <span>· {msg.timestamp}</span>
            </div>

            <div
              className={`max-w-[90%] rounded-2xl p-3.5 text-xs leading-relaxed shadow-lg ${
                msg.role === 'user'
                  ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white rounded-tr-none'
                  : 'bg-[#101524] border border-cyan-500/25 text-white/90 rounded-tl-none font-sans'
              }`}
            >
              <div className="whitespace-pre-wrap space-y-2">
                {msg.content}
              </div>
            </div>
          </div>
        ))}

        {/* Loading Spinner */}
        {isLoading && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/20 text-cyan-300 text-xs font-mono">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span>Consulting Google Gemini...</span>
          </div>
        )}
      </div>

      {/* 4. Recommendation Quick Chips (When messages exist) */}
      {messages.length > 0 && (
        <div className="px-3 py-1.5 border-t border-white/5 bg-black/30 overflow-x-auto scrollbar-none flex items-center gap-1.5">
          <span className="text-[10px] font-mono text-white/40 whitespace-nowrap">Suggested:</span>
          {[
            'Perseverance findings at Jezero',
            'Curiosity boxwork in Gale Crater',
            'Ingenuity helicopter flights',
            'Subsurface ice in Utopia Planitia',
          ].map((chip, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(chip)}
              className="px-2 py-0.5 rounded-full bg-white/5 hover:bg-cyan-500/20 border border-white/10 text-[10px] text-white/70 hover:text-cyan-300 whitespace-nowrap transition-colors cursor-pointer"
            >
              {chip}
            </button>
          ))}
        </div>
      )}

      {/* 5. Input Area */}
      <div className="p-3 border-t border-cyan-500/20 bg-[#080B12]">
        <div className="relative flex items-end bg-black/50 border border-white/15 focus-within:border-cyan-400 rounded-xl p-2 transition-colors">
          <textarea
            ref={textareaRef}
            rows={2}
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask Gemini about any Mars mission, rover, crater..."
            className="w-full bg-transparent text-xs text-white placeholder-white/40 focus:outline-none resize-none font-sans"
          />

          <div className="flex items-center gap-1.5 ml-2">
            {messages.length > 0 && (
              <button
                onClick={handleClearHistory}
                className="p-1.5 text-white/40 hover:text-white rounded-lg hover:bg-white/10 text-xs transition-colors"
                title="Clear Chat History"
              >
                🗑️
              </button>
            )}

            <button
              onClick={() => handleSendMessage()}
              disabled={!inputPrompt.trim() || isLoading}
              className="p-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 disabled:cursor-not-allowed text-white shadow-md transition-all cursor-pointer flex items-center justify-center"
              title="Send Message"
            >
              <svg className="w-3.5 h-3.5 transform rotate-90" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
              </svg>
            </button>
          </div>
        </div>
        <div className="flex items-center justify-between mt-1.5 px-1 text-[9.5px] font-mono text-white/40">
          <span>Enter to send · Shift+Enter for new line</span>
          <span>Google Gemini API</span>
        </div>
      </div>
    </motion.div>
  );
};
